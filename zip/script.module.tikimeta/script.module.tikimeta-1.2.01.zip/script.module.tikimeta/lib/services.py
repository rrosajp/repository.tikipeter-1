import xbmc, xbmcgui
from tikimeta.setting_reader import make_settings_dict
# from tikimeta.utils import logger

window = xbmcgui.Window(10000)

monitor = xbmc.Monitor()

class SettingsMonitor(xbmc.Monitor):
	def __init__ (self):
		xbmc.Monitor.__init__(self)
		xbmc.log("[TIKIMETA] Settings Monitor Service Starting...", 2)

	def onSettingsChanged(self):
		window.clearProperty('tikimeta_settings')
		xbmc.sleep(50)
		refreshed = make_settings_dict()

settings_monitor = SettingsMonitor()
settings_monitor.waitForAbort()
