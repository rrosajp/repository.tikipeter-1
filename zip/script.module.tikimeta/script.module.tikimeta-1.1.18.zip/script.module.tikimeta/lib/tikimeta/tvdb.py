# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui
import sys
import datetime
import json
import requests
import time
import re
from threading import Thread
# from resources.lib.modules.utils import logger

__addon_id__ = 'script.module.tikimeta'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__addon_profile__ = xbmc.translatePath(__addon__.getAddonInfo('profile'))
__handle__ = int(sys.argv[1])
window = xbmcgui.Window(10000)

class TvdbAPI:
    def __init__(self):
        self.result = {}
        self.episodes_result = []
        self.cast = []
        self.seasons_summary = []
        self.base_url = 'https://api.thetvdb.com/'
        self.base_image_url = 'https://www.thetvdb.com/banners/'
        self.headers = {'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'User-agent': 'Mozilla/5.0'}
        self.api_key = __addon__.getSetting('tvdb.apikey')
        if not self.api_key or self.api_key == '': self.api_key = "905237D822EE21A6"
        self.get_jwtoken()
        self.update_headers()

    def update_headers(self):
        self.headers['Authorization'] = 'Bearer %s' % self.jw_token

    def pause_token_renew(self):
        if not window.getProperty('tikimeta.fetching.tvdb.jwtoken') == 'true':
            return False
        for i in range(0, 20):
            if window.getProperty('tikimeta.fetching.tvdb.jwtoken') == 'true':
                time.sleep(1)
            else:
                self.jw_token = window.getProperty('tikimeta.new.tvdb.jwtoken')
                return True

    def pause_token_new(self):
        if not window.getProperty('tikimeta.fetching.new.tvdb.jwtoken') == 'true':
            return False
        for i in range(0, 20):
            if window.getProperty('tikimeta.fetching.new.tvdb.jwtoken') == 'true':
                time.sleep(1)
            else:
                self.jw_token = window.getProperty('tikimeta.new.tvdb.jwtoken')
                return True

    def get_jwtoken(self):
        self.jw_token = __addon__.getSetting('tvdb.jwtoken')
        if not self.jw_token or self.jw_token == '': self.get_new_jwtoken()

    def get_new_jwtoken(self):
        pause_token_new = self.pause_token_new()
        if not pause_token_new:
            window.setProperty('tikimeta.fetching.new.tvdb.jwtoken', 'true')
            window.clearProperty('tikimeta.new.tvdb.jwtoken')
        else: return
        url = '%slogin' % self.base_url
        data = json.dumps({'apikey': self.api_key})
        headers = self.headers
        if 'Authorization' in headers:
            headers.pop('Authorization')
        response = json.loads(requests.post(url, data=data, headers=headers).text)
        self.jw_token = response['token']
        __addon__.setSetting('tvdb.jwtoken', self.jw_token)
        __addon__.setSetting('tvdb.jwtoken_expiry', str(time.time() + (24 * (60 * 60))))
        window.setProperty('tikimeta.new.tvdb.jwtoken', self.jw_token)
        window.clearProperty('tikimeta.fetching.new.tvdb.jwtoken')

    def renew_jwtoken(self):
        pause_token_renew = self.pause_token_renew()
        if not pause_token_renew:
            window.setProperty('tikimeta.fetching.tvdb.jwtoken', 'true')
            window.clearProperty('tikimeta.new.tvdb.jwtoken')
        else: return
        url = '%srefresh_token' % self.base_url
        response = json.loads(requests.post(url, headers=self.headers).text)
        if 'Error' in response:
            window.clearProperty('tikimeta.fetching.tvdb.jwtoken')
            self.get_new_jwtoken()
        else:
            self.jw_token = response['token']
            __addon__.setSetting('tvdb.jwtoken', self.jw_token)
            __addon__.setSetting('tvdb.jwtoken_expiry', str(time.time() + (24 * (60 * 60))))
            window.setProperty('tikimeta.new.tvdb.jwtoken', self.jw_token)
            window.clearProperty('tikimeta.fetching.tvdb.jwtoken')
        return

    def _get(self, url):
        data = {}
        url = self.base_url + url
        response = requests.get(url, headers=self.headers).text
        if 'not authorized' in response.lower():
            self.renew_jwtoken()
            self.update_headers()
            response = requests.get(url, headers=self.headers).text
        response = json.loads(requests.get(url, headers=self.headers).text)
        if response.get("data"):
            data = response
        return data

    def get_series(self, tvdb_id):
        threads = []
        threads.append(Thread(target=self.get_series_info, args=(tvdb_id,)))
        threads.append(Thread(target=self.get_series_episodes_summary, args=(tvdb_id,)))
        threads.append(Thread(target=self.get_poster, args=(tvdb_id,)))
        threads.append(Thread(target=self.get_fanart, args=(tvdb_id,)))
        threads.append(Thread(target=self.get_cast, args=(tvdb_id,)))
        [i.start() for i in threads]
        [i.join() for i in threads]
        result = self._map_series_data(self.series_info)
        return result

    def get_series_info(self, tvdb_id):
        series_info = self._get("series/%s" % tvdb_id)['data']
        self.series_info = series_info

    def get_poster(self, tvdb_id, season=None):
        if season:
            images = self._get("series/%s/images/query?keyType=season&subKey=%s" % (tvdb_id, season))['data']
        else:
            images = self._get("series/%s/images/query?keyType=poster" % (tvdb_id))['data']
        poster = self.process_images(images)
        try: self.poster = poster[0]
        except: self.poster = ''

    def get_fanart(self, tvdb_id, landscape=False):
        if landscape:
            images = self._get("series/%s/images/query?keyType=fanart&subKey=text" % (tvdb_id))['data']
        else:
            images = self._get("series/%s/images/query?keyType=fanart&subKey=graphical" % (tvdb_id))['data']
        fanart = self.process_images(images)
        try: self.fanart = fanart[0]
        except: self.fanart = ''

    def get_cast(self, tvdb_id):
        try:
            url = 'series/%s/actors' % tvdb_id
            actors = self._get(url)['data']
            actors = sorted(actors, key=lambda k: k['sortOrder'])
            for i in actors:
                self.cast.append({'name': i['name'], 'role': i['role'], 'thumbnail': self.base_image_url + i['image']})
        except:
            pass

    def get_series_episodes_summary(self, tvdb_id):
        summary = {}
        try: summary = self._get("series/%s/episodes/summary" % tvdb_id)['data']
        except: pass
        return summary

    def get_all_episodes(self, tvdb_id):
        def get_data(page):
            data = self._get("series/%s/episodes?page=%s" % (tvdb_id, page))['data']
            self.episodes_result.extend(data)
        if not tvdb_id: return None
        threads = []
        data = self._get("series/%s/episodes?page=1" % tvdb_id)
        if not data: return None
        total_pages = data['links']['last']
        data = data['data']
        self.episodes_result.extend(data)
        if total_pages > 1:
            for i in range(2, total_pages+1): threads.append(Thread(target=get_data, args=(i,)))
            [i.start() for i in threads]
            [i.join() for i in threads]
        return self.episodes_result

    def get_series_by_imdb_id(self, imdb_id):
        data = self._get("search/series?imdbId=%s" % imdb_id)
        if data: return data['data'][0]
        else: return None

    @staticmethod
    def process_images(images):
        result = []
        if images:
            images = [i for i in images if i['languageId'] == 7]
            for image in images:
                if image["fileName"] and not image["fileName"].endswith("/"):
                    if image["fileName"].startswith("http://"): 
                        image["fileName"] = image["fileName"].replace("http://", "https://")
                    elif not image["fileName"].startswith("https://"):
                        image["fileName"] = "https://thetvdb.com/banners/" + image["fileName"]
                    image_score = image["ratingsInfo"]["average"] * image["ratingsInfo"]["count"]
                    image["score"] = image_score
                    result.append(image)
        return [item["fileName"] for item in sorted(result, key=lambda k: k['score'], reverse=True)]

    def _map_series_data(self, showdetails):
        result = {}
        if showdetails:
            result['episode_summary'] = self.summary
            result['number_of_episodes'] = self.summary['airedEpisodes']
            result['number_of_seasons'] = len([i for i in self.summary['airedSeasons'] if not i == '0'])
            result["title"] = showdetails["seriesName"]
            result["status"] = showdetails["status"]
            result["tvdb_id"] = showdetails["id"]
            result["network"] = showdetails["network"]
            result["studio"] = [showdetails["network"]]
            local_airday, local_airday_short, airday_int = self._get_local_weekday(showdetails["airsDayOfWeek"])
            result["airday"] = local_airday
            result["airday.short"] = local_airday_short
            result["airday.int"] = airday_int
            result["airtime"] = self._get_local_time(showdetails["airsTime"])
            result["airdaytime"] = "%s %s (%s)" % (result["airday"], result["airtime"], result["network"])
            result["votes"] = showdetails["siteRatingCount"]
            result["rating.tvdb"] = showdetails["siteRating"]
            # make sure we have a decimal in the rating
            if len(str(result["rating.tvdb"])) == 1:
                result["rating.tvdb"] = "%s.0" % result["rating.tvdb"]
            result["rating"] = result["rating.tvdb"]
            result["votes"] = showdetails["siteRatingCount"]
            try:
                result["runtime"] = int(showdetails["runtime"]) * 60
            except Exception:
                pass
            result["plot"] = showdetails["overview"]
            result["genre"] = showdetails["genre"]
            result["premiered"] = showdetails["firstAired"]
            result['year'] = result['premiered'].split('-')[0]
            result["imdb_id"] = showdetails["imdbId"]
            result['certification'] = showdetails["rating"]
            result['cast'] = self.cast
            # artwork
            # result["art"] = {}
            result["fanart"] = self.fanart
            result["poster"] = self.poster
            if showdetails.get("banner"):
                result["banner"] = "https://thetvdb.com/banners/" + showdetails["banner"]
        return result

    def _get_local_weekday(self, weekday):
        '''returns the localized representation of the weekday provided by the api'''
        if not weekday:
            return ("", "", 0)
        day_name = weekday
        day_name_short = day_name[:3]
        day_int = 0
        try:
            locale = arrow.locales.get_locale(KODI_LANGUAGE)
            day_names = {"monday": 1, "tuesday": 2, "wednesday": 3, "thurday": 4,
                         "friday": 5, "saturday": 6, "sunday": 7}
            day_int = day_names.get(weekday.lower(), 0)
            if day_int:
                day_name = locale.day_name(day_int).capitalize()
                day_name_short = locale.day_abbreviation(day_int).capitalize()
        except Exception as exc:
            pass
        return (day_name, day_name_short, day_int)

    def _get_local_time(self, timestr):
        '''returns the correct localized representation of the time provided by the api'''
        result = ""
        try:
            if timestr and ":" in timestr:
                timestr = timestr.replace(".", ":")
                if "H" in xbmc.getRegion('time'):
                    time_format = "HH:mm"
                else:
                    time_format = "h:mm A"
                if " AM" in timestr or " PM" in timestr:
                    result = arrow.get(timestr, 'h:mm A').format(time_format, locale=KODI_LANGUAGE)
                elif " am" in timestr or " pm" in timestr:
                    result = arrow.get(timestr, 'h:mm a').format(time_format, locale=KODI_LANGUAGE)
                elif "AM" in timestr or "PM" in timestr:
                    result = arrow.get(timestr, 'h:mmA').format(time_format, locale=KODI_LANGUAGE)
                elif "am" in timestr or "pm" in timestr:
                    result = arrow.get(timestr, 'h:mma').format(time_format, locale=KODI_LANGUAGE)
                elif len(timestr.split(":")[0]) == 1:
                    result = arrow.get(timestr, 'h:mm').format(time_format, locale=KODI_LANGUAGE)
                else:
                    result = arrow.get(timestr, 'HH:mm').format(time_format, locale=KODI_LANGUAGE)
        except Exception as exc:
            pass
            return timestr
        return result

