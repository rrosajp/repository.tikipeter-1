

def playback_context_menu():
    import xbmc
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.furkit/?mode=playback_kodi_library_menu)')

if __name__ == '__main__':
    playback_context_menu()