# -*- coding: utf-8 -*-
import xbmc, xbmcgui
import os
from datetime import datetime, timedelta
try: from sqlite3 import dbapi2 as database
except ImportError: from pysqlite2 import dbapi2 as database

def notification(line1, time=3000, sound=False):
	icon = os.path.join(xbmc.translatePath('special://home/addons/plugin.program.thumbcache.cleaner'), "icon.png")
	xbmcgui.Dialog().notification('Thumb Cleaner', line1, icon, time, sound)

def thumb_cleaner():
	current_date = datetime.date(datetime.utcnow())
	thumbs_folder = xbmc.translatePath('special://thumbnails')
	dbfile = xbmc.translatePath(os.path.join('special://database', 'Textures13.db'))
	item_list = []
	minimum_uses = 30
	days = xbmcgui.Dialog().input('Remove Thumbs Older Than (Days)...', type=xbmcgui.INPUT_NUMERIC)
	if not days: return notification('No Days Set')
	back_date = (current_date - timedelta(days=int(days))).strftime('%Y-%m-%d %H:%M:%S')
	if os.path.exists(dbfile):
		dbcon = database.connect(dbfile, isolation_level=None)
		dbcur = dbcon.cursor()
		dbcur.execute('''PRAGMA synchronous = OFF''')
		dbcur.execute('''PRAGMA journal_mode = OFF''')
	else: return notification('Failed')
	progress_dialog = xbmcgui.DialogProgress()
	progress_dialog.create('Thumbnails Remover', '')
	progress_dialog.update(0, 'Gathering Thumbnail Info...')
	dbcur.execute("SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?", (minimum_uses, str(back_date)))
	result = dbcur.fetchall()
	result_length = len(result)
	if not result_length > 0: return notification('No Thumbnails to Clear')
	for count, item in enumerate(result):
		if progress_dialog.iscanceled(): break
		_id = item[0]
		dbcur.execute("SELECT cachedurl FROM texture WHERE id = ?", (_id, ))
		url = dbcur.fetchall()[0][0]
		path = os.path.join(thumbs_folder, url)
		try:
			os.remove(path)
			item_list.append((_id,))
		except: pass
		percent = int((count/float(result_length))*100)
		line = '[B]Total To Remove:[/B] %s[CR][B]Removing:[/B] %02d.%s' % (result_length, count, str(path))
		progress_dialog.update(max(1, percent), line)
	line = 'Removing Database Entries...[CR]Please Wait...[CR]%s'
	progress_dialog.update(33, line % 'Removing Sizes IDS...')
	dbcur.executemany("DELETE FROM sizes WHERE idtexture = ?", item_list)
	progress_dialog.update(66, line % 'Removing Texture IDS...')
	dbcur.executemany("DELETE FROM texture WHERE id=?", item_list)
	progress_dialog.update(99, line % 'Cleaning Database...')
	dbcur.execute("VACUUM")
	dbcon.commit()
	xbmc.sleep(1500)
	try: progress_dialog.close()
	except Exception: pass
	return notification('Success')

thumb_cleaner()