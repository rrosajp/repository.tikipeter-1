# -*- coding: utf-8 -*-

def movie_meta(id_type, media_id, hours=168):
    from furkitmeta.tmdb import get_movie_meta
    return get_movie_meta(id_type, media_id, hours)

def tvshow_meta(id_type, media_id, hours=168):
    from furkitmeta.tmdb import get_tvshow_meta
    return get_tvshow_meta(id_type, media_id, hours)

def season_episodes_meta(media_id, season_no, hours=24):
    from furkitmeta.tmdb import get_season_episodes_meta
    return get_season_episodes_meta(media_id, season_no, hours)

def delete_cache_item(db_type, id_type, media_id):
    from furkitmeta.metacache import MetaCache
    return MetaCache().delete(db_type, id_type, media_id)

def delete_meta_cache():
    from furkitmeta.metacache import MetaCache
    return MetaCache().delete_all()