# -*- coding: utf-8 -*-
import xbmcaddon
import requests, time
from furkitmeta.metacache import MetaCache
from furkitmeta.utils import to_utf8, try_parse_int
# from furkitmeta.utils import logger

__addon__ = xbmcaddon.Addon("script.module.furkitmeta")
icon_image = __addon__.getAddonInfo('icon')
fanart = __addon__.getAddonInfo('fanart')

tmdb_api = xbmcaddon.Addon(id='script.module.furkitmeta').getSetting('tmdb_api')

def tmdb_movies_simple(tmdb_id):
    url = 'https://api.themoviedb.org/3/movie/%s?api_key=%s&language=en-US&append_to_response=external_ids,videos,credits,release_dates' % (tmdb_id, tmdb_api)
    return get_tmdb(url).json()

def tmdb_movies_simple_external_id(external_source, external_id):
    url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=%s' % (external_id, tmdb_api, external_source)
    return get_tmdb(url).json()['movie_results'][0]

def tmdb_tv_simple(tmdb_id):
    url = 'https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en-US&append_to_response=external_ids,videos,credits' % (tmdb_id, tmdb_api)
    return get_tmdb(url).json()

def tmdb_tv_simple_external_id(external_source, external_id):
    url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=%s' % (external_id, tmdb_api, external_source)
    return get_tmdb(url).json()['tv_results'][0]

def tmdb_tv_season_episodes(tmdb_id, season_no):
    url = 'https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s&language=en-US&append_to_response=credits' % (tmdb_id, int(season_no), tmdb_api)
    return get_tmdb(url).json()

def get_tmdb(url):
    try:
        def request(url):
            result = requests.get(url)
            response = result.status_code
            return str(response), result
        for i in range(15):
            response, result = request(url)
            if response == '200':
                return result
            elif response == '429':
                time.sleep(10)
                pass
            else:
                return
    except: pass

def get_movie_meta(id_type, media_id, hours=168):
    metacache = MetaCache()
    meta = None
    data = metacache.get('movie', id_type, media_id)
    if data: return data
    try:
        from datetime import timedelta
        data = tmdb_movies_simple
        result = tmdb_movies_simple_external_id
        data = data(media_id) if id_type == 'tmdb_id' else data(result(id_type, media_id)['id'])
        meta = build_meta(data, 'movie')
        metacache.set('movie', meta, timedelta(hours=hours))
    except: pass
    return meta

def get_tvshow_meta(id_type, media_id, hours=168):
    metacache = MetaCache()
    meta = None
    data = metacache.get('tvshow', id_type, media_id)
    if data: return data
    try:
        from datetime import timedelta
        data = tmdb_tv_simple
        result = tmdb_tv_simple_external_id
        data = data(media_id) if id_type == 'tmdb_id' else data(result(id_type, media_id)['id'])
        meta = build_meta(data, 'tvshow')
        metacache.set('tvshow', meta, timedelta(hours=hours))
    except: pass
    return meta

def get_season_episodes_meta(media_id, season_no, hours=24):
    metacache = MetaCache()
    meta = None
    data = metacache.get('season', 'tmdb_id', media_id, season_no)
    if data: return data
    try:
        from datetime import timedelta
        meta = tmdb_tv_season_episodes(media_id, season_no)
        meta['tmdb_id'] = media_id
        metacache.set('season', meta, timedelta(hours=hours), season_no)
    except: pass
    return meta

def build_meta(data, db_type):
    meta = {}
    writer = []
    meta['cast'] = []
    meta['castandrole'] = []
    meta['studio'] = []
    meta['all_trailers'] = []
    meta['certification'] = ''
    meta['director'] = ''
    meta['premiered'] = ''
    meta['writer'] = ''
    meta['trailer'] = ''
    meta['tmdb_id'] = data['id'] if 'id' in data else ''
    meta['imdb_id'] = data.get('imdb_id', '') if db_type == 'movie' else data['external_ids'].get('imdb_id', '')
    meta['tvdb_id'] = data['external_ids'].get('tvdb_id', 'None')
    meta['poster'] = "http://image.tmdb.org/t/p/original%s" % data.get('poster_path') if data.get('poster_path') else icon_image
    meta['fanart'] = "http://image.tmdb.org/t/p/original%s" % data.get('backdrop_path') if data.get('backdrop_path') else fanart
    try: meta['year'] = try_parse_int(data['release_date'].split('-')[0]) if db_type == 'movie' else try_parse_int(data['first_air_date'].split('-')[0])
    except: meta['year'] = ''
    meta['duration'] = int(data['runtime'] * 60) if data.get('runtime') else ''
    meta['rating'] = data['vote_average'] if 'vote_average' in data else ''
    try: meta['genre'] = ', '.join([item['name'] for item in data['genres']])
    except: meta['genre'] == []
    meta['plot'] = to_utf8(data['overview']) if 'overview' in data else ''
    meta['title'] = to_utf8(data['title']) if db_type == 'movie' else to_utf8(data['name'])
    meta['tagline'] = to_utf8(data['tagline']) if 'tagline' in data else ''
    meta['votes'] = data['vote_count'] if 'vote_count' in data else ''
    meta['season_data'] = data['seasons'] if 'seasons' in data else ''
    meta['rootname'] = '{0} ({1})'.format(meta['title'], meta['year'])
    if db_type == 'movie':
        if data.get('production_companies'): meta['studio'] = [item['name'] for item in data['production_companies']]
        if data.get('release_date'): meta['premiered'] = data['release_date']
    else:
        try: meta['episode_run_time'] = min(data['episode_run_time']) if 'episode_run_time' in data else ''
        except: meta['episode_run_time'] = 30
        if data.get('networks', None):
            try: meta['studio'] = [item['name'] for item in data['networks']]
            except: meta['studio'] = []
        if data.get('first_air_date', None): meta['premiered'] = data.get('first_air_date', '')
        if data.get('number_of_seasons', None): meta['number_of_seasons'] = data.get('number_of_seasons', '')
        if data.get('number_of_episodes', None): meta['number_of_episodes'] = data.get('number_of_episodes', '')
        if data.get('last_episode_to_air', None): meta['last_episode_to_air'] = data.get('last_episode_to_air', '')
        if data.get('next_episode_to_air', None): meta['next_episode_to_air'] = data.get('next_episode_to_air', '')
        if data.get('in_production', None): meta['in_production'] = data.get('in_production', False) # True, False
        if data.get('status', None): meta['status'] = data.get('status', 'Ended') # Returning Series, Ended
    if 'release_dates' in data:
        for rel_info in data['release_dates']['results']:
            if rel_info['iso_3166_1'] == 'US':
                meta['certification'] = rel_info['release_dates'][0]['certification']
    if 'credits' in data:
        if 'cast' in data['credits']:
            for cast_member in data['credits']['cast']:
                cast_thumb = ''
                if cast_member['profile_path']:
                    cast_thumb = 'http://image.tmdb.org/t/p/original%s' % cast_member['profile_path']
                meta['cast'].append({'name': cast_member['name'], 'role': cast_member['character'], 'thumbnail': cast_thumb})
                meta['castandrole'].append((cast_member['name'], cast_member['character']))
        if 'crew' in data['credits']:
            for crew_member in data['credits']['crew']:
                cast_thumb = ''
                if crew_member['profile_path']:
                    cast_thumb = 'http://image.tmdb.org/t/p/original%s' % crew_member['profile_path']
                if crew_member['job'] in ['Author', 'Writer', 'Screenplay', 'Characters']:
                    writer.append(crew_member['name'])
                if crew_member['job'] == 'Director':
                    meta['director'] = crew_member['name']
            if writer: meta['writer'] = ', '.join(writer)
    if 'videos' in data:
        meta['all_trailers'] = data['videos']['results']
        for video in data['videos']['results']:
            if video['site'] == 'YouTube' and video['type'] == 'Trailer' or video['type'] == 'Teaser':
                meta['trailer'] = 'plugin://plugin.video.youtube/play/?video_id=%s' % video['key']
                break
    return to_utf8(meta)
