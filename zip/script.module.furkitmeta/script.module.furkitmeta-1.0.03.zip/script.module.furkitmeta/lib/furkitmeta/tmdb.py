# -*- coding: utf-8 -*-

import requests, time
from furkitmeta.utils import tmdb_api

tmdb_api = tmdb_api()

def tmdbMovies(tmdb_id):
    url = 'https://api.themoviedb.org/3/movie/%s?api_key=%s&language=en-US&append_to_response=external_ids,videos,credits,release_dates' % (tmdb_id, tmdb_api)
    return getTmdb(url).json()

def tmdbMoviesExternalID(external_source, external_id):
    url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=%s' % (external_id, tmdb_api, external_source)
    return getTmdb(url).json()['movie_results'][0]

def tmdbTVShows(tmdb_id):
    url = 'https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en-US&append_to_response=external_ids,videos,credits' % (tmdb_id, tmdb_api)
    return getTmdb(url).json()

def tmdbTVShowsExternalID(external_source, external_id):
    url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=%s' % (external_id, tmdb_api, external_source)
    return getTmdb(url).json()['tv_results'][0]

def tmdbSeasonEpisodes(tmdb_id, season_no):
    url = 'https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s&language=en-US&append_to_response=credits' % (tmdb_id, int(season_no), tmdb_api)
    return getTmdb(url).json()

def getTmdb(url):
    try:
        def request(url):
            result = requests.get(url)
            response = result.status_code
            return str(response), result
        for i in range(15):
            response, result = request(url)
            if response == '200':
                return result
            elif response == '429':
                time.sleep(10)
                pass
            else:
                return
    except: pass

