# -*- coding: utf-8 -*-

def logger(heading, function):
    import xbmc
    xbmc.log('###%s###: %s' % (heading, function), 2)

def to_utf8(obj):
    import copy
    if isinstance(obj, unicode):
        obj = obj.encode('utf-8', 'ignore')
    elif isinstance(obj, dict):
        obj = copy.deepcopy(obj)
        for key, val in obj.items():
            obj[key] = to_utf8(val)
    elif obj is not None and hasattr(obj, "__iter__"):
        obj = obj.__class__([to_utf8(x) for x in obj])
    else: pass
    return obj

def try_parse_int(string):
    '''helper to parse int from string without erroring on empty or misformed string'''
    try:
        return int(string)
    except Exception:
        return 0

