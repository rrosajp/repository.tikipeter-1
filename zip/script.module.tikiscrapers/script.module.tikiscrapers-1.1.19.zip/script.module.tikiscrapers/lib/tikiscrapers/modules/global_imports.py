# -*- coding: utf-8 -*-

try: from urllib import quote
except ImportError: from urllib.parse import quote
try: from urllib import quote_plus
except ImportError: from urllib.parse import quote_plus
try: from urllib import unquote
except ImportError: from urllib.parse import unquote
try: from urllib import unquote_plus
except ImportError: from urllib.parse import unquote_plus
try: from urlparse import urljoin
except ImportError: from urllib.parse import urljoin
try: from urlparse import urlparse
except ImportError: from urllib.parse import urlparse
try: from urllib import urlencode
except ImportError: from urllib.parse import urlencode
try: from urlparse import parse_qs
except ImportError: from urllib.parse import parse_qs

__all__ = ['quote', 'quote_plus', 'unquote', 'unquote_plus', 'urljoin', 'urlparse', 'urlencode', 'parse_qs']