# -*- coding: UTF-8 -*-
"""
Created by Tempest

****EGGMAN WILL CLAIM THIS AS HIS*****
"""

import requests, urllib, urlparse, json

from furkitscrapers.modules import cfscrape
from furkitscrapers.modules import debrid
from furkitscrapers.modules import source_utils
from furkitscrapers.modules.control import logger


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.base_link = 'https://api.filepursuit.com/'
        self.search_link = '?type=video&q=%s'
        self.scraper = cfscrape.create_scraper()

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return
            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        # try:
        sources = []
        if url == None: return sources
        data = urlparse.parse_qs(url)
        data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
        if 'tvshowtitle' in data: query = '%s S%02dE%02d' %(data['tvshowtitle'], int(data['season']), int(data['episode']))
        else: query = '%s %s' % (data['title'], data['year'])

        url = self.search_link % urllib.quote(query)
        url = self.base_link + self.search_link % query
        url = urlparse.urljoin(self.base_link, url).replace('%20', '-')
        r = self.scraper.get(url).content
        r = json.loads(r)
        for item in results:


        # s = requests.Session()
        # logger('s', s)
        # p = s.get(url)
        # logger('p1', p1)
        # p = json.loads(p.text)
        # logger('p', p)
        # url = client.request(url)
        # url = json.loads(url)
        # logger('url', url)
        # try:
        #     results = client.parseDOM(html, 'div', attrs={'class': 'ava1'})
        # except:
        #     return sources
        # for torrent in results:
        #     link = re.findall('a data-torrent-id=".+?" href="(magnet:.+?)" class=".+?" title="(.+?)"', torrent, re.DOTALL)
        #     for link, name in link:
        #         link = str(client.replaceHTMLCodes(link).split('&tr')[0])
        #         quality, info = source_utils.get_release_quality(name, name)
        #         try:
        #             size = re.findall('((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|MB|MiB))', torrent)[-1]
        #             div = 1 if size.endswith(('GB', 'GiB')) else 1024
        #             size = float(re.sub('[^0-9|/.|/,]', '', size)) / div
        #             size = '%.2f GB' % size
        #             info.append(size)
        #         except Exception:
        #             pass
        #         info = ' | '.join(info)
        #         sources.append({'source': 'Torrent', 'quality': quality, 'language': 'en', 'url': link, 'info': info, 'direct': False, 'debridonly': True})

        return sources
        # except:
            # return sources

    def resolve(self, url):
        return url
