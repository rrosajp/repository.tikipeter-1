# -*- coding: utf-8 -*-

import xbmc
import sys
from utils import build_url
try: from urlparse import parse_qsl
except ImportError: from urllib.parse import parse_qsl

listitem = sys.listitem
path = listitem.getPath()

orig_params = dict(parse_qsl(path.replace('plugin://plugin.video.fen/?','')))

db_type = orig_params['vid_type']

if db_type == 'movie':
	t_y_split = orig_params['query'].split(' (')
	title = t_y_split[0]
	year = t_y_split[1].replace(')', '')
	params = {"mode": "mark_movie_as_watched_unwatched", "action": "mark_as_watched", "media_id": orig_params['tmdb_id'], "title": title, "year": year}
else:
	pass
	t_y_split = orig_params['tvshowtitle'].split(' (')
	title = t_y_split[0]
	year = t_y_split[1].replace(')', '')
	params = {"mode": "mark_episode_as_watched_unwatched", "action": 'mark_as_watched',
				"season": orig_params['season'], "episode": orig_params['episode'], "media_id": orig_params['tmdb_id'],
				"imdb_id": orig_params['imdb_id'], "title": title, "year": year}


xbmc.executebuiltin("RunPlugin(%s)" % build_url(params))
xbmc.sleep(1000)
xbmc.executebuiltin('UpdateLibrary(video,special://skin/foo)')
