# -*- coding: utf-8 -*-

import xbmc
import sys
from utils import build_url
import json
try: from urlparse import parse_qsl
except ImportError: from urllib.parse import parse_qsl

listitem = sys.listitem
path = listitem.getPath()
widget_status = listitem.getProperty("fen_widget")

orig_params = dict(parse_qsl(path.replace('plugin://plugin.video.fen/?','')))

media_type = orig_params.get('vid_type', 'tvshow')
if media_type == 'movie': title = orig_params['query']
else: title = json.loads(orig_params['meta'])['title']
params = {'mode': 'favorites_choice', 'db_type': media_type, 'tmdb_id': orig_params['tmdb_id'], 'title': title}
xbmc.executebuiltin("RunPlugin(%s)" % build_url(params))
