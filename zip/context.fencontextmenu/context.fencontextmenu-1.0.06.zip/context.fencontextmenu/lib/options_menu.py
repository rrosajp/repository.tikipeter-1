# -*- coding: utf-8 -*-

import xbmc
import sys
import json
from utils import build_url
from urlparse import parse_qsl

listitem = sys.listitem
path = listitem.getPath()

orig_params = dict(parse_qsl(path.replace('plugin://plugin.video.fen/?','')))

try:
    options_menu_params = json.loads(listitem.getProperty("fen_options_menu_params"))
    content = orig_params.get('vid_type', None)
    params = {'mode': options_menu_params.get('mode'), 'suggestion': options_menu_params.get('suggestion'),
              'play_params': options_menu_params.get('play_params'), 'content': content}
except:
    params = {'mode': 'options_menu'}
xbmc.executebuiltin("RunPlugin(%s)" % build_url(params))
