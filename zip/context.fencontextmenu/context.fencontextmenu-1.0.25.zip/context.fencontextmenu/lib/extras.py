# -*- coding: utf-8 -*-
from xbmc import executebuiltin
import sys
import json
from utils import build_url

listitem = sys.listitem
extras_menu_params = json.loads(listitem.getProperty("fen_extras_menu_params"))
extras_menu_params['is_widget'] = 'false'
extras_menu_params['is_home'] = 'true'
executebuiltin("RunPlugin(%s)" % build_url(extras_menu_params))
