# -*- coding: utf-8 -*-
from xbmc import executebuiltin
import sys
import json
from utils import build_url

listitem = sys.listitem
meta_json = listitem.getProperty("fen_listitem_meta")
executebuiltin("RunPlugin(%s)" % build_url({'mode': 'play_fetch_random', 'db_type': 'episode', 'meta': meta_json}))
