# -*- coding: utf-8 -*-

from xbmc import executebuiltin
from xbmcaddon import Addon
import sys
import json
from utils import build_url

listitem = sys.listitem
meta_json = listitem.getProperty('fen_listitem_meta')
meta = json.loads(meta_json)
def make_browse_params():
	browse_params = {}
	try:
		total_seasons = meta['total_seasons']
		all_episodes = Addon(id='plugin.video.fen').getSetting('default_all_episodes')
		show_all_episodes = True if all_episodes in ('1', '2') else False
		if show_all_episodes:
			if all_episodes == '1' and total_seasons > 1: browse_params = {'mode': 'build_season_list', 'meta': meta_json, 'tmdb_id': meta['tmdb_id']}
			else: browse_params = {'mode': 'build_episode_list', 'meta': meta_json, 'tmdb_id': meta['tmdb_id'], 'season': 'all'}
		else: browse_params = {'mode': 'build_season_list', 'meta': meta_json, 'tmdb_id': meta['tmdb_id']}
	except: pass
	return browse_params
params = make_browse_params()
executebuiltin('ActivateWindow(Videos,%s)' % build_url(params))