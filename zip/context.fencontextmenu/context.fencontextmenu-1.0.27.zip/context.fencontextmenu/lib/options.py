# -*- coding: utf-8 -*-
from xbmc import executebuiltin
import sys
import json
from utils import build_url

executebuiltin("RunPlugin(%s)" % sys.listitem.getProperty("fen_options_menu_params"))
