# -*- coding: utf-8 -*-
from xbmc import executebuiltin
import sys

params = sys.listitem.getProperty('fen_extras_menu_params')
params += '&is_widget=false&is_home=true'
executebuiltin('RunPlugin(%s)' % params)
