# -*- coding: utf-8 -*-
from xbmc import executebuiltin
import sys

executebuiltin("RunPlugin(%s)" % sys.listitem.getProperty('fen_random_params'))
