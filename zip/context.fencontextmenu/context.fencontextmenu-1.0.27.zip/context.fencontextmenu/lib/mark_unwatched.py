# -*- coding: utf-8 -*-
from xbmc import executebuiltin, sleep
import sys

executebuiltin("RunPlugin(%s)" % sys.listitem.getProperty('fen_unwatched_params'))
sleep(1000)
executebuiltin('UpdateLibrary(video,special://skin/foo)')
