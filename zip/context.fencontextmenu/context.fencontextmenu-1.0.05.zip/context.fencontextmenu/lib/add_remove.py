import xbmc
import sys
from utils import build_url
# import urllib
import json
from urlparse import parse_qsl

# def build_url(query):
#     return 'plugin://plugin.video.fen/?' + urllib.urlencode(query)

listitem = sys.listitem
path = listitem.getPath()
widget_status = listitem.getProperty("fen_widget")

params = dict(parse_qsl(path.replace('plugin://plugin.video.fen/?','')))

if __name__ == '__main__':
    meta = json.loads(params['meta'])
    media_type = params.get('vid_type', 'tvshow')
    xbmc.log('media_type %s' % media_type, 2)
    params = {"mode": "build_add_to_remove_from_list", "media_type": media_type, "meta": params['meta']}
    xbmc.executebuiltin("RunPlugin(%s)" % build_url(params))
