import xbmc
import sys
import json
from utils import build_url
# import urllib
from urlparse import parse_qsl


# def build_url(query):
#     return 'plugin://plugin.video.fen/?' + urllib.urlencode(query)

listitem = sys.listitem
path = listitem.getPath()
orig_params = dict(parse_qsl(path.replace('plugin://plugin.video.fen/?','')))

if __name__ == '__main__':
    try:
        playback_menu_params = json.loads(listitem.getProperty("fen_playback_menu_params"))
        content = orig_params.get('vid_type', None)
        params = {'mode': playback_menu_params.get('mode'), 'suggestion': playback_menu_params.get('suggestion'),
                  'play_params': playback_menu_params.get('play_params'), 'content': content}
    except:
        params = {'mode': 'playback_menu'}
    xbmc.executebuiltin("RunPlugin(%s)" % build_url(params))
