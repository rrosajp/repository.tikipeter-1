import xbmc
import sys

listitem = sys.listitem
widget_status = listitem.getProperty("fen_widget")
path = listitem.getPath()

def library_playback_context_menu():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=playback_kodi_library_menu)')

def furkit_playback_context_menu():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=playback_menu)')

if __name__ == '__main__':
    if widget_status == 'true':
        furkit_playback_context_menu()
    else:
        library_playback_context_menu()
