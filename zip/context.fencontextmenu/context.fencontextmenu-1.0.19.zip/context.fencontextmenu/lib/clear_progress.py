# -*- coding: utf-8 -*-

import xbmc
import sys
from utils import build_url
import json
try: from urlparse import parse_qsl
except ImportError: from urllib.parse import parse_qsl

listitem = sys.listitem
path = listitem.getPath()

orig_params = dict(parse_qsl(path.replace('plugin://plugin.video.fen/?','')))
meta = json.loads(orig_params['meta'])

if orig_params['vid_type'] == 'movie':
    params = {"mode": "watched_unwatched_erase_bookmark", "db_type": "movie",
    			"media_id": meta['tmdb_id'], "refresh": "true"}
else:
    params = {'mode': 'watched_unwatched_erase_bookmark', 'db_type': 'episode', 'media_id': meta['tmdb_id'],
    			'season': meta['season'], 'episode': meta['episode'], 'refresh': 'true'}
xbmc.executebuiltin("RunPlugin(%s)" % build_url(params))
xbmc.sleep(1000)
xbmc.executebuiltin('UpdateLibrary(video,special://skin/foo)')
