# -*- coding: utf-8 -*-

import xbmc
import sys
import json
from utils import build_url

listitem = sys.listitem
meta = json.loads(listitem.getProperty('fen_listitem_meta'))
params = {'mode': 'favorites_choice', 'db_type': meta['mediatype'], 'tmdb_id': meta['tmdb_id'], 'title': meta['rootname']}
xbmc.executebuiltin("RunPlugin(%s)" % build_url(params))
