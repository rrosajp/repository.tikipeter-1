# -*- coding: utf-8 -*-

import xbmc
import sys
import json
from utils import build_url

listitem = sys.listitem
meta = json.loads(listitem.getProperty('fen_listitem_meta'))
params = {'mode': 'build_season_list', 'tmdb_id': meta['tmdb_id']}
xbmc.executebuiltin('ActivateWindow(Videos,%s)' % build_url(params))