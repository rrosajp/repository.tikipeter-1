# -*- coding: utf-8 -*-
import xbmc
import sys
import json
from utils import build_url

listitem = sys.listitem
meta = json.loads(listitem.getProperty('fen_listitem_meta'))
if meta['mediatype'] == 'movie':
	params = {'mode': 'mark_movie_as_watched_unwatched', 'action': 'mark_as_unwatched', 'media_id': meta['tmdb_id'], 'title': meta['title'], 'year': meta['year']}
else:
	params = {'mode': 'mark_episode_as_watched_unwatched', 'action': 'mark_as_unwatched', 'media_id': meta['tmdb_id'], 'imdb_id': meta['imdb_id'], 'tvdb_id': meta['tvdb_id'],
				'season': meta['season'], 'episode': meta['episode'],  'title': meta['title'], 'year': meta['year']}
xbmc.executebuiltin("RunPlugin(%s)" % build_url(params))
xbmc.sleep(1000)
xbmc.executebuiltin('UpdateLibrary(video,special://skin/foo)')
