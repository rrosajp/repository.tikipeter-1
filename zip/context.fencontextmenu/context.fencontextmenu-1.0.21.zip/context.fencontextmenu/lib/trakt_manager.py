# -*- coding: utf-8 -*-

import xbmc
import sys
from utils import build_url
try: from urlparse import parse_qsl
except ImportError: from urllib.parse import parse_qsl

listitem = sys.listitem
path = listitem.getPath()
widget_status = listitem.getProperty("fen_widget")

orig_params = dict(parse_qsl(path.replace('plugin://plugin.video.fen/?','')))

media_type = orig_params.get('vid_type', 'tvshow')
params = {'mode': 'trakt_manager_choice', 'tmdb_id': orig_params['tmdb_id'], 'imdb_id': orig_params['imdb_id'], 'tvdb_id': orig_params.get('tvdb_id', 'None'), 'db_type': media_type}
xbmc.executebuiltin("RunPlugin(%s)" % build_url(params))
