# -*- coding: utf-8 -*-
import xbmc
import sys
import json
from utils import build_url

listitem = sys.listitem
meta = json.loads(listitem.getProperty('fen_listitem_meta'))
if meta['mediatype'] == 'movie':
    params = {"mode": "watched_unwatched_erase_bookmark", "db_type": "movie",
    			"media_id": meta['tmdb_id'], "refresh": "true"}
else:
    params = {'mode': 'watched_unwatched_erase_bookmark', 'db_type': 'episode', 'media_id': meta['tmdb_id'],
    			'season': meta['season'], 'episode': meta['episode'], 'refresh': 'true'}
xbmc.executebuiltin("RunPlugin(%s)" % build_url(params))
xbmc.sleep(1000)
xbmc.executebuiltin('UpdateLibrary(video,special://skin/foo)')
