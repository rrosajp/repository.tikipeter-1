# -*- coding: utf-8 -*-
import xbmc

xbmc.executebuiltin('UpdateLibrary(video,special://skin/foo)')
