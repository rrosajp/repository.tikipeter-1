# -*- coding: utf-8 -*-
import xbmc
import sys
import json
from utils import build_url

listitem = sys.listitem
meta = json.loads(listitem.getProperty('fen_listitem_meta'))
params = {'mode': 'trakt_manager_choice', 'tmdb_id': meta['tmdb_id'], 'imdb_id': meta['imdb_id'], 'tvdb_id': meta.get('tvdb_id', 'None'), 'db_type': meta['mediatype']}
xbmc.executebuiltin("RunPlugin(%s)" % build_url(params))
