
import xbmcaddon, xbmcvfs, xbmcgui
import re
import json
import os
try: from urlparse import urlparse
except ImportError: from urllib.parse import urlparse
from resources.lib.modules.utils import get_release_quality, get_file_info, clean_file_name, replace_html_codes
from resources.lib.modules import settings
# from resources.lib.modules.utils import logger

__addon__ = xbmcaddon.Addon(id='plugin.video.fen')
window = xbmcgui.Window(10000)

class DownloadsSource:
    def __init__(self):
        self.scrape_provider = 'downloads'
        self.sources = []
        self.provider_color = settings.provider_color(self.scrape_provider)
        self.second_line_color = __addon__.getSetting('secondline.identify')
        if self.second_line_color == 'No Color': self.second_line_color = self.provider_color
        self.show_extra_info = settings.show_extra_info()
        self.show_filenames = settings.show_filenames()

    def results(self, info):
        self.info = info
        self.db_type = self.info.get("db_type")
        self.download_path = settings.download_directory(self.db_type)
        self.title = self.info.get("title")
        self.year = self.info.get("year")
        self.season = self.info.get("season")
        self.episode = self.info.get("episode")
        self.file_dl = self._get_video(self.db_type, self.title, self.year, self.season, self.episode)
        if not self.file_dl: return self.sources
        self._label_settings()
        self.size = self._get_size(self.file_dl)
        self.details = get_file_info(self.file_name)
        self.video_quality = get_release_quality(self.file_name, self.file_dl)
        labels = self._build_label()
        label = labels[0]
        multiline_label = labels[1]
        self.sources.append({'name': self.file_name,
                            'label': label,
                            'multiline_label': multiline_label,
                            'title': self.file_name,
                            'quality': self.video_quality,
                            'size': self.size,
                            'url_dl': self.file_dl,
                            'id': self.file_dl,
                            'downloads': True,
                            'direct': True,
                            'source': self.scrape_provider,
                            'scrape_provider': self.scrape_provider})

        window.setProperty('downloads_source_results', json.dumps(self.sources))
        
        return self.sources

    def _get_video(self, db_type, title, year, season=None, episode=None):
        try:
            file_fetcher = self._fetch_movie if self.db_type == 'movie' else self._fetch_episode
            match = None
            try:
                dirs, files = xbmcvfs.listdir(self.download_path)
                for item in dirs:
                    match = self._match_media(item)
                    if match:
                        break
            except: pass
            if not match: return None
            result = file_fetcher(match)
            return result
        except: pass

    def _match_media(self, item):
        if clean_file_name(self.title).lower() in clean_file_name(item).lower():
            if self.db_type == 'movie':
                if item.split('(')[1][:4] in self._year_query_list():
                    return item
            else:
                return item
        else:
            return None

    def _fetch_movie(self, item):
        match = None
        movie_path = os.path.join(self.download_path, item)
        dirs, files = xbmcvfs.listdir(movie_path)
        for item in files:
            ext = os.path.splitext(urlparse(item).path)[1][1:]
            if ext in ['mp4', 'mkv', 'flv', 'avi', 'mpg']:
                match = item
                if match:
                    self.file_name = match
                    break
        if not match: return None
        url_path = os.path.join(movie_path, match)
        return url_path

    def _fetch_episode(self, item):
        match = None
        season_queries = self._season_query_list()
        season_path = os.path.join(self.download_path, item)
        dirs, files = xbmcvfs.listdir(season_path)
        for item in dirs:
            if item.lower() in season_queries:
                match = item
                if match:
                    break
        if not match: return None
        episode_path = os.path.join(season_path, match)
        queries = self._episode_query_list()
        match = None
        dirs, files = xbmcvfs.listdir(episode_path)
        for item in files:
            ext = os.path.splitext(urlparse(item).path)[1][1:]
            if ext.lower() in ['mp4', 'mkv', 'flv', 'avi', 'mpg']:
                if any(i in item.lower() for i in queries):
                    match = item
                    if match:
                        self.file_name = match
                        break
        if not match: return None
        url_path = os.path.join(episode_path, match)
        return url_path

    def _get_size(self, file):
        f = xbmcvfs.File(file) ; s = f.size() ; f.close()
        size = float(s)/1073741824
        return size

    def _year_query_list(self):
        return (str(self.year), str(int(self.year)+1), str(int(self.year)-1))

    def _season_query_list(self):
        return ['season %02d' % int(self.season), 'season %s' % self.season]

    def _episode_query_list(self):
        return ['s%02de%02d' % (int(self.season), int(self.episode)),
                '%dx%02d' % (int(self.season), int(self.episode)),
                '%02dx%02d' % (int(self.season), int(self.episode)),
                'season%02depisode%02d' % (int(self.season), int(self.episode)),
                'season%depisode%02d' % (int(self.season), int(self.episode)),
                'season%depisode%d' % (int(self.season), int(self.episode))]

    def _label_settings(self):
        if self.provider_color == '':
            self.leading = self.closing = ''
            if self.second_line_color == '': self.multi_closing = ''
            else: self.multi_closing = '[/COLOR]'
        else:
            self.leading = '[COLOR %s]' % self.provider_color
            if self.second_line_color == '':
                self.closing = ''
            else:
                self.closing = '[/COLOR]'
            self.multi_closing = '[/COLOR]'

        if self.second_line_color == '':
            self.multi_leading = self.multiLineClosing = ''
        else:
            self.multi_leading = '[COLOR %s]' % self.second_line_color
            self.multiLineClosing = '[/COLOR]'

    def _build_label(self, uncached=False, active_download=False):
        if self.show_filenames: filename = self.file_name.replace('.', ' ')
        else: filename = ''
        if self.show_extra_info: details = self.details
        else: details = ''
        label = '[B]DOWN[/B] | [I][B]%s[/B][/I] | %.2f GB' % (self.video_quality, self.size)
        multiline_label1 = '[B]DOWN[/B] | [I][B]%s[/B][/I] | %.2f GB' % (self.video_quality, self.size)
        if self.show_extra_info: label += ' | %s' % details
        multiline_label2 = ''
        if self.show_filenames:
            label += ' | %s' % filename
            multiline_label1 += ' | %s' % details
            multiline_label2 += '\n        %s' % filename
        else:
            multiline_label2 += '\n        %s' % details
        label = label.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
        label = re.sub('\[I\]\s+\[/I\]', ' ', label)
        label = re.sub('\|\s+\|', '|', label)
        label = re.sub('\|(?:\s+|)$', '', label)
        label = label.upper()
        multiline_label1 = multiline_label1.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
        multiline_label1 = re.sub('\[I\]\s+\[/I\]', ' ', multiline_label1)
        multiline_label1 = re.sub('\|\s+\|', '|', multiline_label1)
        multiline_label1 = re.sub('\|(?:\s+|)$', '', multiline_label1)
        multiline_label1 = multiline_label1.upper()
        if multiline_label2 != '':
            multiline_label2 = multiline_label2.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
            multiline_label2 = re.sub('\[I\]\s+\[/I\]', ' ', multiline_label2)
            multiline_label2 = re.sub('\|\s+\|', '|', multiline_label2)
            multiline_label2 = re.sub('\|(?:\s+|)$', '', multiline_label2)
            multiline_label2 = multiline_label2.upper()
        label = self.leading + label + self.closing
        multiline_label = self.leading + multiline_label1 + self.closing + self.multi_leading + multiline_label2 + self.multi_closing
        return label, multiline_label
