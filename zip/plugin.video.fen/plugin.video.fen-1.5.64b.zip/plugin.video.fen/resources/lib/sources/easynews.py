import xbmcaddon, xbmcgui
import re
import json
from resources.lib.apis.easynews_api import EasyNewsAPI
from resources.lib.modules.utils import get_release_quality, get_file_info, replace_html_codes, clean_file_name
from resources.lib.modules import settings
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.fen'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
window = xbmcgui.Window(10000)
EasyNews = EasyNewsAPI()

class EasyNewsSource:
    def __init__(self):
        self.scrape_provider = 'easynews'
        self.sources = []
        self.provider_color = settings.provider_color(self.scrape_provider)
        self.second_line_color = __addon__.getSetting('secondline.identify')
        if self.second_line_color == 'No Color': self.second_line_color = self.provider_color
        self.show_extra_info = settings.show_extra_info()
        self.show_filenames = settings.show_filenames()
        self.max_results = int(__addon__.getSetting('easynews_limit'))
        self.max_gb = __addon__.getSetting('easynews_maxgb')
        self.max_bytes = int(self.max_gb) * 1024 * 1024 * 1024

    def results(self, info):
        self.info = info
        search_name = self._search_name()
        files = EasyNews.search(search_name)
        files = files[0:self.max_results]
        self._label_settings()
        for item in files:
            try:
                if self.max_bytes:
                    match = re.search('([\d.]+)\s+(.*)', item['size'])
                    if match:
                        size_bytes = self.to_bytes(*match.groups())
                        if size_bytes > self.max_bytes:
                            continue
                self.file_name = item['name']
                self.file_dl = item['url_dl']
                self.size = float(int(item['rawSize']))/1073741824
                self.details = get_file_info(self.file_name)
                self.video_quality = get_release_quality(self.file_name, self.file_dl)
                labels = self._build_label()
                label = labels[0]
                multiline_label = labels[1]
                self.sources.append({'name': self.file_name,
                                'label': label,
                                'multiline_label': multiline_label,
                                'quality': self.video_quality,
                                'size': self.size,
                                'url_dl': self.file_dl,
                                'id': self.file_dl,
                                'local': False,
                                'direct': True,
                                'source': self.scrape_provider,
                                'scrape_provider': self.scrape_provider})
            except: pass

        window.setProperty('easynews_source_results', json.dumps(self.sources))

        return self.sources

    def _search_name(self):
        search_title = clean_file_name(self.info.get("title"))
        db_type = self.info.get("db_type")
        year = self.info.get("year")
        years = '%s,%s,%s' % (str(int(year - 1)), year, str(int(year + 1)))
        season = self.info.get("season")
        episode = self.info.get("episode")
        if db_type == 'movie': search_name = '"%s" %s' % (search_title, years)
        else: search_name = '%s S%02dE%02d' % (search_title,  int(season), int(episode))
        return search_name

    def to_bytes(self, num, unit):
        unit = unit.upper()
        if unit.endswith('B'): unit = unit[:-1]
        units = ['', 'K', 'M', 'G', 'T', 'P', 'E', 'Z']
        try: mult = pow(1024, units.index(unit))
        except: mult = sys.maxint
        return int(float(num) * mult)

    def _label_settings(self):
        if self.provider_color == '':
            self.leading = self.closing = ''
            if self.second_line_color == '': self.multi_closing = ''
            else: self.multi_closing = '[/COLOR]'
        else:
            self.leading = '[COLOR %s]' % self.provider_color
            if self.second_line_color == '':
                self.closing = ''
            else:
                self.closing = '[/COLOR]'
            self.multi_closing = '[/COLOR]'

        if self.second_line_color == '':
            self.multi_leading = self.multiLineClosing = ''
        else:
            self.multi_leading = '[COLOR %s]' % self.second_line_color
            self.multiLineClosing = '[/COLOR]'

    def _build_label(self, uncached=False, active_download=False):
        if self.show_filenames: filename = self.file_name.replace('.', ' ')
        else: filename = ''
        if self.show_extra_info: details = self.details
        else: details = ''
        label = '[B]EASY[/B] | [I][B]%s[/B][/I] | %.2f GB' % (self.video_quality, self.size)
        multiline_label1 = '[B]EASY[/B] | [I][B]%s[/B][/I] | %.2f GB' % (self.video_quality, self.size)
        if self.show_extra_info: label += ' | %s' % details
        multiline_label2 = ''
        if self.show_filenames:
            label += ' | %s' % filename
            multiline_label1 += ' | %s' % details
            multiline_label2 += '\n        %s' % filename
        else:
            multiline_label2 += '\n        %s' % details
        label = label.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
        label = re.sub('\[I\]\s+\[/I\]', ' ', label)
        label = re.sub('\|\s+\|', '|', label)
        label = re.sub('\|(?:\s+|)$', '', label)
        label = label.upper()
        multiline_label1 = multiline_label1.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
        multiline_label1 = re.sub('\[I\]\s+\[/I\]', ' ', multiline_label1)
        multiline_label1 = re.sub('\|\s+\|', '|', multiline_label1)
        multiline_label1 = re.sub('\|(?:\s+|)$', '', multiline_label1)
        multiline_label1 = multiline_label1.upper()
        if multiline_label2 != '':
            multiline_label2 = multiline_label2.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
            multiline_label2 = re.sub('\[I\]\s+\[/I\]', ' ', multiline_label2)
            multiline_label2 = re.sub('\|\s+\|', '|', multiline_label2)
            multiline_label2 = re.sub('\|(?:\s+|)$', '', multiline_label2)
            multiline_label2 = multiline_label2.upper()
        label = self.leading + label + self.closing
        multiline_label = self.leading + multiline_label1 + self.closing + self.multi_leading + multiline_label2 + self.multi_closing
        return label, multiline_label

