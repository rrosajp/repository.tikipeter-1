# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcplugin, xbmcgui, xbmcvfs
import sys, os
try: from urllib import unquote
except ImportError: from urllib.parse import unquote
import json
import re
try: from urlparse import parse_qsl
except ImportError: from urllib.parse import parse_qsl
from resources.lib.apis.opensubtitles_api import OpenSubtitlesAPI
from resources.lib.modules.indicators_bookmarks import detect_bookmark, erase_bookmark
from resources.lib.modules.nav_utils import hide_busy_dialog, close_all_dialog, notification, remove_unwanted_info_keys
from resources.lib.modules.utils import sec2time
from resources.lib.modules import settings
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.fen'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__handle__ = int(sys.argv[1])
window = xbmcgui.Window(10000)

class FenPlayer(xbmc.Player):
    def __init__ (self):
        xbmc.Player.__init__(self)
        self.set_resume = settings.set_resume()
        self.set_watched = settings.set_watched()
        self.autoplay_nextep = settings.autoplay_next_episode()
        self.nextep_threshold = settings.nextep_threshold()
        self.nextep_info = None
        self.delete_nextep_playcount = True
        self.subs_searched = False

    def run(self, url=None):
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        rootname = params.get('rootname', '')
        url = url if url else params.get("url") if 'url' in params else None
        url = unquote(url)
        if not url: return
        try:
            if rootname in ('video', 'music'):
                p_list = xbmc.PLAYLIST_VIDEO if rootname == 'video' else xbmc.PLAYLIST_MUSIC
                playlist = xbmc.PlayList(p_list)
                playlist.clear()
                listitem = xbmcgui.ListItem(path=url)
                listitem.setInfo(type=rootname, infoLabels={})
                playlist.add(url, listitem)
                return self.play(playlist)
            self.meta = json.loads(window.getProperty('fen_media_meta'))
            rootname = self.meta['rootname'] if 'rootname' in self.meta else ''
            bookmark = self.bookmarkChoice()
            if bookmark == -1: return
            self.meta.update({'url': url, 'bookmark': bookmark})
            listitem = xbmcgui.ListItem(path=url)
            try:
                if self.meta.get('use_animated_poster', False): poster = self.meta.get('gif_poster')
                else: poster = self.meta.get('poster')
                listitem.setProperty('StartPercent', str(self.meta.get('bookmark')))
                listitem.setArt({'poster': poster, 'fanart': self.meta.get('fanart'),
                                'banner': self.meta.get('banner'), 'clearlogo': self.meta.get('clearlogo'),
                                'landscape': self.meta.get('landscape'), 'discart': self.meta.get('discart')})
                listitem.setCast(self.meta['cast'])
                if self.meta['vid_type'] == 'movie':
                    listitem.setInfo(
                        'video', {'mediatype': 'movie', 'trailer': str(self.meta['trailer']),
                        'title': self.meta['title'], 'size': '0', 'duration': self.meta['duration'],
                        'plot': self.meta['plot'], 'rating': self.meta['rating'], 'premiered': self.meta['premiered'],
                        'studio': self.meta['studio'],'year': self.meta['year'], 'genre': self.meta['genre'],
                        'tagline': self.meta['tagline'], 'code': self.meta['imdb_id'], 'imdbnumber': self.meta['imdb_id'],
                        'director': self.meta['director'], 'writer': self.meta['writer'], 'votes': self.meta['votes']})
                elif self.meta['vid_type'] == 'episode':
                    listitem.setInfo(
                        'video', {'mediatype': 'episode', 'trailer': str(self.meta['trailer']), 'title': self.meta['ep_name'], 'imdbnumber': self.meta['imdb_id'],
                        'tvshowtitle': self.meta['title'], 'size': '0', 'plot': self.meta['plot'], 'year': self.meta['year'], 'votes': self.meta['votes'],
                        'premiered': self.meta['premiered'], 'studio': self.meta['studio'], 'genre': self.meta['genre'], 'season': int(self.meta['season']),
                        'episode': int(self.meta['episode']), 'duration': str(self.meta['duration']), 'rating': self.meta['rating']})
            except: pass
            try:
                self.play(url, listitem)
            except:
                xbmcplugin.setResolvedUrl(__handle__, True, listitem)
            self.monitor()
        except: return

    def bookmarkChoice(self):
        season = self.meta.get('season', '')
        episode = self.meta.get('episode', '')
        if season == 0: season = ''
        if episode == 0: episode = ''
        bookmark = 0
        try: resume_point, curr_time = detect_bookmark(self.meta['vid_type'], self.meta['media_id'], season, episode)
        except: resume_point = 0
        resume_check = float(resume_point)
        if resume_check > 0:
            percent = str(resume_point)
            raw_time = float(curr_time)
            time = sec2time(raw_time, n_msec=0)
            bookmark = self.getResumeStatus(time, percent, bookmark, self.meta.get('from_library', None))
            if bookmark == 0: erase_bookmark(self.meta['vid_type'], self.meta['media_id'], season, episode)
        return bookmark

    def getResumeStatus(self, time, percent, bookmark, from_library):
        if settings.auto_resume(): return percent
        dialog = xbmcgui.Dialog()
        xbmc.sleep(600)
        choice = dialog.contextmenu(['Resume from [B]%s[/B]' % time, 'Start from Beginning'])
        return percent if choice == 0 else bookmark if choice == 1 else -1

    def monitor(self):
        self.library_setting = 'library' if 'from_library' in self.meta else None
        self.autoplay_next_episode = True if self.meta['vid_type'] == 'episode' and self.autoplay_nextep else False
        while not self.isPlayingVideo():
            xbmc.sleep(100)
        close_all_dialog()
        while self.isPlayingVideo():
            try:
                if not self.subs_searched: self.fetch_subtitles()
                self.total_time = self.getTotalTime()
                self.curr_time = self.getTime()
                xbmc.sleep(1000)
                if self.autoplay_next_episode:
                    current_point = round(float(self.curr_time/self.total_time*100),1)
                    if current_point >= self.nextep_threshold:
                        if not self.nextep_info:
                            self.nextEpPrep()
                        else: pass
            except: pass
        return self.mediaWatchedMarker()

    def mediaWatchedMarker(self):
        try:
            resume_point = round(float(self.curr_time/self.total_time*100),1)
            if self.set_resume < resume_point < self.set_watched:
                from resources.lib.modules.indicators_bookmarks import set_bookmark
                return set_bookmark(self.meta['vid_type'], self.meta['media_id'], self.curr_time, self.total_time, self.meta.get('season', ''), self.meta.get('episode', ''))
            elif resume_point > self.set_watched:
                if self.meta['vid_type'] == 'movie':
                    from resources.lib.modules.indicators_bookmarks import mark_movie_as_watched_unwatched
                    watched_function = mark_movie_as_watched_unwatched
                    watched_params = {"mode": "mark_movie_as_watched_unwatched", "action": 'mark_as_watched',
                    "media_id": self.meta['media_id'], "title": self.meta['title'], "year": self.meta['year'],
                    "refresh": 'false', 'from_playback': 'true'}
                else:
                    from resources.lib.modules.indicators_bookmarks import mark_episode_as_watched_unwatched
                    watched_function = mark_episode_as_watched_unwatched
                    watched_params = {"mode": "mark_episode_as_watched_unwatched", "action": "mark_as_watched",
                    "season": self.meta['season'], "episode": self.meta['episode'], "media_id": self.meta['media_id'],
                    "title": self.meta['title'], "year": self.meta['year'], "imdb_id": self.meta['imdb_id'],
                    "tvdb_id": self.meta["tvdb_id"], "refresh": 'false', 'from_playback': 'true'}
                return watched_function(watched_params)
            else: pass
        except: pass

    def nextEpPrep(self):
        auto_nextep_limit_reached = False
        autoplay_next_check_threshold = settings.autoplay_next_check_threshold()
        try: current_number = int(window.getProperty('current_autoplay_next_number'))
        except: current_number = 1
        if autoplay_next_check_threshold != 0:
            if current_number == autoplay_next_check_threshold:
                auto_nextep_limit_reached = True
                continue_playing = xbmcgui.Dialog().yesno('Fen Next Episode', '[B]Are you still watching %s?[/B]' % self.meta['title'], '', '', 'Not Watching', 'Still Watching', 10000)
                if not continue_playing == 1:
                    from resources.lib.modules.nav_utils import notification
                    notification('Fen Next Episode Cancelled', 6000)
                    self.nextep_info = {'pass': True}
        if not self.nextep_info:
            from resources.lib.modules.next_episode import nextep_playback_info, nextep_play
            self.nextep_info = nextep_playback_info(self.meta['tmdb_id'], int(self.meta['season']), int(self.meta['episode']), self.library_setting)
            if not self.nextep_info.get('pass', False):
                if not auto_nextep_limit_reached: self.delete_nextep_playcount = False
                window.setProperty('current_autoplay_next_number', str(current_number+1))
                nextep_play(self.nextep_info)

    def fetch_subtitles(self):
        self.subs_searched = True
        season = int(self.meta['season']) if self.meta['vid_type'] == 'episode' else None
        episode = int(self.meta['episode']) if self.meta['vid_type'] == 'episode' else None
        try: Subtitles().get(self.meta['title'], self.meta['imdb_id'], season, episode)
        except: pass

    def onAVStarted(self):
        try: close_all_dialog()
        except: pass

    def onPlayBackStarted(self):
        try: close_all_dialog()
        except: pass

    def onPlayBackEnded(self):
        try:
            xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
            xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
        except: pass

    def onPlayBackStopped(self):
        try:
            xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
            xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
        except: pass

    def playAudioAlbum(self, t_files=None, name=None, from_seperate=False):
        import os
        import xbmcaddon
        from resources.lib.modules.utils import clean_file_name, batch_replace, to_utf8
        from resources.lib.modules.nav_utils import setView
        __addon_id__ = 'plugin.video.fen'
        __addon__ = xbmcaddon.Addon(id=__addon_id__)
        __handle__ = int(sys.argv[1])
        addon_dir = xbmc.translatePath(__addon__.getAddonInfo('path'))
        icon_directory = settings.get_theme()
        default_furk_icon = os.path.join(icon_directory, 'furk.png')
        formats = ('.3gp', ''), ('.aac', ''), ('.flac', ''), ('.m4a', ''), ('.mp3', ''), \
        ('.ogg', ''), ('.raw', ''), ('.wav', ''), ('.wma', ''), ('.webm', ''), ('.ra', ''), ('.rm', '')
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        furk_files_list = []
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        playlist.clear()
        if from_seperate: t_files = [i for i in t_files if clean_file_name(i['path']) == params.get('item_path')]
        for item in t_files:
            try:
                name = item['path'] if not name else name
                if not 'audio' in item['ct']: continue
                url = item['url_dl']
                track_name = clean_file_name(batch_replace(to_utf8(item['name']), formats))
                listitem = xbmcgui.ListItem(track_name)
                listitem.setThumbnailImage(default_furk_icon)
                listitem.setInfo(type='music',infoLabels={'title': track_name, 'size': int(item['size']), 'album': clean_file_name(batch_replace(to_utf8(name), formats)),'duration': item['length']})
                listitem.setProperty('mimetype', 'audio/mpeg')
                playlist.add(url, listitem)
                if from_seperate: furk_files_list.append((url, listitem, False))
            except: pass
        self.play(playlist)
        if from_seperate:
            xbmcplugin.addDirectoryItems(__handle__, furk_files_list, len(furk_files_list))
            setView('view.furk_files')
            xbmcplugin.endOfDirectory(__handle__)

class Subtitles:
    def __init__(self):
        self.auto_subs = settings.auto_subs()
        self.opensubtitles = OpenSubtitlesAPI()
        self.settings_language = __addon__.getSetting('subtitles.language')
        self.show_notification = __addon__.getSetting('subtitles.show_notification')
        self.quality = ['bluray', 'hdrip', 'brrip', 'bdrip', 'dvdrip', 'webdl', 'webrip', 'webcap', 'web', 'hdtv', 'hdrip']
        self.language_dict = {
            'Afrikaans': 'afr', 'Albanian': 'alb', 'Arabic': 'ara', 'Armenian': 'arm',
            'Basque': 'baq', 'Bengali': 'ben', 'Bosnian': 'bos', 'Breton': 'bre',
            'Bulgarian': 'bul', 'Burmese': 'bur', 'Catalan': 'cat', 'Chinese': 'chi',
            'Croatian': 'hrv', 'Czech': 'cze', 'Danish': 'dan', 'Dutch': 'dut',
            'English': 'eng', 'Esperanto': 'epo', 'Estonian': 'est', 'Finnish': 'fin',
            'French': 'fre', 'Galician': 'glg', 'Georgian': 'geo', 'German': 'ger',
            'Greek': 'ell', 'Hebrew': 'heb', 'Hindi': 'hin', 'Hungarian': 'hun',
            'Icelandic': 'ice', 'Indonesian': 'ind', 'Italian': 'ita', 'Japanese': 'jpn',
            'Kazakh': 'kaz', 'Khmer': 'khm', 'Korean': 'kor', 'Latvian': 'lav',
            'Lithuanian': 'lit', 'Luxembourgish': 'ltz', 'Macedonian': 'mac', 'Malay': 'may',
            'Malayalam': 'mal', 'Manipuri': 'mni', 'Mongolian': 'mon', 'Montenegrin': 'mne',
            'Norwegian': 'nor', 'Occitan': 'oci', 'Persian': 'per', 'Polish': 'pol',
            'Portuguese': 'por', 'Portuguese(Brazil)': 'pob', 'Romanian': 'rum',
            'Russian': 'rus', 'Serbian': 'scc', 'Sinhalese': 'sin', 'Slovak': 'slo',
            'Slovenian': 'slv', 'Spanish': 'spa', 'Swahili': 'swa', 'Swedish': 'swe',
            'Syriac': 'syr', 'Tagalog': 'tgl', 'Tamil': 'tam', 'Telugu': 'tel',
            'Thai': 'tha', 'Turkish': 'tur', 'Ukrainian': 'ukr', 'Urdu': 'urd'}

    def get(self, query, imdb_id, season, episode):
        def _notification(line, time=3500):
            if self.show_notification: return notification(line, time)
            else: return
        if not self.auto_subs: return
        xbmc.sleep(2000)
        language = self.language_dict[self.settings_language]
        try: available_sub_language = xbmc.Player().getSubtitles()
        except: available_sub_language = ''
        if available_sub_language == language: return _notification('Local Subtitles Found')
        _notification('Searching OPENSUBTITLES...')
        chosen_sub = None
        imdb_id = re.sub('[^0-9]', '', imdb_id)
        result = self.opensubtitles.search(query, imdb_id, language, season, episode)
        if not result or len(result) == 0: return _notification('No Subtitles Found')
        try: video_path = xbmc.Player().getPlayingFile()
        except: video_path = ''
        try: chosen_sub = [i for i in result if i['MovieReleaseName'].lower() in video_path.lower() and i['SubLanguageID'] == language and i['SubSumCD'] == '1'][0]
        except: pass
        if not chosen_sub:
            fmt = re.split('\.|\(|\)|\[|\]|\s|\-', video_path)
            fmt = [i.lower() for i in fmt]
            fmt = [i for i in fmt if i in self.quality]
            if season and fmt == '': fmt = 'hdtv'
            result = [i for i in result if i['SubSumCD'] == '1']
            filter = [i for i in result if i['SubLanguageID'] == language and any(x in i['MovieReleaseName'].lower() for x in fmt) and any(x in i['MovieReleaseName'].lower() for x in self.quality)]
            filter += [i for i in result if any(x in i['MovieReleaseName'].lower() for x in self.quality)]
            filter += [i for i in result if i['SubLanguageID'] == language]
            if len(filter) > 0: chosen_sub = filter[0]
            else: chosen_sub = result[0]; _notification('No Suitable Subtitles Found. Loading First Result')
        try: lang = xbmc.convertLanguage(chosen_sub['SubLanguageID'], xbmc.ISO_639_1)
        except: lang = chosen_sub['SubLanguageID']
        subtitle = xbmc.translatePath('special://temp/')
        subtitle = os.path.join(subtitle, 'FEN_Subs.%s.srt' % lang)
        download_url = chosen_sub['SubDownloadLink']
        content = self.opensubtitles.download(download_url)
        file = xbmcvfs.File(subtitle, 'w')
        file.write(str(content))
        file.close()
        xbmc.sleep(1000)
        return xbmc.Player().setSubtitles(subtitle)






