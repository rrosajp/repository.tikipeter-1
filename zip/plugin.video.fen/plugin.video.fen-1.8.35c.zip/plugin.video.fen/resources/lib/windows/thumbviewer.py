# -*- coding: utf-8 -*-
from windows.base_dialog import BaseDialog
# from modules.utils import logger

class ThumbViewerXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		super(ThumbViewerXML, self).__init__(self, args)
		self.window_id = 2000
		self.image_info = kwargs.get('image_info')
		self.rolling_count = kwargs.get('rolling_count')
		self.all_images_json = kwargs.get('all_images_json')

	def onInit(self):
		super(ThumbViewerXML, self).onInit()
		self.make_items()
		win = self.getControl(self.window_id)
		win.addItems(self.item_list)
		self.set_properties()
		self.setFocusId(self.window_id)

	def run(self):
		self.doModal()

	def onAction(self, action):
		if action in self.closing_actions:
			self.close()

	def set_properties(self):
		self.setProperty('tikiskins.all_images', self.all_images)

	def make_items(self):
		def builder():
			for item in self.image_results:
		self.item_list = list(builder())