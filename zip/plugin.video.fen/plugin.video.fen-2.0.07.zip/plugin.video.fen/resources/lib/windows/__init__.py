# -*- coding: utf-8 -*-

from modules.utils import manual_function_import
# from modules.utils import logger

def open_window(import_info, *args, **kwargs):
	'''
	import_info: Tuple with ('module', 'function')
	'''
	try:
		function = manual_function_import(import_info[0], import_info[1])
		window = function(*args, **kwargs)
		choice = window.run()
		del window
		return choice
	except Exception as e:
		from modules.kodi_utils import notification
		from modules.utils import local_string as ls, logger
		logger('error in open_window', str(e))
		return notification(ls(32574))
