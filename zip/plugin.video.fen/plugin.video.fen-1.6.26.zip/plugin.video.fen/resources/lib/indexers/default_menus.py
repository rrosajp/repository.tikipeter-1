
class DefaultMenus:
    
    def RootList(self):
        return [
            {
                "iconImage": "movies.png", 
                "mode": "navigator.main",
                "action": "MovieList",
                "name": 32028, 
                "foldername": "Movies"
            }, 
            {
                "iconImage": "tv.png", 
                "mode": "navigator.main",
                "action": "TVShowList",
                "name": 32029, 
                "foldername": "TV Shows"
            }, 
            {
                "iconImage": "search.png", 
                "mode": "navigator.search", 
                "name": 32450, 
                "foldername": "Search"
            }, 
            {
                "iconImage": "discover.png", 
                "mode": "navigator.discover_main", 
                "name": 32451, 
                "foldername": "Discover"
            }, 
            {
                "name": 32452, 
                "iconImage": "genre_comedy.png", 
                "foldername": "Popular People", 
                "mode": "build_popular_people"
            }, 
            {
                "iconImage": "favourites.png", 
                "mode": "navigator.favourites", 
                "name": 32453, 
                "foldername": "Favourites"
            }, 
            {
                "iconImage": "library.png", 
                "mode": "navigator.subscriptions", 
                "name": 32194, 
                "foldername": "Subscriptions Root"
            }, 
            {
                "iconImage": "library_kodi.png", 
                "mode": "navigator.kodi_library", 
                "name": 32100, 
                "foldername": "Kodi Library Root"
            }, 
            {
                "iconImage": "downloads.png", 
                "mode": "navigator.downloads", 
                "name": 32107, 
                "foldername": "Fen Downloads"
            }, 
            {
                "iconImage": "lists.png", 
                "mode": "navigator.my_content", 
                "name": 32454, 
                "foldername": "My Lists"
            }, 
            {
                "iconImage": "premium.png", 
                "mode": "navigator.premium", 
                "name": 32455, 
                "foldername": "My Services"
            }, 
            {
                "iconImage": "settings2.png", 
                "mode": "navigator.tools", 
                "name": 32456, 
                "foldername": "Tools"
            }, 
            {
                "iconImage": "settings.png", 
                "mode": "navigator.settings", 
                "name": 32247, 
                "foldername": "Settings"
            }
        ]

    def MovieList(self):
        return [
            {
                "name": 32458, 
                "iconImage": "trending.png", 
                "foldername": "Trending", 
                "mode": "build_movie_list", 
                "action": "trakt_movies_trending"
            }, 
            {
                "name": 32459, 
                "iconImage": "popular.png", 
                "foldername": "Popular", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_popular"
            }, 
            {
                "action": "tmdb_movies_premieres", 
                "iconImage": "fresh.png", 
                "mode": "build_movie_list", 
                "name": 32460, 
                "foldername": "Movies Premiering"
            }, 
            {
                "name": 32461, 
                "iconImage": "dvd.png", 
                "foldername": "Latest Releases", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_latest_releases"
            }, 
            {
                "action": "trakt_movies_top10_boxoffice", 
                "iconImage": "box_office.png", 
                "mode": "build_movie_list", 
                "name": 32462, 
                "foldername": "Movies Top 10 Box Office"
            }, 
            {
                "name": 32463, 
                "iconImage": "most_voted.png", 
                "foldername": "Blockbusters", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_blockbusters"
            }, 
            {
                "name": 32464, 
                "iconImage": "intheatres.png", 
                "foldername": "In Theaters", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_in_theaters"
            }, 
            {
                "name": 32465, 
                "iconImage": "top_rated.png", 
                "foldername": "Top Rated", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_top_rated"
            }, 
            {
                "name": 32466, 
                "iconImage": "lists.png", 
                "foldername": "Up Coming", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_upcoming"
            }, 
            {
                "name": 32467, 
                "iconImage": "most_anticipated.png", 
                "foldername": "Anticipated", 
                "mode": "build_movie_list", 
                "action": "trakt_movies_anticipated"
            }, 
            {
                "name": 32468, 
                "iconImage": "oscar-winners.png", 
                "foldername": "Oscar Winners", 
                "mode": "build_movie_list", 
                "action": "imdb_movies_oscar_winners"
            }, 
            {
                "name": 32469, 
                "menu_type": "movie", 
                "iconImage": "trakt.png", 
                "foldername": "Mosts", 
                "mode": "navigator.trakt_mosts"
            }, 
            {
                "name": 32470, 
                "menu_type": "movie", 
                "iconImage": "genres.png", 
                "foldername": "Genres", 
                "mode": "navigator.genres"
            }, 
            {
                "name": 32471, 
                "menu_type": "movie", 
                "iconImage": "languages.png", 
                "foldername": "Movie Languages", 
                "mode": "navigator.languages"
            }, 
            {
                "name": 32472, 
                "menu_type": "movie", 
                "iconImage": "calender.png", 
                "foldername": "Movie Years", 
                "mode": "navigator.years"
            }, 
            {
                "name": 32473, 
                "menu_type": "movie", 
                "iconImage": "certifications.png", 
                "foldername": "Certifications", 
                "mode": "navigator.certifications"
            }, 
            {
                "name": 32474, 
                "iconImage": "because_you_watched.png", 
                "foldername": "Because You Watched", 
                "mode": "navigator.because_you_watched", 
                "menu_type": "movie"
            }, 
            {
                "foldername": "Watched", 
                "iconImage": "watched_1.png", 
                "mode": "build_movie_list",  
                "action": "watched_movies", 
                "name": 32475
            }, 
            {
                "foldername": "In Progress", 
                "iconImage": "player.png", 
                "mode": "build_movie_list",  
                "action": "in_progress_movies", 
                "name": 32476
            }, 
            {
                "name": 32477, 
                "iconImage": "search.png", 
                "foldername": "Movie Search", 
                "mode": "get_search_term", 
                "db_type": "movie", 
                "default_search_item": "true"
            }
        ]
    
    def TVShowList(self):
        return [
            {
                "action": "trakt_tv_trending", 
                "iconImage": "trending.png", 
                "mode": "build_tvshow_list", 
                "name": 32458, 
                "foldername": "TV Trending"
            }, 
            {
                "action": "tmdb_tv_popular", 
                "iconImage": "popular.png", 
                "mode": "build_tvshow_list", 
                "name": 32459, 
                "foldername": "TV Popular"
            }, 
            {
                "action": "tmdb_tv_premieres", 
                "iconImage": "fresh.png", 
                "mode": "build_tvshow_list", 
                "name": 32460, 
                "foldername": "TV Premiering"
            }, 
            {
                "action": "tmdb_tv_top_rated", 
                "iconImage": "top_rated.png", 
                "mode": "build_tvshow_list", 
                "name": 32465, 
                "foldername": "TV Top Rated"
            }, 
            {
                "action": "tmdb_tv_airing_today", 
                "iconImage": "live.png", 
                "mode": "build_tvshow_list", 
                "name": 32478
            }, 
            {
                "action": "tmdb_tv_on_the_air", 
                "iconImage": "ontheair.png", 
                "mode": "build_tvshow_list", 
                "name": 32479, 
                "foldername": "TV On the Air"
            }, 
            {
                "name": 32466, 
                "iconImage": "lists.png", 
                "foldername": "Up Coming", 
                "mode": "build_tvshow_list", 
                "action": "tmdb_tv_upcoming"
            }, 
            {
                "action": "trakt_tv_anticipated", 
                "iconImage": "most_anticipated.png", 
                "mode": "build_tvshow_list", 
                "name": 32467
            }, 
            {
                "menu_type": "tvshow", 
                "iconImage": "trakt.png", 
                "mode": "navigator.trakt_mosts", 
                "name": 32469, 
                "foldername": "TV Trakt Mosts"
            }, 
            {
                "menu_type": "tvshow", 
                "iconImage": "genres.png", 
                "mode": "navigator.genres", 
                "name": 32470, 
                "foldername": "TV Genres"
            }, 
            {
                "menu_type": "tvshow", 
                "iconImage": "networks.png", 
                "mode": "navigator.networks", 
                "name": 32480, 
                "foldername": "TV Networks"
            }, 
            {
                "menu_type": "tvshow", 
                "iconImage": "languages.png", 
                "mode": "navigator.languages", 
                "name": 32471, 
                "foldername": "TV Show Languages"
            }, 
            {
                "name": 32472, 
                "menu_type": "tvshow", 
                "iconImage": "calender.png", 
                "foldername": "TV Show Years", 
                "mode": "navigator.years"
            }, 
            {
                "menu_type": "tvshow", 
                "iconImage": "certifications.png", 
                "mode": "navigator.certifications", 
                "name": 32473, 
                "foldername": "TV Show Certifications"
            }, 
            {
                "name": 32474, 
                "iconImage": "because_you_watched.png", 
                "foldername": "Because You Watched", 
                "mode": "navigator.because_you_watched", 
                "menu_type": "tvshow"
            }, 
            {
                "foldername": "Watched", 
                "iconImage": "watched_1.png", 
                "mode": "build_tvshow_list",  
                "action": "watched_tvshows", 
                "name": 32475
            }, 
            {
                "action": "in_progress_tvshows", 
                "iconImage": "in_progress_tvshow.png", 
                "mode": "build_tvshow_list", 
                "name": 32481, 
                "foldername": "In Progress TV Shows"
            }, 
            {
                "iconImage": "player.png", 
                "mode": "build_in_progress_episode", 
                "name": 32482, 
                "foldername": "In Progress Episodes"
            }, 
            {
                "iconImage": "next_episodes.png", 
                "mode": "build_next_episode", 
                "name": 32483, 
                "foldername": "It Next Episodes"
            }, 
            {
                "name": 32477, 
                "iconImage": "search.png", 
                "foldername": "TV Show Search", 
                "mode": "get_search_term", 
                "db_type": "tv_show", 
                "default_search_item": "true"
            }
        ]

    def DefaultMenuItems(self):
        return ['RootList', 'MovieList', 'TVShowList']






