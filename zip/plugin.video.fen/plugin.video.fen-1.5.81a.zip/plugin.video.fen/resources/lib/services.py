import xbmc, xbmcgui
import sys
import time
from datetime import datetime, timedelta
from threading import Thread
import sys
from modules import settings
# from modules.utils import logger

__addon__ = settings.addon()

class Services:
    def runServiceThreads(self, services):
        service_threads = []
        for i in services:
            service_threads.append(Thread(target=i[0], args=i[1]))
        [i.start() for i in service_threads]
        while not xbmc.abortRequested:
            time.sleep(2)
        sys.exit()

class AutoRun:
    def run(self):
        if settings.auto_start_fen():
            xbmc.log("[FEN] Auto starting...", 2)
            return xbmc.executebuiltin('RunAddon(plugin.video.fen)')
        else: return

class SubscriptionsUpdater:
    def run(self):
        xbmc.log("[FEN] Subscription service starting...", 2)
        while not xbmc.abortRequested:
            if settings.subscription_update():
                try:
                    hours = settings.subscription_timer()
                    service_time = settings.subscription_service_time()
                    next_run  = datetime.fromtimestamp(time.mktime(time.strptime(service_time, "%Y-%m-%d %H:%M:%S")))
                    now = datetime.now()
                    if now > next_run:
                        if xbmc.Player().isPlaying() == False:
                            if xbmc.getCondVisibility('Library.IsScanningVideo') == False:      
                                xbmc.log("[FEN'] Updating video subscriptions", 2)
                                time.sleep(1)
                                xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?&mode=update_subscriptions)')
                                time.sleep(1)
                                __addon__.setSetting('service_time', str(datetime.now() + timedelta(hours=hours)).split('.')[0])
                                xbmc.log("[FEN] Subscriptions updated. Next run at " + service_time, 2)
                        else:
                            xbmc.log("[FEN] Player is running, waiting until finished")
                except: pass
            time.sleep(2)
        return

subscriptions = SubscriptionsUpdater()
autorun = AutoRun()
Services().runServiceThreads([(subscriptions.run, ()), (autorun.run, ())])
