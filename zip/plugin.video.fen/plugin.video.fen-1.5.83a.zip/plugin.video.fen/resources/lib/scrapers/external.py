# -*- coding: utf-8 -*-
import xbmc, xbmcaddon
import os
import datetime
import json
import re
import sys
import time
from threading import Thread
from tikiscrapers import sources
from tikiscrapers.modules import cleantitle, control, debrid, source_utils
from tikiscrapers.modules.utils import byteify
# from modules.utils import logger
try:
    from sqlite3 import dbapi2 as database
except Exception:
    from pysqlite2 import dbapi2 as database
try:
    import resolveurl
except Exception:
    pass

__fen__ = xbmcaddon.Addon(id='plugin.video.fen')
__external__ = xbmcaddon.Addon(id='script.module.tikiscrapers')

class ExternalSource:
    def __init__(self):
        self.exportSettings()
        self.getConstants()
        self.scrape_provider = 'external'
        self.debrid_enabled = []
        self.sources = []
        self.duplicates = 0

    def results(self, info):
        results = self.getSources((info['title'] if info['db_type'] == 'movie' else info['ep_name']),
                            info['year'], info['imdb_id'], info['tvdb_id'], info['season'], info['episode'],
                            (info['title'] if info['db_type'] == 'episode' else None), info['premiered'], info['language'])
        return results

    def getSources(self, title, year, imdb, tvdb, season, episode, tvshowtitle, premiered, language):
        def _scraperDialog():
            int_dialog_highlight = __fen__.getSetting('int_dialog_highlight')
            if not int_dialog_highlight or int_dialog_highlight == '': int_dialog_highlight = 'darkgoldenrod'
            ext_dialog_highlight = __fen__.getSetting('ext_dialog_highlight')
            if not ext_dialog_highlight or ext_dialog_highlight == '': ext_dialog_highlight = 'dodgerblue'
            finish_early = __fen__.getSetting('search.finish.early')
            string1 = 'Time elapsed: %s seconds'
            string2 = '%s seconds'
            string3 = 'Remaining providers: %s'
            string4 = 'Total'
            string5 = 'Waiting for'
            if self.internal_activated:
                string6 = '[COLOR %s][B]Int[/B][/COLOR]' % int_dialog_highlight
                string7 = '[COLOR %s][B]Ext[/B][/COLOR]' % ext_dialog_highlight
            else:
                string7 = '[COLOR %s]External Scrapers[/COLOR]' % ext_dialog_highlight
            line1 = line2 = line3 = ""
            total_format = '[COLOR %s][B]%s[/B][/COLOR]'
            idiag_format = ' 4K: %s | 1080p: %s | 720p: %s | SD: %s | %s: %s'.split('|')
            ediag_format = ' 4K: %s | 1080p: %s | 720p: %s | SD: %s | %s: %s'.split('|')
            exonly_diag_format = '4K: %s | 1080p: %s | 720p: %s | SD: %s | %s: %s'
            for i in range(0, 4 * timeout):
                try:
                    if xbmc.abortRequested == True: return sys.exit()
                    try:
                        if progressDialog.iscanceled(): break
                    except Exception: pass
                    self.internalResults()
                    source_4k = len([e for e in self.sources if e['quality'] == '4K'])
                    source_1080 = len([e for e in self.sources if e['quality'] in ['1440p', '1080p']])
                    source_720 = len([e for e in self.sources if e['quality'] in ['720p', 'HD']])
                    source_sd = len([e for e in self.sources if e['quality'] == 'SD'])
                    total = source_4k + source_1080 + source_720 + source_sd
                    internalSource_4k_label = total_format % (int_dialog_highlight, self.internalSources4K)
                    internalSource_1080_label = total_format % (int_dialog_highlight, self.internalSources1080p)
                    internalSource_720_label = total_format % (int_dialog_highlight, self.internalSources720p)
                    internalSource_sd_label = total_format % (int_dialog_highlight, self.internalSourcesSD)
                    internalSource_total_label = total_format % (int_dialog_highlight, self.internalSourcesTotal)
                    source_4k_label = total_format % (ext_dialog_highlight, source_4k)
                    source_1080_label = total_format % (ext_dialog_highlight, source_1080)
                    source_720_label = total_format % (ext_dialog_highlight, source_720)
                    source_sd_label = total_format % (ext_dialog_highlight, source_sd)
                    source_total_label = total_format % (ext_dialog_highlight, total)
                    current_time = time.time()
                    current_progress = current_time - start_time
                    if current_time < end_time:
                        try:
                            mainleft = [sourcelabelDict[x.getName()] for x in threads if x.is_alive() is True and x.getName() in mainsourceDict]
                            info = [sourcelabelDict[x.getName()] for x in threads if x.is_alive() is True]
                            if finish_early == 'true':
                                if i >= timeout and len(mainleft) == 0 and len(self.sources) >= 100 * len(info): break
                            if self.internal_activated:
                                line1 = ('%s:' + '|'.join(idiag_format)) % (string6, internalSource_4k_label, internalSource_1080_label,
                                                          internalSource_720_label, internalSource_sd_label, str(string4), internalSource_total_label)
                                line2 = ('%s:' + '|'.join(ediag_format)) % (string7, source_4k_label, source_1080_label, source_720_label, source_sd_label, str(string4), source_total_label)
                            else:
                                line1 = string7
                                line2 = exonly_diag_format % (source_4k_label, source_1080_label, source_720_label, source_sd_label, str(string4), source_total_label)
                            if len(info) > 6: line3 = string3 % (str(len(info)))
                            elif len(info) > 0: line3 = string3 % (', '.join(info))
                            else: break
                            percent = int((current_progress/float(timeout))*100)
                            progressDialog.update(percent, line1, line2, line3)
                            pre_emp_compare = source_4k if pre_emp_quality == '4k' else source_1080 if pre_emp_quality == '1080p' else source_720 if pre_emp_quality == '720p' else source_sd if pre_emp_quality == 'SD' else total
                            if pre_emp == 'true' and pre_emp_compare >= int(pre_emp_limit): break
                        except: pass
                    else:
                        try:
                            mainleft = [sourcelabelDict[x.getName()] for x in threads if x.is_alive() is True and x.getName() in mainsourceDict]
                            info = mainleft
                            if len(info) > 6: line3 = 'Waiting for: %s' % (str(len(info)))
                            elif len(info) > 0: line3 = 'Waiting for: %s' % (', '.join(info))
                            else: break
                            percent = int((current_progress/float(timeout))*100) % 100
                            progressDialog.update(percent, line1, line2, line3)
                        except Exception: break
                    time.sleep(0.5)
                except Exception: pass
            try: progressDialog.close()
            except Exception: pass
        def _background():
            while time.time() < end_time:
                time.sleep(0.5)
                source_4k = len([e for e in self.sources if e['quality'] == '4K'])
                source_1080 = len([e for e in self.sources if e['quality'] in ['1440p', '1080p']])
                source_720 = len([e for e in self.sources if e['quality'] in ['720p', 'HD']])
                source_sd = len([e for e in self.sources if e['quality'] == 'SD'])
                total = source_4k + source_1080 + source_720 + source_sd
                pre_emp_compare = source_4k if pre_emp_quality == '4k' else source_1080 if pre_emp_quality == '1080p' else source_720 if pre_emp_quality == '720p' else source_sd if pre_emp_quality == 'SD' else total
                if pre_emp == 'true' and pre_emp_compare >= int(pre_emp_limit): break
                info = [sourcelabelDict[x.getName()] for x in threads if x.is_alive() is True]
                if len(self.sources) >= 100 * len(info): break
        meta = json.loads(control.window.getProperty('fen_media_meta'))
        self.background = meta.get('background', False)
        content = 'movie' if tvshowtitle is None else 'episode'
        if not self.background:
            progressDialog = control.progressDialog
            if content == 'movie': progressTitle = meta.get('rootname') if self.progressHeading == 1 else self.moduleProvider
            else: progressTitle = meta.get('rootname') if self.progressHeading == 1 else self.moduleProvider
            progressDialog.create(progressTitle, '')
            progressDialog.update(0)
            progressDialog.update(0, 'Preparing sources')
        sourceDict = self.sourceDict
        if content == 'movie': sourceDict = [(i[0], i[1], getattr(i[1], 'movie', None)) for i in sourceDict]
        else: sourceDict = [(i[0], i[1], getattr(i[1], 'tvshow', None)) for i in sourceDict]
        sourceDict = [(i[0], i[1]) for i in sourceDict if not i[2] is None]
        try: sourceDict = [(i[0], i[1], control.setting('provider.' + i[0])) for i in sourceDict]
        except Exception: sourceDict = [(i[0], i[1], 'true') for i in sourceDict]
        sourceDict = [(i[0], i[1]) for i in sourceDict if not i[2] == 'false']
        sourceDict = [(i[0], i[1], i[1].priority) for i in sourceDict]
        sourceDict = sorted(sourceDict, key=lambda i: i[2])
        threads = []
        if content == 'movie':
            title = cleantitle.normalize(title)
            for i in sourceDict:
                threads.append(Thread(target=self.getMovieSource, args=(title, title, [], year, imdb, i[0], i[1])))
        else:
            tvshowtitle = cleantitle.normalize(tvshowtitle)
            for i in sourceDict:
                threads.append(Thread(target=self.getEpisodeSource, args=(title, year, imdb, tvdb, season,
                                                              episode, tvshowtitle, tvshowtitle, [], premiered, i[0], i[1])))
        [i.start() for i in threads]
        s = [i[0] + (i[1],) for i in zip(sourceDict, threads)]
        s = [(i[3].getName(), i[0], i[2]) for i in s]
        mainsourceDict = [i[0] for i in s if i[2] == 0]
        sourcelabelDict = dict([(i[0], i[1].upper()) for i in s])
        pre_emp =  __fen__.getSetting('preemptive.termination')
        pre_emp_quality = __fen__.getSetting('preemptive.quality')
        pre_emp_limit = __fen__.getSetting('preemptive.limit')
        try: timeout = int(__fen__.getSetting('scrapers.timeout.1'))
        except: timeout = 30
        start_time = time.time()
        end_time = start_time + timeout
        if self.background: _background()
        else: _scraperDialog()
        self.sourcesFilter()
        self.sourcesLabels()
        return self.sources

    def getMovieSource(self, title, localtitle, aliases, year, imdb, source, call):
        try:
            dbcon = database.connect(self.providerDatabase)
            dbcur = dbcon.cursor()
        except Exception:
            pass
        if imdb == '0':
            try:
                dbcur.execute(
                    "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                    (source, imdb, '', ''))
                dbcur.execute(
                    "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                    (source, imdb, '', ''))
                dbcon.commit()
            except Exception:
                pass
        try:
            sources = []
            dbcur.execute(
                "SELECT * FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, '', ''))
            match = dbcur.fetchone()
            t1 = int(re.sub('[^0-9]', '', str(match[5])))
            t2 = int(datetime.datetime.now().strftime("%Y%m%d%H%M"))
            update = abs(t2 - t1) > 60
            if update is False:
                sources = eval(match[4].encode('utf-8'))
                return self.sources.extend(sources)
        except Exception:
            pass
        try:
            url = None
            dbcur.execute(
                "SELECT * FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, '', ''))
            url = dbcur.fetchone()
            url = eval(url[4].encode('utf-8'))
        except Exception:
            pass
        try:
            if url is None:
                url = call.movie(imdb, title, localtitle, aliases, year)
            if url is None:
                raise Exception()
            dbcur.execute(
                "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, '', ''))
            dbcur.execute("INSERT INTO rel_url Values (?, ?, ?, ?, ?)", (source, imdb, '', '', repr(url)))
            dbcon.commit()
        except Exception:
            pass
        try:
            sources = []
            sources = call.sources(url, self.hostDict, self.hostprDict)
            if sources is None or sources == []:
                raise Exception()
            sources = [json.loads(t) for t in set(json.dumps(d, sort_keys=True) for d in sources)]
            sources = self.sourcesUpdate(source, sources)
            self.sources.extend(sources)
            dbcur.execute(
                "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, '', ''))
            dbcur.execute("INSERT INTO rel_src Values (?, ?, ?, ?, ?, ?)", (source, imdb, '',
                                                                            '', repr(sources), datetime.datetime.now().strftime("%Y-%m-%d %H:%M")))
            dbcon.commit()
        except Exception:
            pass

    def getEpisodeSource(self, title, year, imdb, tvdb, season, episode, tvshowtitle, localtvshowtitle, aliases, premiered, source, call):
        try:
            dbcon = database.connect(self.providerDatabase)
            dbcur = dbcon.cursor()
        except Exception:
            pass
        try:
            sources = []
            dbcur.execute(
                "SELECT * FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, season, episode))
            match = dbcur.fetchone()
            t1 = int(re.sub('[^0-9]', '', str(match[5])))
            t2 = int(datetime.datetime.now().strftime("%Y%m%d%H%M"))
            update = abs(t2 - t1) > 60
            if update is False:
                sources = eval(match[4].encode('utf-8'))
                return self.sources.extend(sources)
        except Exception:
            pass
        try:
            url = None
            dbcur.execute(
                "SELECT * FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, '', ''))
            url = dbcur.fetchone()
            url = eval(url[4].encode('utf-8'))
        except Exception:
            pass
        try:
            if url is None:
                url = call.tvshow(imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year)
            if url is None:
                raise Exception()
            dbcur.execute(
                "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, '', ''))
            dbcur.execute("INSERT INTO rel_url Values (?, ?, ?, ?, ?)", (source, imdb, '', '', repr(url)))
            dbcon.commit()
        except Exception:
            pass
        try:
            ep_url = None
            dbcur.execute(
                "SELECT * FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, season, episode))
            ep_url = dbcur.fetchone()
            ep_url = eval(ep_url[4].encode('utf-8'))
        except Exception:
            pass
        try:
            if url is None:
                raise Exception()
            if ep_url is None:
                ep_url = call.episode(url, imdb, tvdb, title, premiered, season, episode)
            if ep_url is None:
                raise Exception()
            dbcur.execute(
                "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, season, episode))
            dbcur.execute("INSERT INTO rel_url Values (?, ?, ?, ?, ?)", (source, imdb, season, episode, repr(ep_url)))
            dbcon.commit()
        except Exception:
            pass
        try:
            sources = []
            sources = call.sources(ep_url, self.hostDict, self.hostprDict)
            if sources is None or sources == []:
                raise Exception()
            sources = [json.loads(t) for t in set(json.dumps(d, sort_keys=True) for d in sources)]
            sources = self.sourcesUpdate(source, sources)
            self.sources.extend(sources)
            dbcur.execute(
                "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, season, episode))
            dbcur.execute("INSERT INTO rel_src Values (?, ?, ?, ?, ?, ?)", (source, imdb, season,
                                                                            episode, repr(sources), datetime.datetime.now().strftime("%Y-%m-%d %H:%M")))
            dbcon.commit()
        except Exception:
            pass

    def sourcesFilter(self):
        self.torrentCheckCache = __fen__.getSetting('torrent.check.cache')
        if self.torrentCheckCache == '':  self.torrentCheckCache = 'false'
        self.uncheckedTorrents = __fen__.getSetting('torrent.display.unchecked')
        if self.uncheckedTorrents == '': self.uncheckedTorrents = 'true'
        self.uncachedTorrents = __fen__.getSetting('torrent.display.uncached')
        if self.uncachedTorrents == '': self.uncachedTorrents = 'false'
        removeDuplicates = __fen__.getSetting('remove.duplicates')
        if removeDuplicates == '': removeDuplicates = 'false'
        debridOnly = __fen__.getSetting('debrid.only')
        if debridOnly == '':  debridOnly = 'false'
        captcha = __fen__.getSetting('hosts.captcha')
        if captcha == '': captcha = 'true'
        if removeDuplicates == 'true':
            if len(self.sources) > 0:
                import xbmcgui
                self.sources = list(self.sourcesRemoveDuplicates(self.sources))
                if not self.background: xbmcgui.Dialog().notification('Fen', '[B]%d[/B] Duplicate URLs Removed' % self.duplicates , __fen__.getAddonInfo('icon'), 5000, sound=False)
        hoster_sources = [i for i in self.sources if i['source'].lower() != 'torrent']
        torrentSources = self.sourcesProcessTorrents([i for i in self.sources if i['source'].lower() == 'torrent'])
        filter = []
        valid_hosters = list(set([i['source'] for i in self.sources]))
        for d in debrid.debrid_resolvers:
            valid_hoster = [i for i in valid_hosters if d.valid_url('', i)]
            #TORRENTS...
            if self.torrentCheckCache == 'false':
                filter += [dict(i.items() + [('debrid', d.name)]) for i in torrentSources if i.get('cache_provider') == 'Unchecked']
            else:
                if d.name in ('Real-Debrid', 'Premiumize.me', 'AllDebrid') and d.name in self.debrid_enabled:
                    filter += [dict(i.items() + [('debrid', d.name)]) for i in torrentSources if d.name == i.get('cache_provider')]
                    if self.uncachedTorrents == 'true':
                        filter += [dict(i.items() + [('debrid', d.name)]) for i in torrentSources if i['source'].lower() == 'torrent' and i.get('cache_provider') == 'Uncached']
                else:
                    if self.uncheckedTorrents == 'true' or torrentSources[0].get('cache_provider') == 'Unchecked':
                        filter += [dict(i.items() + [('debrid', d.name)]) for i in torrentSources if i.get('cache_provider') == 'Unchecked']
            #HOSTERS
            filter += [dict(i.items() + [('debrid', d.name)]) for i in hoster_sources if i['source'] in valid_hoster]
        if debridOnly == 'false' or debrid.status() is False:
            filter += [i for i in hoster_sources if not i['source'].lower() in self.hostprDict and i['debridonly'] is False]
        self.sources = filter
        if not captcha == 'true':
            filter = [i for i in self.sources if i['source'].lower() in self.hostcapDict and 'debrid' not in i]
            self.sources = [i for i in self.sources if i not in filter]
        filter = [i for i in self.sources if i['source'].lower() in self.hostblockDict and 'debrid' not in i]
        self.sources = [i for i in self.sources if i not in filter]
        self.sources = self.sources[:2500]

    def sourcesLabels(self):
        def _processLabels(item):
            if extraInfo == 'true': t = source_utils.getFileType(item['url'])
            else: t = None
            u = item['url']
            p = item['provider']
            q = item['quality']
            s = item['source']
            s = s.rsplit('.', 1)[0]
            try: f = (' | '.join(['[I]%s [/I]' % info.strip() for info in item['info'].split('|')]))
            except Exception: f = ''
            try: d = item['debrid']
            except Exception: d = item['debrid'] = ''
            if d:
                if d.lower() == 'real-debrid':
                    if 'cache_provider' in item:
                        if item['cache_provider'] == 'Unchecked': d = '[I]RD UNCHECKED[/I]'
                        elif item['cache_provider'] == 'Uncached': d = '[I]RD UNCACHED[/I]'
                        else: d = '[B]RD CACHED[/B]'
                    else: d = 'RD'
                elif d.lower() == 'premiumize.me':
                    if 'cache_provider' in item:
                        if item['cache_provider'] == 'Unchecked': d = '[I]PM UNCHECKED[/I]'
                        elif item['cache_provider'] == 'Uncached': d = '[I]PM UNCACHED[/I]'
                        else: d = '[B]PM CACHED[/B]'
                    else: d = 'PM'
                elif d.lower() == 'alldebrid':
                    if 'cache_provider' in item:
                        if item['cache_provider'] == 'Unchecked': d = '[I]AD UNCHECKED[/I]'
                        elif item['cache_provider'] == 'Uncached': d = '[I]AD UNCACHED[/I]'
                        else: d = '[B]AD CACHED[/B]'
                    else: d = 'AD'
                elif d.lower() == 'debrid-link.fr': d = 'DL'
                elif d.lower() == 'linksnappy': d = 'LS'
                elif d.lower() == 'megadebrid': d = 'MD'
                elif d.lower() == 'zevera': d = 'ZV'
            multiline_label2 = ''
            if q.upper() in ['4K', '1080P', '720P', 'TELE', 'SCR', 'CAM']:
                label = '[B]EXT[/B] | [I][B]%s[/B][/I]  | ' % q
                multiline_label1 = '[B]EXT[/B] | [I][B]%s[/B][/I]  | ' % q
            else:
                label = '[B]EXT[/B] | [I]SD[/I]  | '
                multiline_label1 = '[B]EXT[/B] | [I]SD[/I]  | '
            if d:
                label += '%s | %s | ' % (d, p)
                multiline_label1 += '%s | %s | ' % (d, p)
            else:
                label += '%s | ' % p
                multiline_label1 += '%s | ' % p
            multiline_label1 += s
            if t:
                if f:
                    label += '%s | %s | %s' % (s, f, t)
                    multiline_label2 += '\n        %s | %s' % (f, t)
                else:
                    label += '%s | %s' % (s, t)
                    multiline_label2 += '\n        %s' % t
            else:
                if f:
                    label += '%s | %s' % (s, f)
                    multiline_label2 = '\n        %s' % f
                else:
                    label += s
            label = label.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
            label = re.sub('\[I\]\s+\[/I\]', ' ', label)
            label = re.sub('\|\s+\|', '|', label)
            label = re.sub('\|(?:\s+|)$', '', label)
            label = label.upper()
            multiline_label1 = multiline_label1.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
            multiline_label1 = re.sub('\[I\]\s+\[/I\]', ' ', multiline_label1)
            multiline_label1 = re.sub('\|\s+\|', '|', multiline_label1)
            multiline_label1 = re.sub('\|(?:\s+|)$', '', multiline_label1)
            multiline_label1 = multiline_label1.upper()
            if multiline_label2 != '':
                multiline_label2 = multiline_label2.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
                multiline_label2 = re.sub('\[I\]\s+\[/I\]', ' ', multiline_label2)
                multiline_label2 = re.sub('\|\s+\|', '|', multiline_label2)
                multiline_label2 = re.sub('\|(?:\s+|)$', '', multiline_label2)
                multiline_label2 = multiline_label2.upper()
            if highlightType == '1':
                if q.upper() == '4K': LeadingColor = highlight_4K
                elif q.upper()  == '1080P': LeadingColor = highlight_1080p
                elif q.upper() == '720P': LeadingColor = highlight_720p
                else: LeadingColor = highlight_SD
                if multiLineHighlight == '': multilineOpen = LeadingColor
                else: multilineOpen = multiLineHighlight
                item['label'] = '[COLOR=%s]' % LeadingColor + label + '[/COLOR]'
                item['multiline_label'] = '[COLOR=%s]' % LeadingColor + multiline_label1 + '[/COLOR]' + '[COLOR=%s]' % multilineOpen + multiline_label2 + '[/COLOR]'
            else:
                if d:
                    if 'torrent' in s.lower():
                        item['label'] = singleTorrentLeading + label + singleTorrentClosing
                        item['multiline_label'] = multi1TorrentLeading + multiline_label1 + multi1TorrentClosing + multi2TorrentLeading + multiline_label2 + multi2TorrentClosing
                    else:
                        item['label'] = singlePremiumLeading + label + singlePremiumClosing
                        item['multiline_label'] = multi1PremiumLeading + multiline_label1 + multi1PremiumClosing + multi2PremiumLeading + multiline_label2 + multi2PremiumClosing
                else:
                    item['label'] = label
                    item['multiline_label'] = multiline_label1 + multi1RegularLeading + multiline_label2 + multi1RegularClosing
        threads = []
        enableMultiline = True if __fen__.getSetting('results.multiline_label') == "true" else False
        extraInfo = __fen__.getSetting('results.show_extra_info')
        
        try: multiLineHighlight = __fen__.getSetting('secondline.identify')
        except: multiLineHighlight = ''
        if multiLineHighlight.lower() == 'no color': multiLineHighlight = ''

        highlightType = __fen__.getSetting('highlight.type')
        if highlightType == '': highlightType = '0'
        
        if highlightType == '1':
            highlight_4K = 'magenta'
            highlight_1080p = 'lawngreen'
            highlight_720p = 'gold'
            highlight_SD = 'lightsaltegray'
            highlight_4K = __fen__.getSetting('scraper_4k_highlight')
            if highlight_4K == '': highlight_4K = 'magenta'
            highlight_1080p = __fen__.getSetting('scraper_1080p_highlight')
            if highlight_1080p == '': highlight_1080p = 'lawngreen'
            highlight_720p = __fen__.getSetting('scraper_720p_highlight')
            if highlight_720p == '': highlight_720p = 'gold'
            highlight_SD = __fen__.getSetting('scraper_SD_highlight')
            if highlight_SD == '': highlight_SD = 'lightsaltegray'
        else:
            premiumHighlight = __fen__.getSetting('prem.identify')
            torrentHighlight = __fen__.getSetting('torrent.identify')
            if premiumHighlight == '': premiumHighlight = 'blue'
            elif premiumHighlight.lower() == 'no color': premiumHighlight = ''
            if torrentHighlight == '': torrentHighlight = 'magenta'
            elif torrentHighlight.lower() == 'no color': torrentHighlight = ''
            # Single Line...
            # Torrent...
            if torrentHighlight == '':
                singleTorrentLeading = ''
                singleTorrentClosing = ''
            else:
                singleTorrentLeading = '[COLOR=%s]' % torrentHighlight
                singleTorrentClosing = '[/COLOR]'
            # Premium...
            if premiumHighlight == '':
                singlePremiumLeading = ''
                singlePremiumClosing = ''
            else:
                singlePremiumLeading = '[COLOR=%s]' % premiumHighlight
                singlePremiumClosing = '[/COLOR]'

            # Multiline...
            # Torrent...
            if torrentHighlight == '':
                multi1TorrentLeading = ''
                multi1TorrentClosing = ''
            else:
                multi1TorrentLeading = '[COLOR=%s]' % torrentHighlight
                multi1TorrentClosing = '[/COLOR]'
            if multiLineHighlight == '':
                multi2TorrentLeading = multi1TorrentLeading
                multi2TorrentClosing = multi1TorrentClosing
            else:
                multi2TorrentLeading = '[COLOR=%s]' % multiLineHighlight
                multi2TorrentClosing = '[/COLOR]'
            # Premium...
            if premiumHighlight == '':
                multi1PremiumLeading = ''
                multi1PremiumClosing = ''
            else:
                multi1PremiumLeading = '[COLOR=%s]' % premiumHighlight
                multi1PremiumClosing = '[/COLOR]'
            if multiLineHighlight == '':
                multi2PremiumLeading = multi1PremiumLeading
                multi2PremiumClosing = multi1PremiumClosing
            else:
                multi2PremiumLeading = '[COLOR=%s]' % multiLineHighlight
                multi2PremiumClosing = '[/COLOR]'

            # Regular...
            if multiLineHighlight == '':
                multi1RegularLeading = ''
                multi1RegularClosing = ''
            else:
                multi1RegularLeading = '[COLOR=%s]' % multiLineHighlight
                multi1RegularClosing = '[/COLOR]'

        for i in self.sources: threads.append(Thread(target=_processLabels, args=(i,)))
        [i.start() for i in threads]
        [i.join() for i in threads]
        self.sources = [i for i in self.sources if 'label' in i and 'multiline_label' in i]

    def sourcesUpdate(self, source, sources):
        source = byteify(source)
        for i in sources:
            i.update({'provider': source, 'external': True, 'size': 0, 'scrape_provider': self.scrape_provider, 'url': i['url']})
            if 'checkquality' in i and i['checkquality'] is True:
                if not i['source'].lower() in self.hosthqDict and i['quality'] not in ['TELE', 'SCR', 'CAM']:
                    i.update({'quality': 'SD'})
            q = i['quality']
            if q == 'HD':
                i.update({'quality': '720p'})
            if q == '1440p':
                i.update({'quality': '1080p'})
        return sources

    def sourcesRemoveDuplicates(self, sources):
        uniqueURLs = set()
        for source in sources:
            try:
                if source['url'] not in uniqueURLs:
                    uniqueURLs.add(source['url'])
                    yield source
                else:
                    self.duplicates += 1
            except:
                yield source

    def sourcesProcessTorrents(self, torrentSources):
        def _return_unchecked_sources():
            for i in torrentSources: i.update({'cache_provider': 'Unchecked'})
            return torrentSources
        if len(torrentSources) == 0: return torrentSources
        if self.torrentCheckCache == 'false': return _return_unchecked_sources()
        try:
            from modules import debridcheck
            self.debrid_enabled = debridcheck.debrid_enabled()
            debridResolvers = [d.name for d in debrid.debrid_resolvers]
            self.debrid_enabled = [i for i in self.debrid_enabled if i in debridResolvers]
            if len(self.debrid_enabled) == 0: return _return_unchecked_sources()
            time.sleep(0.5)
            DBCheck = debridcheck.DebridCheck()
            hashList = []
            cachedTorrents = []
            uncheckedTorrents = []
            uncachedTorrents = []
            for i in torrentSources:
                try:
                    r = re.search('''magnet:.+?urn:([a-zA-Z0-9]+):([a-zA-Z0-9]+)''', str(i['url']), re.I)
                    if r:
                        infoHash = r.group(2).lower()
                        if len(infoHash) == 40:
                            i['info_hash'] = infoHash
                            hashList.append(infoHash)
                        else:
                            torrentSources.remove(i)
                except: torrentSources.remove(i)
            if len(torrentSources) == 0: return torrentSources
            torrentSources = [i for i in torrentSources if 'info_hash' in i]
            hashList = list(set(hashList))
            cachedRDHashes, cachedPMHashes, cachedADHashes = DBCheck.run(hashList, self.background, self.debrid_enabled)
            cachedRDSources = [dict(i.items() + [('cache_provider', 'Real-Debrid')]) for i in torrentSources if any(v in i['info_hash'] for v in cachedRDHashes)]
            cachedPMSources = [dict(i.items() + [('cache_provider', 'Premiumize.me')]) for i in torrentSources if any(v in i['info_hash'] for v in cachedPMHashes)]
            cachedADSources = [dict(i.items() + [('cache_provider', 'AllDebrid')]) for i in torrentSources if any(v in i['info_hash'] for v in cachedADHashes)]
            if 'Real-Debrid' in self.debrid_enabled: cachedTorrents.extend(cachedRDSources)
            if 'Premiumize.me' in self.debrid_enabled: cachedTorrents.extend(cachedPMSources)
            if 'AllDebrid' in self.debrid_enabled: cachedTorrents.extend(cachedADSources)
            if self.uncachedTorrents == 'true':
                cachedHashes = list(set(cachedRDHashes + cachedPMHashes + cachedADHashes))
                uncachedTorrents = [dict(i.items() + [('cache_provider', 'Uncached')]) for i in torrentSources if not i['info_hash'] in cachedHashes]
            if self.uncheckedTorrents == 'true':
                uncheckedTorrents = [dict(i.items() + [('cache_provider', 'Unchecked')]) for i in torrentSources]
            return cachedTorrents + uncachedTorrents + uncheckedTorrents
        except:
            import xbmcgui
            xbmcgui.Dialog().notification('Fen', 'Error Processing Torrents', __fen__.getAddonInfo('icon'), 3500, sound=False)
            return _return_unchecked_sources()

    def internalResults(self):
        if self.furk_enabled == 'true' and not self.furk_sources:
            try: furk_sources = json.loads(control.window.getProperty('furk_source_results'))
            except: furk_sources = []
            if furk_sources:
                self.furk_sources = len(furk_sources)
                self.furk_sources_4K = len([i for i in furk_sources if i['quality'] == '4K'])
                self.furk_sources_1080p = len([i for i in furk_sources if i['quality'] == '1080p'])
                self.furk_sources_720p = len([i for i in furk_sources if i['quality'] == '720p'])
                self.furk_sources_SD = len([i for i in furk_sources if i['quality'] in ['SD', 'SCR', 'CAM', 'TELE']])
        if self.easynews_enabled == 'true' and not self.easynews_sources:
            try: easynews_sources = json.loads(control.window.getProperty('easynews_source_results'))
            except: easynews_sources = []
            if easynews_sources:
                self.easynews_sources = len(easynews_sources)
                self.easynews_sources_4K = len([i for i in easynews_sources if i['quality'] == '4K'])
                self.easynews_sources_1080p = len([i for i in easynews_sources if i['quality'] == '1080p'])
                self.easynews_sources_720p = len([i for i in easynews_sources if i['quality'] == '720p'])
                self.easynews_sources_SD = len([i for i in easynews_sources if i['quality'] in ['SD', 'SCR', 'CAM', 'TELE']])
        if self.pm_cloud_enabled == 'true' and not self.pm_cloud_sources:
            try: pm_cloud_sources = json.loads(control.window.getProperty('pm-cloud_source_results'))
            except: pm_cloud_sources = []
            if pm_cloud_sources:
                self.pm_cloud_sources = len(pm_cloud_sources)
                self.pm_cloud_sources_4K = len([i for i in pm_cloud_sources if i['quality'] == '4K'])
                self.pm_cloud_sources_1080p = len([i for i in pm_cloud_sources if i['quality'] == '1080p'])
                self.pm_cloud_sources_720p = len([i for i in pm_cloud_sources if i['quality'] == '720p'])
                self.pm_cloud_sources_SD = len([i for i in pm_cloud_sources if i['quality'] in ['SD', 'SCR', 'CAM', 'TELE']])
        if self.rd_cloud_enabled == 'true' and not self.rd_cloud_sources:
            try: rd_cloud_sources = json.loads(control.window.getProperty('rd-cloud_source_results'))
            except: rd_cloud_sources = []
            if rd_cloud_sources:
                self.rd_cloud_sources = len(rd_cloud_sources)
                self.rd_cloud_sources_4K = len([i for i in rd_cloud_sources if i['quality'] == '4K'])
                self.rd_cloud_sources_1080p = len([i for i in rd_cloud_sources if i['quality'] == '1080p'])
                self.rd_cloud_sources_720p = len([i for i in rd_cloud_sources if i['quality'] == '720p'])
                self.rd_cloud_sources_SD = len([i for i in rd_cloud_sources if i['quality'] in ['SD', 'SCR', 'CAM', 'TELE']])
        if self.ad_cloud_enabled == 'true' and not self.ad_cloud_sources:
            try: ad_cloud_sources = json.loads(control.window.getProperty('ad-cloud_source_results'))
            except: ad_cloud_sources = []
            if ad_cloud_sources:
                self.ad_cloud_sources = len(ad_cloud_sources)
                self.ad_cloud_sources_4K = len([i for i in ad_cloud_sources if i['quality'] == '4K'])
                self.ad_cloud_sources_1080p = len([i for i in ad_cloud_sources if i['quality'] == '1080p'])
                self.ad_cloud_sources_720p = len([i for i in ad_cloud_sources if i['quality'] == '720p'])
                self.ad_cloud_sources_SD = len([i for i in ad_cloud_sources if i['quality'] in ['SD', 'SCR', 'CAM', 'TELE']])
        if self.local_enabled == 'true' and not self.local_sources:
            try: local_sources = json.loads(control.window.getProperty('local_source_results'))
            except: local_sources = []
            if local_sources:
                self.local_sources = len(local_sources)
                self.local_sources_4K = len([i for i in local_sources if i['quality'] == '4K'])
                self.local_sources_1080p = len([i for i in local_sources if i['quality'] == '1080p'])
                self.local_sources_720p = len([i for i in local_sources if i['quality'] == '720p'])
                self.local_sources_SD = len([i for i in local_sources if i['quality'] in ['SD', 'SCR', 'CAM', 'TELE']])
        if self.downloads_enabled == 'true' and not self.downloads_sources:
            try: downloads_sources = json.loads(control.window.getProperty('downloads_source_results'))
            except: downloads_sources = []
            if downloads_sources:
                self.downloads_sources = len(downloads_sources)
                self.downloads_sources_4K = len([i for i in downloads_sources if i['quality'] == '4K'])
                self.downloads_sources_1080p = len([i for i in downloads_sources if i['quality'] == '1080p'])
                self.downloads_sources_720p = len([i for i in downloads_sources if i['quality'] == '720p'])
                self.downloads_sources_SD = len([i for i in downloads_sources if i['quality'] in ['SD', 'SCR', 'CAM', 'TELE']])
        if self.folder1_enabled == 'true' and not self.folder1_sources:
            try: folder1_sources = json.loads(control.window.getProperty('folder1_source_results'))
            except: folder1_sources = []
            if folder1_sources:
                self.folder1_sources = len(folder1_sources)
                self.folder1_sources_4K = len([i for i in folder1_sources if i['quality'] == '4K'])
                self.folder1_sources_1080p = len([i for i in folder1_sources if i['quality'] == '1080p'])
                self.folder1_sources_720p = len([i for i in folder1_sources if i['quality'] == '720p'])
                self.folder1_sources_SD = len([i for i in folder1_sources if i['quality'] in ['SD', 'SCR', 'CAM', 'TELE']])
        if self.folder2_enabled == 'true' and not self.folder2_sources:
            try: folder2_sources = json.loads(control.window.getProperty('folder2_source_results'))
            except: folder2_sources = []
            if folder2_sources:
                self.folder2_sources = len(folder2_sources)
                self.folder2_sources_4K = len([i for i in folder2_sources if i['quality'] == '4K'])
                self.folder2_sources_1080p = len([i for i in folder2_sources if i['quality'] == '1080p'])
                self.folder2_sources_720p = len([i for i in folder2_sources if i['quality'] == '720p'])
                self.folder2_sources_SD = len([i for i in folder2_sources if i['quality'] in ['SD', 'SCR', 'CAM', 'TELE']])
        if self.folder3_enabled == 'true' and not self.folder3_sources:
            try: folder3_sources = json.loads(control.window.getProperty('folder3_source_results'))
            except: folder3_sources = []
            if folder3_sources:
                self.folder3_sources = len(folder3_sources)
                self.folder3_sources_4K = len([i for i in folder3_sources if i['quality'] == '4K'])
                self.folder3_sources_1080p = len([i for i in folder3_sources if i['quality'] == '1080p'])
                self.folder3_sources_720p = len([i for i in folder3_sources if i['quality'] == '720p'])
                self.folder3_sources_SD = len([i for i in folder3_sources if i['quality'] in ['SD', 'SCR', 'CAM', 'TELE']])
        if self.folder4_enabled == 'true' and not self.folder4_sources:
            try: folder4_sources = json.loads(control.window.getProperty('folder4_source_results'))
            except: folder4_sources = []
            if folder4_sources:
                self.folder4_sources = len(folder4_sources)
                self.folder4_sources_4K = len([i for i in folder4_sources if i['quality'] == '4K'])
                self.folder4_sources_1080p = len([i for i in folder4_sources if i['quality'] == '1080p'])
                self.folder4_sources_720p = len([i for i in folder4_sources if i['quality'] == '720p'])
                self.folder4_sources_SD = len([i for i in folder4_sources if i['quality'] in ['SD', 'SCR', 'CAM', 'TELE']])
        if self.folder5_enabled == 'true' and not self.folder5_sources:
            try: folder5_sources = json.loads(control.window.getProperty('folder5_source_results'))
            except: folder5_sources = []
            if folder5_sources:
                self.folder5_sources = len(folder5_sources)
                self.folder5_sources_4K = len([i for i in folder5_sources if i['quality'] == '4K'])
                self.folder5_sources_1080p = len([i for i in folder5_sources if i['quality'] == '1080p'])
                self.folder5_sources_720p = len([i for i in folder5_sources if i['quality'] == '720p'])
                self.folder5_sources_SD = len([i for i in folder5_sources if i['quality'] in ['SD', 'SCR', 'CAM', 'TELE']])
        self.internalSources4K = self.furk_sources_4K + self.easynews_sources_4K + self.pm_cloud_sources_4K + self.rd_cloud_sources_4K + self.ad_cloud_sources_4K + self.local_sources_4K + self.downloads_sources_4K + self.folder1_sources_4K + self.folder2_sources_4K + self.folder3_sources_4K + self.folder5_sources_4K + self.folder5_sources_4K
        self.internalSources1080p = self.furk_sources_1080p + self.easynews_sources_1080p + self.pm_cloud_sources_1080p + self.rd_cloud_sources_1080p + self.ad_cloud_sources_1080p + self.local_sources_1080p + self.downloads_sources_1080p + self.folder1_sources_1080p + self.folder2_sources_1080p + self.folder3_sources_1080p + self.folder4_sources_1080p + self.folder5_sources_1080p
        self.internalSources720p = self.furk_sources_720p + self.easynews_sources_720p + self.pm_cloud_sources_720p + self.rd_cloud_sources_720p + self.ad_cloud_sources_720p + self.local_sources_720p + self.downloads_sources_720p + self.folder1_sources_720p + self.folder2_sources_720p + self.folder3_sources_720p + self.folder4_sources_720p + self.folder5_sources_720p
        self.internalSourcesSD = self.furk_sources_SD + self.easynews_sources_SD + self.pm_cloud_sources_SD + self.rd_cloud_sources_SD + self.ad_cloud_sources_SD + self.local_sources_SD + self.downloads_sources_SD + self.folder1_sources_SD + self.folder2_sources_SD + self.folder3_sources_SD + self.folder4_sources_SD + self.folder5_sources_SD
        self.internalSourcesTotal = self.internalSources4K + self.internalSources1080p + self.internalSources720p + self.internalSourcesSD

    def getConstants(self):
        from tikiscrapers import sources
        self.providerDatabase = os.path.join(xbmc.translatePath(__external__.getAddonInfo('profile')), "providers.db")
        self.sourceDict = sources()
        self.moduleProvider = __external__.getSetting('module.provider')
        try:
            self.hostDict = resolveurl.relevant_resolvers(order_matters=True)
            self.hostDict = [i.domains for i in self.hostDict if '*' not in i.domains]
            self.hostDict = [i.lower() for i in reduce(lambda x, y: x+y, self.hostDict)]
            self.hostDict = [x for y, x in enumerate(self.hostDict) if x not in self.hostDict[:y]]
        except Exception:
            self.hostDict = []
        self.hostprDict = ['1fichier.com', 'oboom.com', 'rapidgator.net', 'rg.to', 'uploaded.net', 'uploaded.to', 'uploadgig.com', 'ul.to',
                           'filefactory.com', 'nitroflare.com', 'turbobit.net', 'uploadrocket.net', 'multiup.org']
        self.hostcapDict = ['hugefiles.net', 'hugefiles.cc', 'vidup.me', 'vidup.tv', 'flashx.tv', 'flashx.to', 'flashx.sx',
                            'flashx.bz', 'flashx.cc', 'vshare.eu', 'vshare.io', 'thevideo.me', 'vev.io']
        self.hosthqDict = ['gvideo', 'google.com', 'thevideo.me', 'raptu.com', 'filez.tv', 'uptobox.com', 'uptostream.com', 'xvidstage.com', 'xstreamcdn.com', 'idtbox.com']
        self.hostblockDict = ['waaw.tv', 'hqq.watch', 'netu.tv', 'hqq.tv', 'waaw1.tv', 'netu.tv', 'movdivx.com', 'divxme.com', 'streamflv.com', 'speedvid.net',
                              'powvideo.net', 'powvideo.cc', 'estream.to', 'estream.nu', 'estream.xyz', 'openload.io', 'openload.co', 'oload.tv', 'oload.stream',
                              'oload.win', 'oload.download', 'oload.info', 'oload.icu', 'oload.fun', 'oload.space', 'oload.life', 'openload.pw', 'streamango.com',
                              'streamcherry.com', 'fruitstreams.com', 'fruitadblock.net', 'fruithosted.net', 'fruithosts.net', 'streamin.to', 'torba.se', 'rapidvideo.com',
                              'rapidvideo.is', 'rapidvid.to''zippyshare.com', 'youtube.com', 'facebook.com', 'twitch.tv', ]
        self.furk_enabled = __fen__.getSetting('provider.furk')
        self.easynews_enabled = __fen__.getSetting('provider.easynews')
        self.pm_cloud_enabled = __fen__.getSetting('provider.pm-cloud')
        self.rd_cloud_enabled = __fen__.getSetting('provider.rd-cloud')
        self.ad_cloud_enabled = __fen__.getSetting('provider.ad-cloud')
        self.local_enabled = __fen__.getSetting('provider.local')
        self.downloads_enabled = __fen__.getSetting('provider.downloads')
        self.folder1_enabled = __fen__.getSetting('provider.folder1')
        self.folder2_enabled = __fen__.getSetting('provider.folder2')
        self.folder3_enabled = __fen__.getSetting('provider.folder3')
        self.folder4_enabled = __fen__.getSetting('provider.folder4')
        self.folder5_enabled = __fen__.getSetting('provider.folder5')
        self.progressHeading = int(__fen__.getSetting('progress.heading'))
        self.internal_activated = True if 'true' in (self.furk_enabled, self.easynews_enabled, self.pm_cloud_enabled, self.rd_cloud_enabled, self.ad_cloud_enabled,
            self.folder1_enabled, self.folder2_enabled, self.folder3_enabled, self.folder4_enabled, self.folder5_enabled) else False
        self.furk_sources, self.furk_sources_4K, self.furk_sources_1080p, self.furk_sources_720p, self.furk_sources_SD = (0 for _ in range(5))
        self.easynews_sources, self.easynews_sources_4K, self.easynews_sources_1080p, self.easynews_sources_720p, self.easynews_sources_SD = (0 for _ in range(5))
        self.pm_cloud_sources, self.pm_cloud_sources_4K, self.pm_cloud_sources_1080p, self.pm_cloud_sources_720p, self.pm_cloud_sources_SD = (0 for _ in range(5))
        self.rd_cloud_sources, self.rd_cloud_sources_4K, self.rd_cloud_sources_1080p, self.rd_cloud_sources_720p, self.rd_cloud_sources_SD = (0 for _ in range(5))
        self.ad_cloud_sources, self.ad_cloud_sources_4K, self.ad_cloud_sources_1080p, self.ad_cloud_sources_720p, self.ad_cloud_sources_SD = (0 for _ in range(5))
        self.local_sources, self.local_sources_4K, self.local_sources_1080p, self.local_sources_720p, self.local_sources_SD = (0 for _ in range(5))
        self.downloads_sources, self.downloads_sources_4K, self.downloads_sources_1080p, self.downloads_sources_720p, self.downloads_sources_SD = (0 for _ in range(5))
        self.folder1_sources, self.folder1_sources_4K, self.folder1_sources_1080p, self.folder1_sources_720p, self.folder1_sources_SD = (0 for _ in range(5))
        self.folder2_sources, self.folder2_sources_4K, self.folder2_sources_1080p, self.folder2_sources_720p, self.folder2_sources_SD = (0 for _ in range(5))
        self.folder3_sources, self.folder3_sources_4K, self.folder3_sources_1080p, self.folder3_sources_720p, self.folder3_sources_SD = (0 for _ in range(5))
        self.folder4_sources, self.folder4_sources_4K, self.folder4_sources_1080p, self.folder4_sources_720p, self.folder4_sources_SD = (0 for _ in range(5))
        self.folder5_sources, self.folder5_sources_4K, self.folder5_sources_1080p, self.folder5_sources_720p, self.folder5_sources_SD = (0 for _ in range(5))
        self.internalSourcesTotal, self.internalSources4K, self.internalSources1080p, self.internalSources720p, self.internalSourcesSD = (0 for _ in range(5))

    def exportSettings(self):
        try:
            __external__.setSetting('torrent.min.seeders', __fen__.getSetting('torrent.min.seeders'))
        except: pass


