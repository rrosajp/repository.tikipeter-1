# -*- coding: utf-8 -*-
import os
from windows.base_dialog import BaseDialog
from windows.base_contextmenu import BaseContextMenu
from indexers.images import slideshow_image
from modules.nav_utils import translate_path
from modules.utils import local_string as ls
from modules.settings import skin_location
from modules.utils import logger

addon_dir = translate_path('special://home/addons/plugin.video.fen')
icon = os.path.join(addon_dir, "icon.png")
fanart = os.path.join(addon_dir, "fanart.png")

class ThumbViewerXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		super(ThumbViewerXML, self).__init__(self, args)
		self.window_id = 2000
		self.image_info = kwargs.get('image_info')
		self.rolling_count = kwargs.get('rolling_count')
		self.all_images_json = kwargs.get('all_images_json')

	def onInit(self):
		super(ThumbViewerXML, self).onInit()
		self.make_items()
		self.win = self.getControl(self.window_id)
		self.win.addItems(self.item_list)
		self.set_properties()
		self.setFocusId(self.window_id)

	def run(self):
		self.doModal()
		try: del self.cm
		except: pass

	def onAction(self, action):
		action_id = action.getId()
		position = self.get_position(self.window_id)
		# logger('current position', position)
		# if action_id in (1,2,3,4) and self.total_items == 48:
		# 	if position >= 45:
		# 		image_info = imdb_image_results(imdb_id, page_no, self.rolling_count)
		# 		self.make_items(image_info, self.page_no+1)
		# 		self.win.addItems(self.item_list)
		if action_id in self.closing_actions:
			self.close()
		chosen_listitem = self.item_list[position]
		if action_id in self.selection_actions:
			ending_position = slideshow_image(self.getProperty('tikiskins.all_images'), self.get_position(self.window_id))
			self.win.selectItem(ending_position)
		elif action_id in self.context_actions:
			self.cm = ThumbContextMenuXML('contextmenu.xml', skin_location(), list_item=chosen_listitem)
			cm_choice = self.cm.run()
			if cm_choice:
				self.execute_code(cm_choice)
			del self.cm

	def set_properties(self):
		self.setProperty('tikiskins.all_images', self.all_images_json)

	def make_items(self):
		def builder():
			for item in self.image_info:
				self.rolling_count += 1
				name = '%s_%03d' % (item['title'], self.rolling_count)
				listitem = self.make_listitem()
				listitem.setProperty('tikiskins.thumb', item['thumb'])
				listitem.setProperty('tikiskins.image', item['image'])
				listitem.setProperty('tikiskins.name', name)
				yield listitem
		self.item_list = list(builder())
		self.total_items = len(self.item_list)


class ThumbContextMenuXML(BaseContextMenu):
	def __init__(self, *args, **kwargs):
		super(ThumbContextMenuXML, self).__init__(self, args)
		self.window_id = 2002
		self.list_item = kwargs['list_item']
		self.item_list = []
		self.selected = None

	def onInit(self):
		super(ThumbContextMenuXML, self).onInit()
		self.make_context_menu()
		self.set_properties()
		win = self.getControl(self.window_id)
		win.addItems(self.item_list)
		self.setFocusId(self.window_id)

	def run(self):
		self.doModal()
		return self.selected

	def onAction(self, action):
		action_id = action.getId()
		if action_id in self.selection_actions:
			chosen_listitem = self.item_list[self.get_position(self.window_id)]
			self.selected = chosen_listitem.getProperty('tikiskins.context.action')
			return self.close()
		elif action_id in self.context_actions:
			return self.close()
		elif action_id in self.closing_actions:
			return self.close()

	def set_properties(self):
		self.setProperty('tikiskins.context.highlight', 'royalblue')

	def make_context_menu(self):
		image_url = self.list_item.getProperty('tikiskins.image')
		thumb_url = self.list_item.getProperty('tikiskins.thumb')
		name = self.list_item.getProperty('tikiskins.name')
		down_file_params = {'mode': 'downloader', 'name': name, 'url': (image_url, thumb_url), 'db_type': 'image', 'image': icon}
		self.item_list.append(self.make_item(ls(32747), 'RunPlugin(%s)', down_file_params))
		
