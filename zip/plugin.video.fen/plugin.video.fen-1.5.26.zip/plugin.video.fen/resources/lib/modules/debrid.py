import xbmc, xbmcgui, xbmcaddon, xbmcvfs
import os
import time
import json
import requests
import datetime
import sqlite3 as database
from resources.lib.modules.utils import chunks
from resources.lib.modules.workers import Thread
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.fen'
__addon__ = xbmcaddon.Addon(id=__addon_id__)

progressDialog = xbmcgui.DialogProgress()

class RealDebrid:
    def __init__(self):
        self.base_url = "https://api.real-debrid.com/rest/1.0/"
        self.auth_url = 'https://api.real-debrid.com/oauth/v2/'
        self.device_url = "device/code?%s"
        self.credentials_url = "device/credentials?%s"
        self.client_ID = __addon__.getSetting('rd.client_id')
        if self.client_ID == '': self.client_ID = 'X245A4XAIBGVM'
        self.token = __addon__.getSetting('rd.token')
        self.refresh = __addon__.getSetting('rd.refresh')
        self.secret = __addon__.getSetting('rd.secret')
        self.device_code = ''
        self.auth_timeout = 0
        self.auth_step = 0

    def rd_enabled(self):
        if self.token == '':
            return False
        else:
            return True

    def auth_loop(self):
        if progressDialog.iscanceled():
            progressDialog.close()
            return
        time.sleep(self.auth_step)
        url = "client_id=%s&code=%s" % (self.client_ID, self.device_code)
        url = self.auth_url + self.credentials_url % url
        response = json.loads(requests.get(url).text)
        if 'error' in response:
            return
        try:
            progressDialog.close()
            __addon__.setSetting('rd.client_id', response['client_id'])
            __addon__.setSetting('rd.secret', response['client_secret'])
            self.secret = response['client_secret']
            self.client_ID = response['client_id']
        except:
             xbmcgui.Dialog().ok('Real Debrid Authorization', 'Authentication Failed. Try Again.')
        return

    def auth(self):
        self.secret = ''
        self.client_ID = 'X245A4XAIBGVM'
        url = "client_id=%s&new_credentials=yes" % self.client_ID
        url = self.auth_url + self.device_url % url
        response = json.loads(requests.get(url).text)
        progressDialog.create('Real Debrid Authorization', '')
        progressDialog.update(-1, 'Real Debrid Authorization','Navigate to: [B]https://real-debrid.com/device[/B]',
                                    'Enter the following code: [B]%s[/B]'% response['user_code'])
        self.auth_timeout = int(response['expires_in'])
        self.auth_step = int(response['interval'])
        self.device_code = response['device_code']

        while self.secret == '':
            self.auth_loop()
        self.get_token()

    def get_token(self):
        if self.secret is '':
            return
        data = {'client_id': self.client_ID,
                'client_secret': self.secret,
                'code': self.device_code,
                'grant_type': 'http://oauth.net/grant_type/device/1.0'}
        url = '%stoken' % self.auth_url
        response = requests.post(url, data=data).text
        response = json.loads(response)
        self.token = response['access_token']
        self.refresh = response['refresh_token']
        __addon__.setSetting('rd.token', response['access_token'])
        __addon__.setSetting('rd.refresh', response['refresh_token'])
        __addon__.setSetting('rd.expiry', str(time.time() + int(response['expires_in'])))
        username = self._get('user')['username']
        __addon__.setSetting('rd.username', username)
        xbmcgui.Dialog().ok('Real Debrid Authorization', 'Authentication Successful.')

    def refreshToken(self):
        data = {'client_id': self.client_ID,
                'client_secret': self.secret,
                'code': self.refresh,
                'grant_type': 'http://oauth.net/grant_type/device/1.0'}
        url = self.auth_url + 'token'
        response = requests.post(url, data=data)
        response = json.loads(response.text)
        if 'access_token' in response: self.token = response['access_token']
        if 'refresh_token' in response: self.refresh = response['refresh_token']
        __addon__.setSetting('rd.token', self.token)
        __addon__.setSetting('rd.refresh', self.refresh)
        __addon__.setSetting('rd.expiry', str(time.time() + int(response['expires_in'])))

    def check_cache(self, hashes):
        hash_string = '/'.join(hashes)
        url = 'torrents/instantAvailability/%s' % hash_string
        result = self._get(url)
        return result

    def _get(self, url):
        original_url = url
        url = self.base_url + url
        if self.token == '': return None
        if '?' not in url:
            url += "?auth_token=%s" % self.token
        else:
            url += "&auth_token=%s" % self.token
        response = requests.get(url).text
        if 'bad_token' in response or 'Bad Request' in response:
            self.refreshToken()
            response = self._get(original_url)
        try:
            return json.loads(response)
        except:
            return response

class Premiumize:
    def __init__(self):
        self.client_id = '663882072'
        self.user_agent = 'Fen for Kodi'
        self.token_path = 'https://www.premiumize.me/token'
        self.token = __addon__.getSetting('pm.token')
        self.base_url = 'https://www.premiumize.me/api'
        self.cache_path = '%s/cache/check' % self.base_url
        self.account_url = "%s/account/info" % self.base_url

    def pm_enabled(self):
        if self.token == '':
            return False
        else:
            return True

    def auth_loop(self):
        if progressDialog.iscanceled():
            progressDialog.close()
            return
        time.sleep(5)
        data = {'grant_type': 'device_code', 'client_id': self.client_id, 'code': self.device_code}
        response = json.loads(requests.post(self.token_path, data=data, headers=self.headers).text)
        if 'error' in response:
            return
        try:
            progressDialog.close()
            self.token = str(response['access_token'])
            __addon__.setSetting('pm.token', self.token)
        except:
             xbmcgui.Dialog().ok('Premiumize Authorization', 'Authentication failed. Try Again.')
        return

    def auth(self):
        self.token = ''
        self.headers = {'User-Agent': self.user_agent, 'Authorization': 'Bearer %s' % self.token}
        data = {'response_type': 'device_code', 'client_id': self.client_id}
        response = json.loads(requests.post(self.token_path, data=data, headers=self.headers).text)
        progressDialog.create('Premiumize Authorization', '')
        progressDialog.update(-1, 'Premiumize Authentication','Navigate to: [B]%s[/B]' % response.get('verification_uri'),
                                    'Enter the following code: [B]%s[/B]'% response.get('user_code'))
        self.device_code = response['device_code']
        while self.token == '':
            self.auth_loop()
        if self.token is None: return
        account_info = self.get_account()
        __addon__.setSetting('pm.account_id', str(account_info['customer_id']))
        xbmcgui.Dialog().ok('Premiumize Authorization', 'Authentication Successful.')

    def get_account(self):
        self.headers = {'User-Agent': self.user_agent, 'Authorization': 'Bearer %s' % self.token}
        response = json.loads(requests.post(self.account_url, data={}, headers=self.headers).text)
        return response

    def check_cache(self, hashes):
        if self.token == '': return None
        self.headers = {'User-Agent': self.user_agent, 'Authorization': 'Bearer %s' % self.token}
        data = {'items[]': hashes}
        response = json.loads(requests.post(self.cache_path, data=data, headers=self.headers).text)
        return response

class DebridCheck:
    def __init__(self):
        self.db_cache = DebridCache()
        self.db_cache.check_database()
        self.check_cache_list = []
        self.cached_hashes = []
        self.main_threads = []
        self.rd_cached_hashes = []
        self.rd_hashes_unchecked = []
        self.rd_query_threads = []
        self.rd_process_results = []
        self.pm_cached_hashes = []
        self.pm_hashes_unchecked = []
        self.pm_process_results = []

    def debrid_enabled(self):
        if not RealDebrid().rd_enabled() and not Premiumize().pm_enabled():
            return False
        else:
            return True

    def run(self, hash_list, background):
        self.hash_list = hash_list
        if not background:
            progressDialog.create('Debrid Cached Torrents', '')
            progressDialog.update(-1, 'Checking for Cached Torrents', 'Checking Debrid Providers', 'Please Wait...')
        self._query_local_cache(self.hash_list)
        [i.start() for i in self.check_cache_list]
        [i.join() for i in self.check_cache_list]
        self.rd_cached_hashes = [str(i[0]) for i in self.cached_hashes if str(i[1]) == 'rd' and str(i[2]) == 'True']
        self.pm_cached_hashes = [str(i[0]) for i in self.cached_hashes if str(i[1]) == 'pm' and str(i[2]) == 'True']
        self.rd_hashes_unchecked = [i for i in self.hash_list if not any([h for h in self.cached_hashes if str(h[0]) == i and str(h[1]) =='rd'])]
        self.pm_hashes_unchecked = [i for i in self.hash_list if not any([h for h in self.cached_hashes if str(h[0]) == i and str(h[1]) =='pm'])]
        if self.rd_hashes_unchecked or self.pm_hashes_unchecked:
            if self.rd_hashes_unchecked: self.main_threads.append(Thread(self.RD_cache_checker))
            if self.pm_hashes_unchecked: self.main_threads.append(Thread(self.PM_cache_checker))
            [i.start() for i in self.main_threads]
            [i.join() for i in self.main_threads]
        progressDialog.close()
        return self.rd_cached_hashes, self.pm_cached_hashes

    def RD_cache_checker(self):
        hash_chunk_list = list(chunks(self.rd_hashes_unchecked, 100))
        for item in hash_chunk_list: self.rd_query_threads.append(Thread(self._rd_lookup, item))
        [i.start() for i in self.rd_query_threads]
        [i.join() for i in self.rd_query_threads]
        self._add_to_local_cache(self.rd_process_results, 'rd')

    def PM_cache_checker(self):
        result = self._pm_lookup(self.pm_hashes_unchecked)
        self._add_to_local_cache(self.pm_process_results, 'pm')

    def _rd_lookup(self, chunk):
        try:
            rd_cache_get = RealDebrid().check_cache(chunk)
            for h in chunk:
                cached = 'False'
                if h in rd_cache_get:
                    info = rd_cache_get[h]
                    if isinstance(info, dict) and len(info.get('rd')) > 0:
                        self.rd_cached_hashes.append(h)
                        cached = 'True'
                self.rd_process_results.append((h, cached))
        except: pass

    def _pm_lookup(self, hash_list):
        try:
            pm_cache = Premiumize().check_cache(hash_list)['response']
            for c, h in enumerate(hash_list):
                cached = 'False'
                if pm_cache[c] is True:
                    self.pm_cached_hashes.append(h)
                    cached = 'True'
                self.pm_process_results.append((h, cached))
        except: pass

    def _query_local_cache(self, _hash):
        cached = self.db_cache.get_all(_hash)
        if cached:
            self.cached_hashes = cached

    def _add_to_local_cache(self, _hash, debrid):
        self.db_cache.set_many(_hash, debrid)

class DebridCache:
    def __init__(self):
        self.datapath = xbmc.translatePath("special://userdata/addon_data/plugin.video.fen")
        self.dbfile = os.path.join(self.datapath, "debridcache.db")

    def get_all(self, hash_list):
        result = None
        try:
            current_time = self._get_timestamp(datetime.datetime.now())
            dbcon = database.connect(self.dbfile, timeout=40.0)
            dbcur = dbcon.cursor()
            dbcur.execute('SELECT * FROM debrid_data WHERE hash in ({0})'.format(', '.join('?' for _ in hash_list)), hash_list)
            cache_data = dbcur.fetchall()
            if cache_data:
                if cache_data[0][3] > current_time:
                    result = cache_data
                else:
                    self.remove_many(cache_data)
        except: pass
        return result

    def remove_many(self, old_cached_data):
        try:
            old_cached_data = [(str(i[0]),) for i in old_cached_data]
            dbcon = database.connect(self.dbfile, timeout=40.0)
            dbcur = dbcon.cursor()
            dbcur.executemany("DELETE FROM debrid_data WHERE hash=?", old_cached_data)
            dbcon.commit()
        except: pass

    def set_many(self, hash_list, debrid, expiration=datetime.timedelta(hours=1)):
        try:
            expires = self._get_timestamp(datetime.datetime.now() + expiration)
            insert_list = [(i[0], debrid, i[1], expires) for i in hash_list]
            dbcon = database.connect(self.dbfile, timeout=40.0)
            dbcur = dbcon.cursor()
            dbcur.executemany("INSERT INTO debrid_data VALUES (?, ?, ?, ?)", insert_list)
            dbcon.commit()
        except: pass

    def check_database(self):
        if not xbmcvfs.exists(self.datapath):
            xbmcvfs.mkdirs(self.datapath)
        if not xbmcvfs.exists(self.dbfile):
            dbcon = database.connect(self.dbfile)
            dbcon.execute("""CREATE TABLE IF NOT EXISTS debrid_data
                          (hash text not null, debrid text not null, cached text, expires integer, unique (hash, debrid))
                            """)
            dbcon.close()

    def clear_database(self):
        try:
            dbcon = database.connect(self.dbfile)
            dbcur = dbcon.cursor()
            dbcur.execute("DELETE FROM debrid_data")
            dbcur.execute("VACUUM")
            dbcon.commit()
            dbcon.close()
            return 'success'
        except: return 'failure'

    def _get_timestamp(self, date_time):
        return int(time.mktime(date_time.timetuple()))




