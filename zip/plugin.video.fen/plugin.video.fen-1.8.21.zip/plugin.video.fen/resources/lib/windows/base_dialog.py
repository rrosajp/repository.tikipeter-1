# -*- coding: utf-8 -*-
import xbmcgui
from modules.utils import logger

class BaseDialog(xbmcgui.WindowXMLDialog):
	def __init__(self, xml_file, location):
		xbmcgui.WindowXMLDialog.__init__(self, xml_file, location)

	def make_listitem(self):
		return xbmcgui.ListItem()

	def make_contextmenu(self, context_list):
		logger('context_list', context_list)
		return xbmcgui.Dialog().contextmenu(context_list)
	
	def get_position(self, window_id):
		return self.getControl(window_id).getSelectedPosition()
