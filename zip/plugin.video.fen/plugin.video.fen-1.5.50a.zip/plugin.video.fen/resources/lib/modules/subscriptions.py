import xbmc, xbmcgui, xbmcaddon, xbmcvfs
import os
import json
from resources.lib.apis.trakt_api import get_trakt_movie_id, get_trakt_tvshow_id
from resources.lib.modules.kodi_library import get_library_video
from resources.lib.modules.nav_utils import notification, close_all_dialog
from resources.lib.modules.utils import to_utf8, clean_file_name
import tikimeta
from resources.lib.modules import settings
# from resources.lib.modules.utils import logger

__addon__ = xbmcaddon.Addon(id='plugin.video.fen')
__addon_profile__ = xbmc.translatePath(__addon__.getAddonInfo('profile'))

class Subscriptions:
    def __init__(self, db_type=None, tmdb_id=None, action=None, orig_mode=None):
        self.db_type = db_type
        self.tmdb_id = tmdb_id #str
        self.action = action
        self.orig_mode = orig_mode
        if self.db_type: self.path = settings.movies_directory() if self.db_type == 'movie' else settings.tv_show_directory()

    def add_remove(self, silent=False):
        self.add_remove_constants()
        if self.check_exists() and self.action == 'add':
            return notification('[B]%s[/B] already in Subscriptions' % self.rootname, 4500)
        self.add_remove_movie(silent) if self.db_type == 'movie' else self.add_remove_tvshow(silent)
        if self.orig_mode in ('subscriptions_tvshows', 'subscriptions_movies') and self.action == 'remove':
            xbmc.executebuiltin('Container.Refresh')

    def add_remove_movie(self, silent=False):
        if self.action == 'add':
            in_library = get_library_video('movie', self.title, self.year) if settings.skip_duplicates() else False
            if in_library: return
            self.make_folder()
            self.make_nfo()
            stream_file = self.create_movie_strm_files()
            params = to_utf8({'mode': 'play_media', 'library': 'True', 'query': self.rootname, 'poster': self.meta['poster'], 'year': self.year, 'plot': self.meta['plot'], 'title': self.title, 'tmdb_id': self.meta['tmdb_id'], 'vid_type':'movie'})
            self.make_stream(stream_file, params)
        elif self.action == 'remove':
            self.remove_folder()
        if not silent: notification(self.notify % self.rootname, 4500)

    def add_remove_tvshow(self, silent=False):
        if self.action == 'add':
            self.make_folder()
            self.make_nfo()
            self.create_tvshow_strm_files()
        elif self.action == 'remove':
            self.remove_folder()
        if not silent: notification(self.notify % self.rootname, 4500)

    def get_subscriptions(self):
        from resources.lib.modules.utils import read_from_file
        subscription_list = []
        dirs, files = xbmcvfs.listdir(self.path)
        for item in dirs:
            item_path = os.path.join(self.path, item)
            dirs2, files2 = xbmcvfs.listdir(item_path)
            for item2 in files2:
                if item2.endswith('.nfo'):
                    address = read_from_file(os.path.join(item_path, item2))
                    info = address.split('/')[4].split('-', 1)
                    tmdb_id = info[0]
                    title = info[1].replace('-', ' ')
                    subscription_list.append({'media_id': tmdb_id, 'title': title})
        return subscription_list

    def clear_subscriptions(self, confirm=True, silent=False, db_type=None):
        if confirm:
            if not self.subscription_choice('Choose Subscriptions to Erase', 'Continuing will erase all your %s'): return
        self.db_type = self.choice[1] if not db_type else db_type
        self.path = settings.movies_directory() if self.db_type == 'movie' else settings.tv_show_directory()
        subscriptions = self.get_subscriptions()
        if len(subscriptions) == 0:
            return notification('%s Subscriptions is already Empty' % self.db_type.upper(), 4500)
        self.remove_folder(self.path)
        self.make_folder(self.path)
        if not silent: notification('%s Subscriptions has been Cleared' % self.db_type.upper(), 4500)

    def update_subscriptions(self, suppress_extras=False):
        from datetime import datetime, timedelta
        self.db_type = 'tvshow'
        self.action = 'add'
        self.path = settings.tv_show_directory()
        subscriptions = self.get_subscriptions()
        if not subscriptions:
            return notification('No TV Show Subscriptions to Update', 1200)
        hours = settings.subscription_timer()
        close_all_dialog()
        bg_dialog = xbmcgui.DialogProgressBG()
        bg_dialog.create('Please Wait', 'Preparing Subscription Update...')
        for count, item in enumerate(subscriptions, 1):
            self.tmdb_id = item['media_id']
            self.add_remove_constants()
            self.add_remove_tvshow(silent=True)
            display = 'Fen Updating - [B][I]%s[/I][/B]' % self.rootname
            bg_dialog.update(int(float(count) / float(len(subscriptions)) * 100), 'Please Wait', '%s' % display)
            xbmc.sleep(300)
        __addon__.setSetting('service_time', str(datetime.now() + timedelta(hours=hours)).split('.')[0])
        xbmc.sleep(500)
        bg_dialog.close()
        notification('Fen Subscriptions Updated', 4500)
        if settings.update_library_after_service() and not suppress_extras: xbmc.executebuiltin('UpdateLibrary(video)')

    def add_trakt_subscription_listitem(self, db_type, ids, count, chunk_list_length, path, dialog):
        try:
            get_ids = get_trakt_movie_id if db_type in ('movie', 'movies') else get_trakt_tvshow_id
            meta_action = tikimeta.movie_meta if db_type in ('movie', 'movies') else tikimeta.tvshow_meta
            tmdb_id = get_ids(ids)
            address_insert = 'movie' if db_type in ('movie', 'movies') else 'tv'
            meta = meta_action('tmdb_id', tmdb_id)
            title = clean_file_name(meta['title'])
            year = meta['year'] if 'year' in meta else ''
            rootname = '{0} ({1})'.format(title, year) if year else title
            folder = os.path.join(path, rootname + '/')
            nfo_filename = rootname + '.nfo' if db_type in ('movie', 'movies') else 'tvshow.nfo'
            nfo_filepath = os.path.join(folder, nfo_filename)
            nfo_content = "https://www.themoviedb.org/%s/%s-%s" % (address_insert, str(meta['tmdb_id']), title.lower().replace(' ', '-'))
            self.make_folder(folder)
            self.make_nfo(nfo_filepath, nfo_content)
            if db_type in ('movie', 'movies'):
                in_library = get_library_video('movie', title, year) if settings.skip_duplicates() else False
                if in_library: return
                stream_file = self.create_movie_strm_files(folder, rootname)
                params = to_utf8({'mode': 'play_media', 'library': 'True', 'query': rootname, 'poster': meta['poster'], 'year': year, 'plot': meta['plot'], 'title': title, 'tmdb_id': meta['tmdb_id'], 'vid_type':'movie'})
                self.make_stream(stream_file, params)
            else:
                self.create_tvshow_strm_files(meta, folder, tmdb_id, title, year)
            dialog.update(int(float(count) / float(chunk_list_length) * 100), '', 'Adding: [B]%s[/B]' % rootname)
        except Exception as e:
            from resources.lib.modules.utils import logger
            logger('Exception', e)
            pass

    def remove_trakt_subscription_listitem(self, db_type, media_id, count, chunk_list_length, path, dialog):
        try:
            meta_action = tikimeta.movie_meta if db_type in ('movie', 'movies') else tikimeta.tvshow_meta
            tmdb_id = media_id
            meta = meta_action('tmdb_id', tmdb_id)
            title = clean_file_name(meta['title'])
            year = meta['year'] if 'year' in meta else ''
            rootname = '{0} ({1})'.format(title, year) if year else title
            folder = os.path.join(path, rootname + '/')
            self.remove_folder(folder)
            dialog.update(int(float(count) / float(chunk_list_length) * 100), 'Please Wait...', 'Removing: [B]%s[/B]' % rootname)
        except: pass

    def create_movie_strm_files(self, folder=None, rootname=None):
        folder = self.folder if not folder else folder
        rootname = self.rootname if not rootname else rootname
        return os.path.join(folder, rootname + '.strm')

    def create_tvshow_strm_files(self, meta=None, folder=None, tmdb_id=None, title=None, year=None):
        from datetime import date
        from resources.lib.modules.utils import to_utf8
        from resources.lib.modules.kodi_library import get_library_video
        meta = self.meta if not meta else meta
        folder = self.folder if not folder else folder
        tmdb_id = self.tmdb_id if not tmdb_id else tmdb_id
        title = self.title if not title else title
        year = self.year if not year else year
        skip_duplicates = settings.skip_duplicates()
        season_data = tikimeta.all_episodes_meta(meta['tmdb_id'], meta['tvdb_id'], meta['tvdb_summary']['airedSeasons'], meta['season_data'])
        season_data = [i for i in season_data if not i['season_number'] == 0]
        for i in season_data:
            season_path = os.path.join(folder, 'Season ' + str(i['season_number']))
            self.make_folder(season_path)
            ep_data = i['episodes_data']
            for item in ep_data:
                in_library = get_library_video('episode', title, year, item['airedSeason'], item['airedEpisodeNumber']) if skip_duplicates else None
                if not in_library:
                    first_aired = item['firstAired'] if 'firstAired' in item else None
                    try:
                        d = first_aired.split('-')
                        episode_date = date(int(d[0]), int(d[1]), int(d[2]))
                    except: episode_date = date(2100,10,24)
                    if date.today() > episode_date:
                        display = "%s S%.2dE%.2d" % (title, int(item['airedSeason']), int(item['airedEpisodeNumber']))
                        stream_file = os.path.join(season_path, str(display) + '.strm')
                        params = to_utf8({'mode': 'play_media', 'library': 'True', 'query': title, 'year': year, 'plot': item['overview'], 'poster': meta['poster'], 'season': item['airedSeason'], 'episode': item['airedEpisodeNumber'], 'ep_name': item['episodeName'], 'premiered': item['firstAired'], 'tmdb_id': tmdb_id, 'vid_type':'episode'})
                        self.make_stream(stream_file, params)

    def make_folder(self, folder=None):
        folder = self.folder if not folder else folder
        xbmcvfs.mkdir(folder)

    def remove_folder(self, folder=None):
        folder = self.folder if not folder else folder
        xbmcvfs.rmdir(folder, True)

    def make_nfo(self, nfo_filepath=None, nfo_content=None):
        nfo_filepath = self.nfo_filepath if not nfo_filepath else nfo_filepath
        nfo_content = self.nfo_content if not nfo_content else nfo_content
        if not xbmcvfs.exists(nfo_filepath):
            nfo_file = xbmcvfs.File(nfo_filepath, 'w')
            nfo_file.write(nfo_content)
            nfo_file.close()

    def make_stream(self, stream_file, params):
        if not xbmcvfs.exists(stream_file):
            from resources.lib.modules.nav_utils import build_url
            file = xbmcvfs.File(stream_file, 'w')
            content = build_url(params)
            file.write(str(content))
            file.close()

    def check_exists(self):
        tmdb_ids = [i['media_id'] for i in self.get_subscriptions()]
        if str(self.meta['tmdb_id']) in tmdb_ids: return True
        else: return False

    def add_remove_constants(self):
        meta_action = tikimeta.movie_meta if self.db_type == 'movie' else tikimeta.tvshow_meta
        address_insert = 'movie' if self.db_type == 'movie' else 'tv'
        self.meta = meta_action('tmdb_id', self.tmdb_id)
        self.title = clean_file_name(self.meta['title'])
        self.year = self.meta['year'] if 'year' in self.meta else ''
        self.rootname = '{0} ({1})'.format(self.title, self.year) if self.year else self.title
        self.folder = os.path.join(self.path, self.rootname + '/')
        self.nfo_filename = self.rootname + '.nfo' if self.db_type == 'movie' else 'tvshow.nfo'
        self.nfo_filepath = os.path.join(self.folder, self.nfo_filename)
        self.nfo_content = "https://www.themoviedb.org/%s/%s-%s" % (address_insert, str(self.meta['tmdb_id']), self.title.lower().replace(' ', '-'))
        self.notify = '[B]%s[/B] added to Subscriptions' if self.action == 'add' else '[B]%s[/B] removed from Subscriptions'

    def subscription_choice(self, heading, message):
        sl = [('Movie Subscriptions', 'movie'), ('TV Show Subscriptions', 'tvshow')]
        choice = xbmcgui.Dialog().select(heading, [i[0] for i in sl])
        if choice < 0: return
        confirm = xbmcgui.Dialog().yesno('Are you sure?', message % sl[choice][0])
        if not confirm: return False
        self.choice = sl[choice]
        return True

def retrieve_subscriptions(db_type, page_no, letter):
    from resources.lib.modules.nav_utils import paginate_list
    from resources.lib.modules.utils import title_key
    limit = 20
    data = Subscriptions(db_type).get_subscriptions()
    original_list = sorted(data, key=lambda k: title_key(k['title']))
    paginated_list, total_pages = paginate_list(original_list, page_no, letter, limit)
    return paginated_list, total_pages, limit

def subscriptions_add_list(db_type):
    from resources.lib.modules.utils import chunks
    from resources.lib.modules.workers import Thread
    from resources.lib.modules.trakt_cache import clear_trakt_list_data
    from resources.lib.apis.trakt_api import get_trakt_list_selection
    from resources.lib.modules.nav_utils import open_settings

    def _process(db_type, ids, count, chunk_list_length, path, sleep, dialog):
        ''' Process each item in the chunk with a small (growing) pause between each item '''
        xbmc.sleep(sleep)
        Subscriptions().add_trakt_subscription_listitem(db_type, ids, count, chunk_list_length, path, dialog)
    
    # Set the variables
    variables = ('Movies', 'movies', 'movie', 'trakt.subscriptions_movie', 'trakt.subscriptions_movie_display', '8.6') if db_type == 'movie' else ('TV Shows', 'shows', 'show', 'trakt.subscriptions_show', 'trakt.subscriptions_show_display', '8.7')
    dialog_display = variables[0]
    trakt_list_type = variables[1]
    trakt_dbtype = variables[2]
    main_setting = variables[3]
    display_setting = variables[4]
    open_setting = variables[5]
    clear_library = False
    cancelled = False
    supplied_list = False
    chunk_amount = 10 if db_type == 'movie' else 5
    path = settings.movies_directory() if db_type == 'movie' else settings.tv_show_directory()

    # Refresh trakt lists info
    for i in ('my_lists', 'liked_lists'):
        try: clear_trakt_list_data(i)
        except: pass

    # Get the chosen list
    trakt_list = get_trakt_list_selection(list_choice='subscriptions')
    if not trakt_list: return open_settings(open_setting)

    # Set the new list and return if list is None
    __addon__.setSetting(main_setting, json.dumps(trakt_list))
    __addon__.setSetting(display_setting, trakt_list['name'])
    if trakt_list['name'].lower() == 'none': return open_settings(open_setting)

    # Confirm Continue
    if not xbmcgui.Dialog().yesno('Are you sure?','Fen will add all [B]%s[/B] from [B]%s[/B] to your Fen Subscriptions, and monitor this list for changes. Do you wish to continue?' % (dialog_display, trakt_list['name'])):
        return open_settings(open_setting)

    # See if there are current subscriptions and confirm Deletion if present
    current_subscriptions = Subscriptions(db_type).get_subscriptions()
    if len(current_subscriptions) > 0:
        if not xbmcgui.Dialog().yesno('Current Subscriptions Found!','You currently have items in your [B]%s[/B] Subscription. Fen will delete these before adding this new list. Do you wish to continue?' % (dialog_display)):
            return open_settings(open_setting)
        clear_library = True
        Subscriptions().clear_subscriptions(confirm=False, silent=True, db_type=db_type)

    # Get the contents of the chosen list if not passed
    dialog = xbmcgui.DialogProgressBG()
    dialog.create('Please Wait', 'Preparing Trakt List Info...')
    if trakt_list['name'] in ('Collection', 'Watchlist'):
        from resources.lib.modules.trakt_cache import clear_trakt_collection_watchlist_data
        from resources.lib.apis.trakt_api import trakt_fetch_collection_watchlist
        # clear_trakt_collection_watchlist_data(trakt_list['name'].lower(), db_type)
        list_contents = trakt_fetch_collection_watchlist(trakt_list['name'].lower(), trakt_list_type)
    else:
        from resources.lib.apis.trakt_api import get_trakt_list_contents
        from resources.lib.modules.trakt_cache import clear_trakt_list_contents_data
        # clear_trakt_list_contents_data(user=trakt_list['user'], slug=trakt_list['slug'])
        list_contents = get_trakt_list_contents(trakt_list['user'], trakt_list['slug'])
        list_contents = [{'media_ids': i[trakt_dbtype]['ids'], 'title': i[trakt_dbtype]['title']} for i in list_contents if i['type'] == trakt_dbtype]

    # Try to make sure TMDb is present and set
    for i in list_contents:
        if i['media_ids']['tmdb'] == None:
            i['media_ids']['tmdb'] = get_trakt_tvshow_id(i['media_ids'])

    # Get the length of the chosen list and break the chosen list into manageable chunks
    list_length = len(list_contents)
    chunk_list = list(chunks(list_contents, chunk_amount))
    chunk_list_length = len(chunk_list)

    # Begin processing the chunks
    for count, chunk in enumerate(chunk_list, 1):
        if xbmc.abortRequested == True: return sys.exit()
        try:
            if dialog.iscanceled():
                cancelled = True
                break
        except Exception:
            pass
        threads = []
        sleep = 0
        for item in chunk:
            threads.append(Thread(_process, db_type, item['media_ids'], count, chunk_list_length, path, sleep, dialog))
            sleep += 200
        [i.start() for i in threads]
        [i.join() for i in threads]
    dialog.close()

    # Final information on result of Subscription list setting
    end_dialog = 'Operation Cancelled! Not all items from [B]%s[/B] were added.' if cancelled else '[B]%s[/B] added to Subscriptions.'
    xbmcgui.Dialog().ok('Fen Subscriptions', end_dialog % trakt_list['name'])

    # If previous Subscription items were found, ask if user wants to clean them from Kodi's Library
    if clear_library:
        if xbmcgui.Dialog().yesno('Fen Subscriptions','Do you wish to clear Kodi\'s Library of your previous Subscription items?'):
            import time
            xbmc.executebuiltin('CleanLibrary(video)')
            time.sleep(3)
            # Pause script whilst Library is cleaning
            while xbmc.getCondVisibility("Window.IsVisible(ProgressDialog)"):
                time.sleep(1)

    # Ask if user wants to scan new Subscription items into Kodi's Library
    if xbmcgui.Dialog().yesno('Fen Subscriptions','Do you wish to scan your new Subscription list into Kodi\'s Library?'):
        xbmc.executebuiltin('UpdateLibrary(video)')

    # Reopen settings
    return open_settings(open_setting)

def subscriptions_update_list():
    def _get_trakt_list_contents(db_type, item):
        append_list = trakt_movie_list_contents if db_type in ('movie', 'movies') else trakt_tvshow_list_contents
        if item['name'].lower() == 'none': return append_list
        if item['name'] in ('Collection', 'Watchlist'):
            from resources.lib.modules.trakt_cache import clear_trakt_collection_watchlist_data
            from resources.lib.apis.trakt_api import trakt_fetch_collection_watchlist
            clear_trakt_collection_watchlist_data(item['name'].lower(), db_type)
            list_contents = trakt_fetch_collection_watchlist(item['name'].lower(), db_type)
        else:
            from resources.lib.apis.trakt_api import get_trakt_list_contents
            from resources.lib.modules.trakt_cache import clear_trakt_list_contents_data
            trakt_dbtype = 'movie' if db_type in ('movie', 'movies') else 'show'
            clear_trakt_list_contents_data(user=item['user'], slug=item['slug'])
            list_contents = get_trakt_list_contents(item['user'], item['slug'])
            list_contents = [{'media_ids': i[trakt_dbtype]['ids'], 'title': i[trakt_dbtype]['title']} for i in list_contents if i['type'] == trakt_dbtype]
        append_list.extend(list_contents)
    close_all_dialog()
    dialog = xbmcgui.DialogProgressBG()
    dialog.create('Please Wait', 'Preparing for Subscription Update...')
    trakt_dbtype = ('movie', 'show')
    main_setting = ('trakt.subscriptions_movie', 'trakt.subscriptions_show')
    display_setting = ('trakt.subscriptions_movie_display', 'trakt.subscriptions_show_display')
    trakt_movie_list_contents = []
    trakt_tvshow_list_contents = []
    update_movies = False
    update_tvshows = False
    movies_added = False
    tvshows_added = False
    movies_removed = False
    tvshows_removed = False

    # Get Current Subscriptions
    movie_subscriptions = Subscriptions('movie').get_subscriptions()
    tvshow_subscriptions = Subscriptions('tvshow').get_subscriptions()

    # Get the Subscribed Trakt lists
    try: movie_list = json.loads(__addon__.getSetting(main_setting[0]))
    except: movie_list = []
    try: tvshow_list = json.loads(__addon__.getSetting(main_setting[1]))
    except: tvshow_list = []
    movie_list_name = __addon__.getSetting(display_setting[0])
    tvshow_list_name = __addon__.getSetting(display_setting[1])

    # Refresh and Get the contents of the Trakt lists
    for i in [('movies', movie_list), ('shows', tvshow_list)]: _get_trakt_list_contents(i[0], i[1])

    # Make compare lists with TMDb ID and check if they are equal
    trakt_movie_compare_contents = sorted([str(get_trakt_movie_id(i['media_ids'])) for i in trakt_movie_list_contents])
    subscriptions_movie_compare_contents = sorted([str(i['media_id']) for i in movie_subscriptions])
    trakt_tvshow_compare_contents = sorted([str(get_trakt_tvshow_id(i['media_ids'])) for i in trakt_tvshow_list_contents])
    subscriptions_tvshow_compare_contents = sorted([str(i['media_id']) for i in tvshow_subscriptions])
    if not trakt_movie_compare_contents == subscriptions_movie_compare_contents:
        if len(trakt_movie_compare_contents) > 0: update_movies = True
    if not trakt_tvshow_compare_contents == subscriptions_tvshow_compare_contents:
        if len(trakt_tvshow_compare_contents) > 0: update_tvshows = True

    # Check if Movies or TV Shows lists need updating
    if any([update_movies, update_tvshows]):
        from resources.lib.modules.utils import chunks
        from resources.lib.modules.workers import Thread
        def _process_additions(db_type, ids, count, chunk_list_length, path, sleep, dialog):
            ''' Process each item in the chunk with a small (growing) pause between each item '''
            xbmc.sleep(sleep)
            Subscriptions().add_trakt_subscription_listitem(db_type, ids, count, chunk_list_length, path, dialog)
        def _process_removals(db_type, media_id, count, chunk_list_length, path, sleep, dialog):
            ''' Process each item in the chunk with a small (growing) pause between each item '''
            xbmc.sleep(sleep)
            Subscriptions().remove_trakt_subscription_listitem(db_type, media_id, count, chunk_list_length, path, dialog)
        def _process_additions_removals(db_type, action, list_contents):
            function = _process_additions if action == 'add' else _process_removals
            media_id_key = 'media_ids' if action == 'add' else 'media_id'
            chunk_amount = 10 if db_type in ('movie', 'movies') else 5
            dialog_db = '[B]Movies[/B]' if db_type in ('movie', 'movies') else '[B]TV Shows[/B]'
            dialog_line2 = 'Adding [B]%s[/B] %s' if action == 'add' else 'Removing [B]%s[/B] %s'
            path = settings.movies_directory() if db_type in ('movie', 'movies') else settings.tv_show_directory()
            list_length = len(list_contents)
            chunk_list = list(chunks(list_contents, chunk_amount))
            chunk_list_length = len(chunk_list)
            dialog.update(0, dialog_db, dialog_line2 % (list_length, dialog_db))
            for count, chunk in enumerate(chunk_list, 1):
                if xbmc.abortRequested == True: return sys.exit()
                try:
                    if dialog.iscanceled():
                        break
                except Exception:
                    pass
                threads = []
                sleep = 0
                for item in chunk:
                    threads.append(Thread(function, db_type, item[media_id_key], count, chunk_list_length, path, sleep, dialog))
                    sleep += 200
                [i.start() for i in threads]
                [i.join() for i in threads]

        # Process Movies if needed
        if update_movies:
            add_to_subscriptions = [i for i in trakt_movie_compare_contents if not i in subscriptions_movie_compare_contents]
            remove_from_subscriptions = [i for i in subscriptions_movie_compare_contents if not i in trakt_movie_compare_contents]
            if len(add_to_subscriptions) > 0:
                movies_added = True
                list_contents = [i for i in trakt_movie_list_contents if str(i['media_ids']['tmdb']) in add_to_subscriptions]
                _process_additions_removals('movies', 'add', list_contents)
            xbmc.sleep(1500)
            if len(remove_from_subscriptions) > 0:
                movies_removed = True
                list_contents = [i for i in movie_subscriptions if str(i['media_id']) in remove_from_subscriptions]
                _process_additions_removals('movies', 'remove', list_contents)

        # Process TV Shows if needed
        if update_tvshows:
            add_to_subscriptions = [i for i in trakt_tvshow_compare_contents if not i in subscriptions_tvshow_compare_contents]
            remove_from_subscriptions = [i for i in subscriptions_tvshow_compare_contents if not i in trakt_tvshow_compare_contents]
            if len(add_to_subscriptions) > 0:
                tvshows_added = True
                list_contents = [i for i in trakt_tvshow_list_contents if str(i['media_ids']['tmdb']) in add_to_subscriptions]
                _process_additions_removals('tvshows', 'add', list_contents)
            xbmc.sleep(1500)
            if len(remove_from_subscriptions) > 0:
                tvshows_removed = True
                list_contents = [i for i in tvshow_subscriptions if str(i['media_id']) in remove_from_subscriptions]
                _process_additions_removals('tvshows', 'remove', list_contents)

    # Nearly done...
    dialog.update(100, 'Please Wait..', 'Finished Syncing Subscriptions')

    # Update the TV Show Episodes
    xbmc.sleep(1500)
    dialog.close()
    Subscriptions().update_subscriptions(suppress_extras=True)

    # Finished. Update/Clean Library as needed
    if settings.clean_library_after_service():
        if any([movies_removed, tvshows_removed]):
            import time
            xbmc.executebuiltin('CleanLibrary(video)')
            time.sleep(3)
            # Pause script whilst Library is cleaning
            while xbmc.getCondVisibility("Window.IsVisible(ProgressDialog)"):
                time.sleep(1)
        else:
            notification('Nothing Removed. Skipping Clean', 4500)
    if settings.update_library_after_service():
        return xbmc.executebuiltin('UpdateLibrary(video)')
    return
