
import requests
import gzip
try: from StringIO import StringIO ## for Python 2
except ImportError: from io import StringIO ## for Python 3
try: from urllib import quote
except ImportError: from urllib.parse import quote
import json
from modules.utils import to_utf8
from modules.utils import logger


class OpenSubtitlesAPI:
    def __init__(self):
        self.base_url = 'https://rest.opensubtitles.org/search'
        self.user_agent = 'Fen v1.0'
        self.sublanguage_id = ''

    def search(self, query, imdb_id, language, season=None, episode=None):
        url = '/imdbid-%s/query-%s' % (imdb_id, quote(query))
        if season: url += '/season-%d/episode-%d' % (season, episode)
        url += '/sublanguageid-%s' % language
        return self._get(url)

    def download(self, url):
        headers = {'User-Agent': self.user_agent}
        response = requests.get(url, headers=headers, stream=True)
        logger('FEN Opensubtitles Download', response)
        content = gzip.GzipFile(fileobj=StringIO(response.content)).read()
        return content

    def _get(self, url):
        headers = {'User-Agent': self.user_agent}
        url = self.base_url + url
        response = requests.get(url, headers=headers)
        logger('FEN Opensubtitles Search', response)
        response = response.text
        return to_utf8(json.loads(response))