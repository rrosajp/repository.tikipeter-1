# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcvfs, xbmcgui
import os
import re
try:
    from HTMLParser import HTMLParser # Python 2
except ImportError:
    from html.parser import HTMLParser # Python 3
try:
    from sqlite3 import dbapi2 as database
except Exception:
    from pysqlite2 import dbapi2 as database
# from modules.utils import logger

__addon__ = xbmcaddon.Addon(id='plugin.video.fen')
__external__ = xbmcaddon.Addon(id='script.module.openscrapers')

def normalize(title):
    try:
        try: return title.decode('ascii').encode("utf-8")
        except: pass

        return str(''.join(c for c in unicodedata.normalize('NFKD', unicode(title.decode('utf-8'))) if unicodedata.category(c) != 'Mn'))
    except:
        return title

def deleteProviderCache(silent=False):
    try:
        providerDB = os.path.join(xbmc.translatePath(__addon__.getAddonInfo('profile')), "ext_providers.db")
        if not xbmcvfs.exists(providerDB): return 'failure'
        if not silent:
            if not xbmcgui.Dialog().yesno('Are you sure?','Fen will Clear all External Provider Results.'): return 'cancelled'
        dbcon = database.connect(providerDB)
        dbcur = dbcon.cursor()
        for i in ('rel_url', 'rel_src'): dbcur.execute("DELETE FROM %s" % i)
        dbcon.commit()
        dbcur.execute("VACUUM")
        dbcon.close()
        return 'success'
    except: return 'failure'

def checkDatabase():
    dataPath = xbmc.translatePath(__addon__.getAddonInfo('profile'))
    providerDatabase = os.path.join(dataPath, "ext_providers.db")
    if not xbmcvfs.exists(dataPath): xbmcvfs.mkdirs(dataPath)
    if xbmcvfs.exists(providerDatabase): return
    try: from sqlite3 import dbapi2 as database
    except: from pysqlite2 import dbapi2 as database
    dbcon = database.connect(providerDatabase)
    dbcon.execute("""CREATE TABLE IF NOT EXISTS rel_url
                      (source text, imdb_id text, season text, episode text,
                      rel_url text, unique (source, imdb_id, season, episode)) 
                   """)
    dbcon.execute("""CREATE TABLE IF NOT EXISTS rel_src
                      (source text, imdb_id text, season text, episode text,
                      hosts text, added text, unique (source, imdb_id, season, episode)) 
                   """)
    dbcon.close()

def debrid_resolvers_check():
    try:
        import resolveurl

        debrid_resolvers = [resolver() for resolver in resolveurl.relevant_resolvers(order_matters=True) if
                            resolver.isUniversal()]
        if len(debrid_resolvers) == 0:
            # Support Rapidgator accounts! Unfortunately, `sources.py` assumes that rapidgator.net is only ever
            # accessed via a debrid service, so we add rapidgator as a debrid resolver and everything just works.
            # As a bonus(?), rapidgator links will be highlighted just like actual debrid links
            debrid_resolvers = [resolver() for resolver in
                                resolveurl.relevant_resolvers(order_matters=True, include_universal=False) if
                                'rapidgator.net' in resolver.domains]
    except:
        debrid_resolvers = []
    return debrid_resolvers


def debrid_status(torrent=False):
    try:
        import xbmc
        debrid_check = debrid_resolvers_check() != []
        if debrid_check is True:
            if torrent:
                enabled = __external__.getSetting('torrent.enabled')
                if enabled == '' or enabled.lower() == 'true':
                    return True
                else:
                    return False
        return debrid_check
    except:
        return True

def resolver(url, debrid):
    try:
        debrid_resolver = [resolver for resolver in debrid_resolvers_check() if resolver.name == debrid][0]

        debrid_resolver.login()
        _host, _media_id = debrid_resolver.get_host_and_id(url)
        stream_url = debrid_resolver.get_media_url(_host, _media_id)

        return stream_url
    except Exception:
        return None

def replaceHTMLCodes(txt):
    txt = re.sub("(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", txt)
    txt = HTMLParser().unescape(txt)
    txt = txt.replace("&quot;", "\"")
    txt = txt.replace("&amp;", "&")
    txt = txt.strip()
    return txt

def getFileType(url):
    try:
        url = replaceHTMLCodes(url)
        url = re.sub('[^A-Za-z0-9]+', ' ', url)
        url = url.encode('utf-8')
        url = str(url.lower())
    except:
        url = str(url)
    info = ''
    if any(i in url for i in [' h 265 ', ' h265 ', ' x265 ', ' hevc ']):
        info += '[B]HEVC[/B] |'
    if ' hi10p ' in url:
        info += ' HI10P |'
    if ' 10bit ' in url:
        info += ' 10BIT |'
    if any(i in url for i in [' bluray ', ' blu ray ']):
        info += ' BLURAY |'
    if any(i in url for i in [' bd r ', ' bdr ', ' bd rip ', ' bdrip ', ' br rip ', ' brrip ']):
        info += ' BD-RIP |'
    if ' remux ' in url:
        info += ' REMUX |'
    if any(i in url for i in [' dvdrip ', ' dvd rip ']):
        info += ' DVD-RIP |'
    if any(i in url for i in [' dvd ', ' dvdr ', ' dvd r ']):
        info += ' DVD |'
    if any(i in url for i in [' webdl ', ' web dl ', ' web ', ' web rip ', ' webrip ']):
        info += ' WEB |'
    if ' hdtv ' in url:
        info += ' HDTV |'
    if ' sdtv ' in url:
        info += ' SDTV |'
    if any(i in url for i in [' hdrip ', ' hd rip ']):
        info += ' HDRIP |'
    if any(i in url for i in [' uhdrip ', ' uhd rip ']):
        info += ' UHDRIP |'
    if ' xvid ' in url:
        info += ' XVID |'
    if ' avi ' in url:
        info += ' AVI |'
    if ' hdr ' in url:
        info += ' HDR |'
    if ' imax ' in url:
        info += ' IMAX |'
    if ' ac3 ' in url:
        info += ' AC3 |'
    if ' eac3 ' in url:
        info += ' EAC3 |'
    if ' aac ' in url:
        info += ' AAC |'
    if any(i in url for i in [' dd ', ' dolby ', ' dolbydigital ', ' dolby digital ']):
        info += ' DD |'
    if any(i in url for i in [' truehd ', ' true hd ']):
        info += ' TRUEHD |'
    if ' atmos ' in url:
        info += ' ATMOS |'
    if any(i in url for i in [' ddplus ', ' dd plus ', ' ddp ']):
        info += ' DD+ |'
    if ' dts ' in url:
        info += ' DTS |'
    if any(i in url for i in [' hdma ', ' hd ma ']):
        info += ' HD.MA |'
    if any(i in url for i in [' hdhra ', ' hd hra ']):
        info += ' HD.HRA |'
    if any(i in url for i in [' dtsx ', ' dts x ']):
        info += ' DTS:X |'
    if ' dd5 1 ' in url:
        info += ' DD | 5.1 |'
    if any(i in url for i in [' 5 1 ', ' 6ch ']):
        info += ' 5.1 |'
    if any(i in url for i in [' 7 1 ', ' 8ch ']):
        info += ' 7.1 |'
    if any (i in url for i in [' subs ', ' subbed ', ' sub ']):
        info += ' SUBS |'
    if any (i in url for i in [' dub ', ' dubbed ', ' dublado ']):
        info += ' DUB |'
    info = info.rstrip('|')
    return info
