
import xbmcvfs, xbmcgui
import re
import json
import os
import urlparse
from resources.lib.apis.premiumize_api import PremiumizeAPI
from resources.lib.modules.workers import Thread
from resources.lib.modules.utils import clean_title, clean_file_name, replace_html_codes, supported_video_extensions
from resources.lib.modules import settings
# from resources.lib.modules.utils import logger

window = xbmcgui.Window(10000)

Premiumize = PremiumizeAPI()

class PremiumizeSource:
    def __init__(self):
        self.scrape_provider = 'pm-cloud'
        self.sources = []
        self.threads  = []
        self.scrape_results = []
        self.provider_color = settings.provider_color(self.scrape_provider)
        self.show_filenames = settings.show_filenames()

    def results(self, info):
        self.info = info
        self.db_type = self.info.get("db_type")
        self.title = self.info.get("title")
        self.year = self.info.get("year")
        self.season = self.info.get("season")
        self.episode = self.info.get("episode")
        self.title_query = clean_title(self.title)
        self.folder_query = self._season_query_list() if self.db_type == 'episode' else self._year_query_list()
        self.file_query = self._episode_query_list() if self.db_type == 'episode' else self._year_query_list()
        self.extensions = supported_video_extensions()
        self._scrape_cloud()
        if not self.scrape_results: return self.sources
        for item in self.scrape_results:
            self.folder_name = item['folder_name']
            self.file_name = clean_file_name(item['name'])
            self.file_dl = item['link']
            self.size = item['size']
            self.details = self._get_release_details(self.file_name, self.folder_name)
            self.video_quality = self._get_release_quality(self.file_name, self.folder_name)
            self.label = self._build_label()
            self.multiline_label = self._build_multiline_label()
            self.sources.append({'name': self.file_name,
                                'label': self.label,
                                'multiline_label': self.multiline_label,
                                'title': self.file_name,
                                'quality': self.video_quality,
                                'size': self.size,
                                'url_dl': self.file_dl,
                                'id': self.file_dl,
                                'downloads': False,
                                'direct': True,
                                'source': self.scrape_provider,
                                'scrape_provider': self.scrape_provider})

        window.setProperty('pm-cloud_source_results', json.dumps(self.sources))
        
        return self.sources

    def _scrape_cloud(self, folder_id=None, folder_name=None):
        folder_results = []
        try:
            cloud_files = Premiumize.user_cloud(folder_id)['content']
            cloud_files = [i for i in cloud_files if ('link' in i and i['link'].lower().endswith(tuple(self.extensions))) or i['type'] == 'folder']
            cloud_files = sorted(cloud_files, key=lambda k: k['name'])
            cloud_files = sorted(cloud_files, key=lambda k: k['type'], reverse=True)
        except: return self.sources
        for item in cloud_files:
            file_type = item['type']
            item_name = clean_title(self._normalize(item['name']))
            if file_type == 'folder':
                if self.title_query in item_name or any(x in item_name for x in self.folder_query):
                    item['folder_name'] = item['name']
                    folder_results.append(item)
            else:
                if self.title_query in item_name:
                    if self.db_type == 'movie':
                        item['folder_name'] = folder_name
                        self.scrape_results.append(item)
                    elif any(x in item_name for x in self.file_query):
                        item['folder_name'] = folder_name
                        self.scrape_results.append(item)
        if not folder_results: return
        return self._pm_worker(folder_results)

    def _pm_worker(self, folder_results):
        threads = []
        for i in folder_results: threads.append(Thread(self._scrape_cloud, i.get('id'), i.get('folder_name', None)))
        [i.start() for i in threads]
        [i.join() for i in threads]

    def _year_query_list(self):
        return [str(self.year), str(int(self.year)+1), str(int(self.year)-1)]

    def _season_query_list(self):
        return ['s%02d' % int(self.season), 's%d' % int(self.season),
                'season%02d' % int(self.season), 'season%d' % int(self.season)]

    def _episode_query_list(self):
        return ['s%02de%02d' % (int(self.season), int(self.episode)),
                '%dx%02d' % (int(self.season), int(self.episode)),
                '%02dx%02d' % (int(self.season), int(self.episode)),
                'season%02depisode%02d' % (int(self.season), int(self.episode)),
                'season%depisode%02d' % (int(self.season), int(self.episode)),
                'season%depisode%d' % (int(self.season), int(self.episode))]

    def _build_label(self):
        quality = '[I]{}[/I] '.format(self.video_quality) if self.video_quality in ('HQ', 'CAM', 'TELE', 'SCR') else '[B][I]{}[/I][/B] '.format(self.video_quality)
        details = self.details
        display = '[B]PM CLOUD[/B]'
        display_name = '[COLOR={0}]{1} | {2} | {3}[/COLOR]'.format(self.provider_color, display.upper(), quality.upper(), details.upper())
        if self.show_filenames: display_name += '[COLOR={0}] | [I]{1}[/I][/COLOR]'.format(self.provider_color, clean_file_name(self.file_name).upper())
        return display_name

    def _build_multiline_label(self):
        quality = '[I]{}[/I] '.format(self.video_quality) if self.video_quality in ('HQ', 'CAM', 'TELE', 'SCR') else '[B][I]{}[/I][/B] '.format(self.video_quality)
        details = self.details
        display = '[B]PM CLOUD[/B]'
        display_name = '[COLOR={0}]{1} | {2} | {3}[/COLOR]'.format(self.provider_color, display.upper(), quality.upper(), details.upper())
        if self.show_filenames: display_name += ' \n       [COLOR={0}][I]{1}[/I][/COLOR]'.format(self.provider_color, clean_file_name(self.file_name).upper())
        return display_name

    def _get_release_quality(self, file_name, folder_name):
        def _find_quality(name):
            vid_quality = None
            try:
                name = name.upper()
                fmt = re.sub('(.+)(\.|\(|\[|\s)(\d{4}|S\d*E\d*|S\d*)(\.|\)|\]|\s)', '', name)
                fmt = re.split('\.|\(|\)|\[|\]|\s|-', fmt)
                fmt = [i.lower() for i in fmt]
                if any(i in ['dvdscr', 'r5', 'r6'] for i in fmt): vid_quality = 'SCR'
                elif any(i in ['camrip', 'tsrip', 'hdcam', 'hd-cam', 'hdts', 'dvdcam', 'dvdts', 'cam', 'telesync', 'ts'] for i in fmt): vid_quality = 'CAM'
                elif any(i in ['tc', 'hdtc', 'telecine', 'tc720p', 'tc720', 'hdtc'] for i in fmt): vid_quality = 'TELE'
                elif '2160p' in fmt: vid_quality = '4K'
                elif '1080p' in fmt: vid_quality = '1080p'
                elif '720p' in fmt: vid_quality = '720p'
                elif 'brrip' in fmt: vid_quality = '720p'
            except: pass
            return vid_quality
        vid_quality = _find_quality(file_name)
        if not vid_quality: vid_quality = _find_quality(folder_name)
        if not vid_quality: vid_quality = 'SD'
        return vid_quality

    def _get_release_details(self, file_name, folder_name):
        def _fmt(name):
            name = replace_html_codes(name)
            fmt = re.sub('(.+)(\.|\(|\[|\s)(\d{4}|S\d*E\d*)(\.|\)|\]|\s)', '', name)
            fmt = re.split('\.|\(|\)|\[|\]|\s|\-', fmt)
            fmt = [x.lower() for x in fmt]
            return fmt
        def _detailed(name):
            info = None
            fmt = _fmt(name)
            size = float(self.size)/1073741824
            if '3d' in fmt: q = ' | 3D'
            else: q = ''
            try:
                v = a = ''
                if any(i in ['hevc', 'h265', 'x265'] for i in fmt): v = ' | [B]HEVC[/B]'
                if '10bit' in fmt: v += ' | 10BIT'
                if 'imax' in fmt: v += ' | IMAX'
                if 'bluray' in fmt: v += ' | BLURAY'
                if 'web-dl' in fmt: v += ' | WEB-DL'
                if 'web' in fmt: v += ' | WEB-DL'
                if 'hdrip' in fmt: v += ' | HDRip'
                if 'bd-r' in fmt: v += ' | BD-R'
                if 'bd-rip' in fmt: v += ' | BD-RIP'
                if 'bd.r' in fmt: v += ' | BD-R'
                if 'bdr' in fmt: v += ' | BD-R'
                if 'bdrip' in fmt: v += ' | BD-RIP'
                if 'brrip' in fmt: v += ' | BR-RIP'
                if 'xvid' in fmt: v += ' | XVID'
                if 'mp4' in fmt: v += ' | MP4'
                if 'mkv' in fmt: v += ' | MKV'
                if 'avi' in fmt: v += ' | AVI'
                if 'dts' in fmt: a += ' | DTS'
                if 'atmos' in fmt: a += ' | ATMOS'
                if 'truehd' in fmt: a += ' | TRUEHD'
                if 'mp3' in fmt: a += ' | MP3'
                if 'aac' in fmt: a += ' | AAC'
                info = '%.2f GB%s%s%s' % (size, q, v, a)
            except: pass
            return info
        def _simple(name):
            info = None
            fmt = _fmt(name)
            size = float(self.size)/1073741824
            if '3d' in fmt: q = ' | 3D'
            else: q = ''
            try:
                if any(i in ['hevc', 'h265', 'x265'] for i in fmt): v = '[B]HEVC[/B]'
                else: v = 'h264'
                info = '%.2f GB%s | %s' % (size, q, v)
            except: pass
            return info
        def _basic(name):
            info = None
            fmt = _fmt(name)
            size = float(self.size)/1073741824
            if '3d' in fmt: q = ' | 3D'
            else: q = ''
            try:
                info = '%.2f GB%s | [I]%s[/I]' % (size, q, name.replace('.', ' '))
            except: pass
            return info
        info = _detailed(folder_name)
        if not info: info = _detailed(file_name)
        if not info: info = _simple(folder_name)
        if not info: info = _simple(file_name)
        if not info: info = _basic(folder_name)
        if not info: info = _basic(file_name)
        return info

    def _normalize(self, txt):
        txt = re.sub(r'[^\x00-\x7f]',r'', txt)
        return txt


