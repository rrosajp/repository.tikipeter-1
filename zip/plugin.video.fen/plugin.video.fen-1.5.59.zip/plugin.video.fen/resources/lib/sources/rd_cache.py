
import xbmcaddon, xbmcvfs, xbmcgui
import re
import json
import os
import urlparse
from resources.lib.apis.real_debrid_api import RealDebridAPI
from resources.lib.modules.workers import Thread
from resources.lib.modules.utils import get_release_quality, get_file_info, clean_title, clean_file_name, replace_html_codes, supported_video_extensions
from resources.lib.modules import settings
# from resources.lib.modules.utils import logger

__addon__ = xbmcaddon.Addon(id='plugin.video.fen')
window = xbmcgui.Window(10000)

RealDebrid = RealDebridAPI()

class RealDebridSource:
    def __init__(self):
        self.scrape_provider = 'rd-cloud'
        self.sources = []
        self.threads  = []
        self.folder_results = []
        self.scrape_results = []
        self.provider_color = settings.provider_color(self.scrape_provider)
        self.second_line_color = __addon__.getSetting('secondline.identify')
        if self.second_line_color == 'No Color': self.second_line_color = self.provider_color
        self.show_extra_info = settings.show_extra_info()
        self.show_filenames = settings.show_filenames()

    def results(self, info):
        self.info = info
        self.db_type = self.info.get("db_type")
        self.title = self.info.get("title")
        self.year = self.info.get("year")
        self.season = self.info.get("season", None)
        self.episode = self.info.get("episode", None)
        self.extensions = supported_video_extensions()
        self.folder_query = clean_title(self.title)
        self.query_list = self._year_query_list() if self.db_type == 'movie' else self._episode_query_list()
        self._scrape_cloud()
        if not self.scrape_results: return self.sources
        self._label_settings()
        for item in self.scrape_results:
            try:
                self.folder_name = item['folder_name']
                self.file_name = self._get_filename(item['path'])
                self.file_dl = item['url_link']
                self.size = float(item['bytes'])/1073741824
                self.video_quality = get_release_quality(self.file_name, self.folder_name)
                self.details = get_file_info(self.file_name)
                if not self.details: self.details = get_file_info(self.folder_name)
                labels = self._build_label()
                label = labels[0]
                multiline_label = labels[1]
                self.sources.append({'name': self.file_name,
                                    'label': label,
                                    'multiline_label': multiline_label,
                                    'title': self.file_name,
                                    'quality': self.video_quality,
                                    'size': self.size,
                                    'url_dl': self.file_dl,
                                    'id': self.file_dl,
                                    'downloads': False,
                                    'direct': True,
                                    'source': self.scrape_provider,
                                    'scrape_provider': self.scrape_provider})
            except: pass

        window.setProperty('rd-cloud_source_results', json.dumps(self.sources))
        
        return self.sources

    def _scrape_cloud(self):
        try: my_cloud_files = RealDebrid.user_cloud()
        except: return self.sources
        for item in my_cloud_files:
            folder_name = clean_title(self._normalize(item['filename']))
            if self.folder_query in folder_name:
                self.folder_results.append((self._normalize(item['filename']), item['id']))
        if not self.folder_results: return self.sources
        for i in self.folder_results: self.threads.append(Thread(self._scrape_folders, i))
        [i.start() for i in self.threads]
        [i.join() for i in self.threads]

    def _scrape_folders(self, folder_info):
        folder_files = RealDebrid.user_cloud_info(folder_info[1])
        file_info = [i for i in folder_files['files'] if i['path'].lower().endswith(tuple(self.extensions))]
        file_urls = folder_files['links']
        contents = [dict(i.items() + [('folder_name', folder_info[0]), ('url_link', file_urls[c])]) for c, i in enumerate(file_info)]
        contents = sorted(contents, key=lambda k: k['path'])
        for item in contents:
            filename = clean_title(self._normalize(item['path']))
            if self.folder_query in filename and any(x in filename for x in self.query_list):
                self.scrape_results.append(item)

    def _year_query_list(self):
        return [str(self.year), str(int(self.year)+1), str(int(self.year)-1)]

    def _episode_query_list(self):
        return ['s%02de%02d' % (int(self.season), int(self.episode)),
                '%dx%02d' % (int(self.season), int(self.episode)),
                '%02dx%02d' % (int(self.season), int(self.episode)),
                'season%02depisode%02d' % (int(self.season), int(self.episode)),
                'season%depisode%02d' % (int(self.season), int(self.episode)),
                'season%depisode%d' % (int(self.season), int(self.episode))]

    def _get_filename(self, path):
        name = path
        if name.startswith('/'): name = name.split('/')[-1]
        return clean_file_name(name)

    def _label_settings(self):
        if self.provider_color == '':
            self.leading = self.closing = ''
            if self.second_line_color == '': self.multi_closing = ''
            else: self.multi_closing = '[/COLOR]'
        else:
            self.leading = '[COLOR %s]' % self.provider_color
            if self.second_line_color == '':
                self.closing = ''
            else:
                self.closing = '[/COLOR]'
            self.multi_closing = '[/COLOR]'

        if self.second_line_color == '':
            self.multi_leading = self.multiLineClosing = ''
        else:
            self.multi_leading = '[COLOR %s]' % self.second_line_color
            self.multiLineClosing = '[/COLOR]'

    def _build_label(self, uncached=False, active_download=False):
        if self.show_filenames: filename = self.file_name.replace('.', ' ')
        else: filename = ''
        if self.show_extra_info: details = self.details
        else: details = ''
        label = '[B]RD CLOUD[/B] | [I][B]%s[/B][/I] | %.2f GB' % (self.video_quality, self.size)
        multiline_label1 = '[B]RD CLOUD[/B] | [I][B]%s[/B][/I] | %.2f GB' % (self.video_quality, self.size)
        if self.show_extra_info: label += ' | %s' % details
        multiline_label2 = ''
        if self.show_filenames:
            label += ' | %s' % filename
            multiline_label1 += ' | %s' % details
            multiline_label2 += '\n        %s' % filename
        else:
            multiline_label2 += '\n        %s' % details
        label = label.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
        label = re.sub('\[I\]\s+\[/I\]', ' ', label)
        label = re.sub('\|\s+\|', '|', label)
        label = re.sub('\|(?:\s+|)$', '', label)
        label = label.upper()
        multiline_label1 = multiline_label1.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
        multiline_label1 = re.sub('\[I\]\s+\[/I\]', ' ', multiline_label1)
        multiline_label1 = re.sub('\|\s+\|', '|', multiline_label1)
        multiline_label1 = re.sub('\|(?:\s+|)$', '', multiline_label1)
        multiline_label1 = multiline_label1.upper()
        if multiline_label2 != '':
            multiline_label2 = multiline_label2.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
            multiline_label2 = re.sub('\[I\]\s+\[/I\]', ' ', multiline_label2)
            multiline_label2 = re.sub('\|\s+\|', '|', multiline_label2)
            multiline_label2 = re.sub('\|(?:\s+|)$', '', multiline_label2)
            multiline_label2 = multiline_label2.upper()
        label = self.leading + label + self.closing
        multiline_label = self.leading + multiline_label1 + self.closing + self.multi_leading + multiline_label2 + self.multi_closing
        return label, multiline_label

    def _normalize(self, txt):
        txt = re.sub(r'[^\x00-\x7f]',r'', txt)
        return txt


