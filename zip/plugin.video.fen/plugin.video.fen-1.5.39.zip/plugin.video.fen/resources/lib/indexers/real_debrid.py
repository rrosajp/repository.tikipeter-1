# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcplugin, xbmcgui
import sys, os
import urllib
from urlparse import parse_qsl
from resources.lib.modules.real_debrid_api import RealDebridAPI
from resources.lib.modules.settings import get_theme
from resources.lib.modules.nav_utils import build_url, setView
from resources.lib.modules.utils import clean_file_name, supported_video_extensions
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.fen'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__handle__ = int(sys.argv[1])
addon_dir = xbmc.translatePath(__addon__.getAddonInfo('path'))
icon_directory = get_theme()
default_rd_icon = os.path.join(icon_directory, 'realdebrid.png')
fanart = os.path.join(addon_dir, 'fanart.png')

RealDebrid = RealDebridAPI()

def rd_torrent_cloud():
    try: my_cloud_files = RealDebrid.user_cloud()
    except: return
    for count, item in enumerate(my_cloud_files, 1):
        try:
            cm = []
            name = clean_file_name(item['filename']).upper()
            display = '%02d | [B]FOLDER[/B] | [I]%s [/I]' % (count, name)
            url_params = {'mode': 'real_debrid.browse_rd_cloud', 'id': item['id']}
            url = build_url(url_params)
            listitem = xbmcgui.ListItem(display)
            listitem.addContextMenuItems(cm)
            listitem.setArt({'thumb': default_rd_icon, 'fanart': fanart})
            listitem.setInfo(type='video', infoLabels={'title': display})
            xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=True)
        except: pass
    xbmcplugin.setContent(__handle__, 'files')
    xbmcplugin.endOfDirectory(__handle__)

def browse_rd_cloud(folder_id):
    try:
        extensions = supported_video_extensions()
        torrent_files = RealDebrid.user_cloud_info(folder_id)
    except: return
    try:
        file_info = [i for i in torrent_files['files'] if i['path'].lower().endswith(tuple(extensions))]
        file_urls = torrent_files['links']
        display_info = [dict(i.items() + [('url_link', file_urls[c])]) for c, i in enumerate(file_info)]
        display_info = sorted(display_info, key=lambda k: k['path'])
    except: return xbmcgui.Dialog().ok('Fen - Real Debrid', 'Cannot display Malformed Pack.')
    for count, item in enumerate(display_info):
        try:
            cm = []
            name = item['path']
            if name.startswith('/'): name = name.split('/')[-1]
            name = clean_file_name(name).upper()
            url_link = item['url_link']
            if url_link.startswith('/'): url_link = 'http' + url_link
            size = float(int(item['bytes']))/1073741824
            display = '%02d | [B]FILE[/B] | %.2f GB | [I]%s [/I]' % (count+1, size, name)
            url_params = {'mode': 'real_debrid.resolve_rd', 'url': url_link}
            url = build_url(url_params)
            down_file_params = {'mode': 'download_file', 'name': name, 'url': url_link,
                                'db_type': 'realdebrid_file', 'image': default_rd_icon}
            cm.append(("[B]Download File[/B]",'XBMC.RunPlugin(%s)' % build_url(down_file_params)))
            listitem = xbmcgui.ListItem(display)
            listitem.addContextMenuItems(cm)
            listitem.setArt({'thumb': default_rd_icon, 'fanart': fanart})
            listitem.setInfo(type='video', infoLabels={'title': display, 'size': int(item['bytes'])})
            xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=False)
        except: pass
    xbmcplugin.setContent(__handle__, 'files')
    xbmcplugin.endOfDirectory(__handle__)

def rd_account_info():
    from datetime import datetime
    import time
    dialog = xbmcgui.Dialog()
    try:
        account_info = RealDebrid.account_info()
        resformat = "%Y-%m-%dT%H:%M:%S.%fZ"
        try: expires = datetime.strptime(account_info['expiration'], resformat)
        except TypeError: expires = datetime(*(time.strptime(account_info['expiration'], resformat)[0:6]))
        days_remaining = (expires - datetime.today()).days
        heading = 'Real Debrid : %s' % account_info['email']
        body = []
        body.append('[B]Username:[/B] %s' % account_info['username'])
        body.append('[B]Status:[/B] %s' % account_info['type'].capitalize())
        body.append('[B]Expires:[/B] %s' % expires)
        body.append('[B]Days Remaining:[/B] %s' % days_remaining)
        body.append('[B]Fidelity Points:[/B] %s' % account_info['points'])
        return dialog.select(heading, body)
    except: return dialog.ok('Fen', 'Error Getting Real Debrid Info.')

def resolve_rd(url, play=True):
    resolved_link = RealDebrid.unrestrict_link(url)
    if not play: return resolved_link
    url_params = {'mode': 'media_play', 'url': resolved_link, 'rootname': 'nill'}
    return xbmc.executebuiltin('XBMC.RunPlugin(%s)' % build_url(url_params))
