import xbmc

extensions = [i for i in xbmc.getSupportedMedia('video').split('|') if not i in ('','.zip')]