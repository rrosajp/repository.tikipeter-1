import xbmc, xbmcaddon, xbmcgui, xbmcplugin
import os, sys
import urllib
import json
from resources.lib.modules.nav_utils import build_url, setView
from resources.lib.modules.utils import to_utf8
import settings
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.fen'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
addon_dir = xbmc.translatePath(__addon__.getAddonInfo('path'))
__addon_profile__ = xbmc.translatePath(__addon__.getAddonInfo('profile'))
__url__ = sys.argv[0]
__handle__ = int(sys.argv[1])

tmdb_api = settings.tmdb_api_check()
icon_directory = settings.get_theme()
dialog = xbmcgui.Dialog()
window = xbmcgui.Window(10000)
window_id = 'FEN_discover_params'

class Discover:
    def __init__(self):
        self.view = 'view.main'
        self.icon = os.path.join(icon_directory, 'discover.png')
        self.fanart = os.path.join(addon_dir, 'fanart.png')
        try: self.discover_params = json.loads(window.getProperty(window_id))
        except: self.discover_params = {}

    def movie(self):
        if not 'db_type' in self.discover_params or self.discover_params['db_type'] == 'tvshow':
            self._clear_property()
            self.discover_params['db_type'] = 'movie'
            self.discover_params['search_string'] = {}
            self.discover_params['search_string']['base'] = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&page=%s' % (tmdb_api, '%s')
            self.discover_params['search_name'] = {'db_type': 'Movies'}
            self._set_property()
        names = self.discover_params['search_name']
        self._add_dir({'mode': 'discover._clear_property', 'info': '', 'list_name': '[B]CLEAR ALL FILTERS[/B]'})
        self._add_dir({'mode': 'discover.year_start', 'info': '', 'list_name': 'Year Start:  [I]%s[/I]' % names.get('year_start', '')})
        self._add_dir({'mode': 'discover.year_end', 'info': '', 'list_name': 'Year End:  [I]%s[/I]' % names.get('year_end', '')})
        self._add_dir({'mode': 'discover.include_genres', 'info': '', 'list_name': 'Include Genres:  [I]%s[/I]' % names.get('include_genres', '')})
        self._add_dir({'mode': 'discover.exclude_genres', 'info': '', 'list_name': 'Exclude Genres:  [I]%s[/I]' % names.get('exclude_genres', '')})
        self._add_dir({'mode': 'discover.language', 'info': '', 'list_name': 'Language:  [I]%s[/I]' % names.get('language', '')})
        self._add_dir({'mode': 'discover.region', 'info': '', 'list_name': 'Region:  [I]%s[/I]' % names.get('region', '')})
        self._add_dir({'mode': 'discover.certification', 'info': '', 'list_name': 'Certification:  [I]%s[/I]' % names.get('certification', '').upper()})
        self._add_dir({'mode': 'discover.rating', 'info': '', 'list_name': 'Minimum Rating:  [I]%s[/I]' % names.get('rating', '')})
        self._add_dir({'mode': 'discover.rating_votes', 'info': '', 'list_name': 'Minimum Number of Votes:  [I]%s[/I]' % names.get('rating_votes', '')})
        self._add_dir({'mode': 'discover.cast', 'info': '', 'list_name': 'Includes Cast Member:  [I]%s[/I]' % names.get('cast', '')})
        self._add_dir({'mode': 'discover.sort_by', 'info': '', 'list_name': 'Sort By:  [I]%s[/I]' % names.get('sort_by', '')})
        self._add_dir({'mode': 'discover.adult', 'info': '', 'list_name': 'Includes Adult:  [I]%s[/I]' % names.get('adult', 'False')})
        self._add_defaults()
        self._end_directory()

    def tvshow(self):
        if not 'db_type' in self.discover_params or self.discover_params['db_type'] == 'movie':
            self._clear_property()
            self.discover_params['db_type'] = 'tvshow'
            self.discover_params['search_string'] = {}
            self.discover_params['search_string']['base'] = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&page=%s' % (tmdb_api, '%s')
            self.discover_params['search_name'] = {'db_type': 'TV Shows'}
            self._set_property()
        names = self.discover_params['search_name']
        self._add_dir({'mode': 'discover._clear_property', 'info': '', 'list_name': '[B]CLEAR ALL FILTERS[/B]'})
        self._add_dir({'mode': 'discover.year_start', 'info': '', 'list_name': 'Year Start:  %s' % names.get('year_start', '')})
        self._add_dir({'mode': 'discover.year_end', 'info': '', 'list_name': 'Year End:  %s' % names.get('year_end', '')})
        self._add_dir({'mode': 'discover.include_genres', 'info': '', 'list_name': 'Include Genres:  %s' % names.get('include_genres', '')})
        self._add_dir({'mode': 'discover.exclude_genres', 'info': '', 'list_name': 'Exclude Genres:  %s' % names.get('exclude_genres', '')})
        self._add_dir({'mode': 'discover.language', 'info': '', 'list_name': 'Language:  %s' % names.get('language', '')})
        self._add_dir({'mode': 'discover.network', 'info': '', 'list_name': 'Network:  %s' % names.get('network', '')})
        self._add_dir({'mode': 'discover.rating', 'info': '', 'list_name': 'Minimum Rating:  %s' % names.get('rating', '')})
        self._add_dir({'mode': 'discover.rating_votes', 'info': '', 'list_name': 'Minimum Number of Votes:  %s' % names.get('rating_votes', '')})
        self._add_dir({'mode': 'discover.sort_by', 'info': '', 'list_name': 'Sort By:  [I]%s[/I]' % names.get('sort_by', '')})
        self._add_defaults()
        self._end_directory()

    def year_start(self):
        key = 'year_start'
        if self._action(key) == 'clear': return
        from resources.lib.modules.nav_utils import years
        years = years()
        years_list = [str(i) for i in years]
        year_start = self._selection_dialog(years_list, years, 'FEN DISCOVER: Choose Start Year')
        if year_start:
            if self.discover_params['db_type'] == 'movie':
                value = 'primary_release_date.gte'
            else:
                value = 'first_air_date.gte'
            values = ('&%s=%s-01-01' % (value, str(year_start)), str(year_start))
            self._process(key, values)

    def year_end(self):
        key = 'year_end'
        if self._action(key) == 'clear': return
        from resources.lib.modules.nav_utils import years
        years = years()
        years_list = [str(i) for i in years]
        year_end = self._selection_dialog(years_list, years, 'FEN DISCOVER: Choose End Year')
        if year_end:
            if self.discover_params['db_type'] == 'movie':
                value = 'primary_release_date.lte'
            else:
                value = 'first_air_date.lte'
            values = ('&%s=%s-12-31' % (value, str(year_end)), str(year_end))
            self._process(key, values)

    def include_genres(self):
        key = 'include_genres'
        if self._action(key) == 'clear': return
        if self.discover_params['db_type'] == 'movie':
            from resources.lib.modules.nav_utils import movie_genres as genres
        else:
            from resources.lib.modules.nav_utils import tvshow_genres as genres
        genre_list = [(k, v[0]) for k,v in sorted(genres.items())]
        genres_choice = self._multiselect_dialog('FEN DISCOVER: Choose Included Genres', [i[0] for i in genre_list], genre_list)
        if genres_choice:
            genre_ids = ','.join([i[1] for i in genres_choice])
            genre_names = ', '.join([i[0] for i in genres_choice])
            values = ('&with_genres=%s' % genre_ids, genre_names)
            self._process(key, values)

    def exclude_genres(self):
        key = 'exclude_genres'
        if self._action(key) == 'clear': return
        if self.discover_params['db_type'] == 'movie':
            from resources.lib.modules.nav_utils import movie_genres as genres
        else:
            from resources.lib.modules.nav_utils import tvshow_genres as genres
        genre_list = [(k, v[0]) for k,v in sorted(genres.items())]
        genres_choice = self._multiselect_dialog('FEN DISCOVER: Choose Excluded Genres', [i[0] for i in genre_list], genre_list)
        if genres_choice:
            genre_ids = ','.join([i[1] for i in genres_choice])
            genre_names = ', '.join([i[0] for i in genres_choice])
            values = ('&without_genres=%s' % genre_ids, '/'.join(genre_names.split(', ')))
            self._process(key, values)

    def language(self):
        key = 'language'
        if self._action(key) == 'clear': return
        from resources.lib.modules.nav_utils import languages
        languages_list = [i[0] for i in languages]
        language = self._selection_dialog(languages_list, languages, 'FEN DISCOVER: Choose Language')
        if language:
            values = ('&with_original_language=%s' % str(language[1]), str(language[1]).upper())
            self._process(key, values)

    def region(self):
        key = 'region'
        if self._action(key) == 'clear': return
        from resources.lib.modules.nav_utils import regions
        region_names = [i['name'] for i in regions]
        region_codes = [i['code'] for i in regions]
        region = self._selection_dialog(region_names, region_codes, 'FEN DISCOVER: Choose Region')
        if region:
            region_name = [i['name'] for i in regions if i['code'] == region][0]
            values = ('&region=%s' % region, region_name)
            self._process(key, values)

    def rating(self):
        key = 'rating'
        if self._action(key) == 'clear': return
        ratings = [i for i in range(1,11)]
        ratings_list = [str(float(i)) for i in ratings]
        rating = self._selection_dialog(ratings_list, ratings, 'FEN DISCOVER: Choose Minimum Rating')
        if rating:
            values = ('&vote_average.gte=%s' % str(rating), str(float(rating)))
            self._process(key, values)

    def rating_votes(self):
        key = 'rating_votes'
        if self._action(key) == 'clear': return
        rating_votes = [i for i in range(0,1001,50)]
        rating_votes.pop(0)
        rating_votes.insert(0, 1)
        rating_votes_list = [str(i) for i in rating_votes]
        rating_votes = self._selection_dialog(rating_votes_list, rating_votes, 'FEN DISCOVER: Choose Minimum Number of Votes')
        if rating_votes:
            values = ('&vote_count.gte=%s' % str(rating_votes), str(rating_votes))
            self._process(key, values)

    def certification(self):
        key = 'certification'
        if self._action(key) == 'clear': return
        from resources.lib.modules.nav_utils import movie_certifications as certifications
        certifications_list = [i.upper() for i in certifications]
        certification = self._selection_dialog(certifications_list, certifications, 'FEN DISCOVER: Choose Certification')
        if certification:
            values = ('&certification_country=US&certification=%s' % certification, certification.upper())
            self._process(key, values)

    def cast(self):
        key = 'cast'
        if self._action(key) == 'clear': return
        from resources.lib.apis.tmdb_api import get_tmdb
        from resources.lib.modules.fen_cache import cache_object
        result = None
        actor_id = None
        search_name = None
        search_name = dialog.input('FEN DISCOVER: Enter Actor/Actress Name', type=xbmcgui.INPUT_ALPHANUM)
        if not search_name: return
        string = "%s_%s" % ('tmdb_movies_people_search_actor_data', search_name)
        url = 'https://api.themoviedb.org/3/search/person?api_key=%s&language=en-US&query=%s' % (tmdb_api, search_name)
        result = cache_object(get_tmdb, string, url, 4)
        result = result['results']
        if not result: return
        actor_list = []
        if len(result) > 1:
            for item in result:
                name = item['name']
                known_for_list = [i.get('title', 'NA') for i in item['known_for']]
                known_for_list = [i for i in known_for_list if not i == 'NA']
                known_for = '[I]%s[/I]' % ', '.join(known_for_list) if known_for_list else '[I]Movie Actor[/I]'
                listitem = xbmcgui.ListItem(name, known_for, iconImage='http://image.tmdb.org/t/p/w300/%s' % item['profile_path'])
                listitem.setProperty('id', str(item['id']))
                listitem.setProperty('name', name)
                actor_list.append(listitem)
            selection = dialog.select("FEN DISCOVER: Select Correct Actor/Actress", actor_list, useDetails=True)
            if selection >= 0:
                actor_id = int(actor_list[selection].getProperty('id'))
                actor_name = actor_list[selection].getProperty('name')
            else:
                self._set_property()
        else:
            actor_id = [item['id'] for item in result][0]
            actor_name = [item['name'] for item in result][0]
        if actor_id:
            values = ('&with_cast=%s' % str(actor_id), actor_name.decode('ascii', 'ignore'))
            self._process(key, values)

    def network(self):
        key = 'network'
        if self._action(key) == 'clear': return
        from resources.lib.modules.nav_utils import networks
        network_list = []
        networks = sorted(networks, key=lambda k: k['name'])
        for item in networks:
            name = item['name']
            listitem = xbmcgui.ListItem(name, iconImage=item['logo'])
            listitem.setProperty('id', str(item['id']))
            listitem.setProperty('name', name)
            network_list.append(listitem)
        selection = dialog.select("FEN DISCOVER: Select Network", network_list, useDetails=True)
        if selection >= 0:
            network_id = int(network_list[selection].getProperty('id'))
            network_name = network_list[selection].getProperty('name')
            values = ('&with_networks=%s' % network_id, network_name)
            self._process(key, values)

    def sort_by(self):
        key = 'sort_by'
        if self._action(key) == 'clear': return
        if self.discover_params['db_type'] == 'movie':
            sort_by_list = self._movies_sort()
        else:
            sort_by_list = self._tvshows_sort()
        sort_by_value = self._selection_dialog([i[0] for i in sort_by_list], [i[1] for i in sort_by_list], 'FEN DISCOVER: Choose Certification')
        sort_by_name = [i[0] for i in sort_by_list if i[1] == sort_by_value][0]
        if sort_by_value:
            values = (sort_by_value, sort_by_name)
            self._process(key, values)

    def adult(self):
        key = 'adult'
        include_adult = self._selection_dialog(('True', 'False'), ('true', 'false'), 'FEN DISCOVER: Choose Adult Titles Inclusion')
        if include_adult:
            values = ('&include_adult=%s' % include_adult, include_adult.capitalize())
            self._process(key, values)

    def export(self):
        try:
            db_type = self.discover_params['db_type']
            query = self.discover_params['final_string']
            name = self.discover_params['name']
            set_history(db_type, name, query)
            if db_type == 'movie':
                mode = 'build_movie_list'
                action = 'tmdb_movies_discover'
            else:
                mode = 'build_tvshow_list'
                action = 'tmdb_tv_discover'
            final_params = {'name': name, 'mode': mode, 'action': action, 'query': query, 'iconImage': self.icon}
            url_params = {'mode': 'navigator.adjust_main_lists', 'method': 'add_external',
                        'list_name': name, 'menu_item': json.dumps(final_params)}
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % self._build_url(url_params))
        except:
            from resources.lib.modules.nav_utils import notification
            notification('Please set some filters before exporting')

    def history(self, display=True):
        try: from sqlite3 import dbapi2 as database
        except ImportError: from pysqlite2 import dbapi2 as database
        cache_file = xbmc.translatePath("%s/fen_cache.db" % __addon_profile__).decode('utf-8')
        settings.check_database(cache_file)
        dbcon = database.connect(cache_file)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT id, data FROM fencache WHERE id LIKE 'fen_discover_%' ORDER BY rowid DESC")
        history = dbcur.fetchall()
        data = [eval(i[1]) for i in history]
        if not display: return [i[0] for i in history]
        for count, item in enumerate(data, 1):
            try:
                cm = []
                data_id = history[count-1][0]
                name = item['name']
                url_params = {'mode': item['mode'], 'action': item['action'], 'query': item['query'],
                              'name': name, 'iconImage': self.icon}
                display = '%s | %s' % (count, name)
                url = build_url(url_params)
                remove_single_params = {'mode': 'discover.remove_from_history', 'data_id': data_id}
                remove_all_params = {'mode': 'discover.remove_all_history'}
                export_params = {'mode': 'navigator.adjust_main_lists', 'method': 'add_external',
                                'list_name': name, 'menu_item': json.dumps(url_params)}
                listitem = xbmcgui.ListItem(display, iconImage=self.icon)
                listitem.setArt({'fanart': self.fanart})
                listitem.setInfo(type='video', infoLabels={'Title': name})
                cm.append(("[B]Export List[/B]",'XBMC.RunPlugin(%s)'% self._build_url(export_params)))
                cm.append(("[B]Remove From History[/B]",'XBMC.RunPlugin(%s)'% self._build_url(remove_single_params)))
                cm.append(("[B]Clear All History[/B]",'XBMC.RunPlugin(%s)'% self._build_url(remove_all_params)))
                listitem.addContextMenuItems(cm)
                xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, isFolder=True)
            except: pass
        self._end_directory()

    def remove_from_history(self, data_id=None):
        try: from sqlite3 import dbapi2 as database
        except ImportError: from pysqlite2 import dbapi2 as database
        from resources.lib.modules.nav_utils import notification
        display_notification = False
        if not data_id:
            from urlparse import parse_qsl
            params = dict(parse_qsl(sys.argv[2].replace('?','')))
            data_id = params['data_id']
            display_notification = True
        cache_file = xbmc.translatePath("%s/fen_cache.db" % __addon_profile__).decode('utf-8')
        settings.check_database(cache_file)
        dbcon = database.connect(cache_file)
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM fencache WHERE id=?", (data_id,))
        dbcon.commit()
        window.clearProperty(data_id)
        xbmc.executebuiltin("Container.Refresh")
        if display_notification: notification('Result Removed from Discover History')

    def remove_all_history(self):
        from resources.lib.modules.nav_utils import notification
        if not dialog.yesno('Are you sure?','Fen will Clear Discover\'s  History.'): return
        all_history = self.history(display=False)
        for item in all_history:
            self.remove_from_history(data_id=item)
        notification('Discover History Cleared')

    def help(self):
        heading = 'FEN DISCOVER: Help Dialog'
        text = self._help_text()
        read = dialog.textviewer(heading, text)

    def _add_defaults(self):
        if self.discover_params['db_type'] == 'movie':
            mode = 'build_movie_list'
            action = 'tmdb_movies_discover'
        else:
            mode = 'build_tvshow_list'
            action = 'tmdb_tv_discover'
        name = self.discover_params.get('name', '...')
        query = self.discover_params.get('final_string', '')
        self._add_dir({'mode': mode, 'action': action, 'query': query, 'name': name, 'info': '', 'list_name': '[B]SAVE & BROWSE RESULTS FOR:[/B]  [I]%s[/I]' % name})
        self._add_dir({'mode': 'discover.export', 'info': '', 'list_name': '[B]EXPORT SEARCH:[/B]  [I]%s[/I]' % name})

    def _action(self, key):
        dict_item = self.discover_params
        action = 'change'
        if key in dict_item['search_name']:
            action = self._selection_dialog(['Change Filter','Clear Filter'], ('change', 'clear'), 'FEN DISCOVER: Filter Action')
        if action == 'clear':
            for k in ('search_string', 'search_name'): dict_item[k].pop(key, None)
            self._process()
        return action

    def _process(self, key=None, values=None):
        if key:
            self.discover_params['search_string'][key] = values[0]
            self.discover_params['search_name'][key] = values[1]
        self._build_string()
        self._build_name()
        self._set_property()

    def _clear_property(self):
        window.clearProperty(window_id)
        self.discover_params = {}

    def _set_property(self):
        return window.setProperty(window_id, json.dumps(self.discover_params))

    def _add_dir(self, params):
        list_name = params.get('list_name', '')
        info = params.get('info', '')
        url = self._build_url(params)
        listitem = xbmcgui.ListItem(list_name, iconImage=self.icon)
        listitem.setArt({'fanart': self.fanart})
        listitem.setInfo('video', {'title': list_name, 'plot': info})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=listitem, isFolder=True)

    def _end_directory(self):
        xbmcplugin.setContent(__handle__, 'files')
        xbmcplugin.endOfDirectory(__handle__)
        setView(self.view)

    def _build_url(self, query):
        return __url__ + '?' + urllib.urlencode(to_utf8(query))

    def _selection_dialog(self, dialog_list, function_list, string):
        list_choose = dialog.select("%s" % string, dialog_list)
        if list_choose >= 0: return function_list[list_choose]
        else: return None

    def _multiselect_dialog(self, string, dialog_list, function_list=None, preselect= []):
        if not function_list: function_list = dialog_list
        list_choose = dialog.multiselect(string, dialog_list, preselect=preselect)
        if list_choose >= 0:
            return [function_list[i] for i in list_choose]
        else:
            return

    def _build_string(self):
        string_params = self.discover_params['search_string']
        string = string_params['base']
        if 'year_start' in string_params:
            string += string_params['year_start']
        if 'year_end' in string_params:
            string += string_params['year_end']
        if 'include_genres' in string_params:
            string += string_params['include_genres']
        if 'exclude_genres' in string_params:
            string += string_params['exclude_genres']
        if 'language' in string_params:
            string += string_params['language']
        if 'region' in string_params:
            string += string_params['region']
        if 'rating' in string_params:
            string += string_params['rating']
        if 'rating_votes' in string_params:
            string += string_params['rating_votes']
        if 'certification' in string_params:
            string += string_params['certification']
        if 'cast' in string_params:
            string += string_params['cast']
        if 'network' in string_params:
            string += string_params['network']
        if 'adult' in string_params:
            string += string_params['adult']
        if 'sort_by' in string_params:
            string += string_params['sort_by']
        self.discover_params['final_string'] = string

    def _build_name(self):
        values = self.discover_params['search_name']
        name = '[B]%s[/B] ' % values['db_type']
        if 'year_start' in values:
            if 'year_end' in values:
                name += '| %s' % values['year_start']
            else:
                name += '| %s ' % values['year_start']
        if 'year_end' in values:
            if 'year_start' in values:
                name += '-%s ' % values['year_end']
            else:
                name += '| %s ' % values['year_end']
        if 'language' in values:
            name += '| %s ' % values['language']
        if 'region' in values:
            name += '| %s ' % values['region']
        if 'network' in values:
            name += '| %s ' % values['network']
        if 'include_genres' in values:
            name += '| %s ' % values['include_genres']
            if 'exclude_genres' in values:
                name += '(not %s) ' % values['exclude_genres']
        elif 'exclude_genres' in values:
            name += '| not %s ' % values['exclude_genres']
        if 'certification' in values:
            name += '| %s ' % values['certification']
        if 'rating' in values:
            name += '| %s+ ' % values['rating']
        if 'cast' in values:
            name += '| with %s ' % values['cast']
        if 'sort_by' in values:
            name += '| %s ' % values['sort_by']
        self.discover_params['name'] = name

    def _movies_sort(self):
        return [
            ('Popularity (asc)', '&sort_by=popularity.asc'),
            ('Popularity (desc)', '&sort_by=popularity.desc'),
            ('Release Date (asc)', '&sort_by=primary_release_date.asc'),
            ('Release Date (desc)', '&sort_by=primary_release_date.desc'),
            ('Revenue (asc)', '&sort_by=revenue.asc'),
            ('Revenue (desc)', '&sort_by=revenue.desc'),
            ('Title (asc)', '&sort_by=original_title.asc'),
            ('Title (desc)', '&sort_by=original_title.desc'),
            ('Rating (asc)', '&sort_by=vote_average.asc'),
            ('Rating (desc)', '&sort_by=vote_average.desc')
                ]

    def _tvshows_sort(self):
        return [
            ('Popularity (asc)', '&sort_by=popularity.asc'),
            ('Popularity (desc)', '&sort_by=popularity.desc'),
            ('First Aired (asc)', '&sort_by=first_air_date.asc'),
            ('First Aired (desc)', '&sort_by=first_air_date.desc'),
            ('Rating (asc)', '&sort_by=vote_average.asc'),
            ('Rating (desc)', '&sort_by=vote_average.desc')
            ]

    def _help_text(self):
        text = '' \
        '*Select a category and assign a filter value. You only need to assign the values you wish ' \
        'to include in the search. e.g. If you don\'t need a certain actor included, then leave "Includes Cast Member" blank etc. ' \
        ' \n\n*Once you have filled in all the categories you need, hit "Save & Browse Results" to immediately browse the results. ' \
        '\n\n*Alternately, you can select "Export Search", give the search a name, and choose which of the main Fen lists you wish to save it to ' \
        'e.g. Root Menu or Movies or TV Shows. You can then browse that list whenever you want, without having to re-enter the ' \
        'different filters continuously.' \
        '\n\n*Fen will keep a history of the last 7 days of filtered lists you have made. Select "Discover: History" to re-browse these lists.' \
        '\n\n[B]EXAMPLE:[/B]' \
        '\n[I]You want to search for Comedy Action Movies made in the 1980\'s that are PG Rated.[/I]' \
        '\n    - Assign a "[B]Year Start[/B]" filter of "1980"' \
        '\n    - Assign a "[B]Year End[/B]" filter of "1989"' \
        '\n    - Assign a "[B]Include Genres[/B]" filter of "Action, Comedy"' \
        '\n    - Assign a "[B]Certification[/B]" filter of "PG"' \
        '\n    - Select "[B]Browse Results[/B]" to immediately see the results or "[B]Export List[/B]" to export the list to Fen Root Menu or Fen Movies Menu etc"' \
        '\n\n[B]Enjoy your 1980\'s Action/Comedy Family Movie Night!!![/B]'
        return text

def set_history(db_type, name, query):
    from resources.lib.modules import fen_cache
    from datetime import timedelta
    _cache = fen_cache.FenCache()
    string = 'fen_discover_' + name
    cache = _cache.get(string)
    if cache: return
    if db_type == 'movie':
        mode = 'build_movie_list'
        action = 'tmdb_movies_discover'
    else:
        mode = 'build_tvshow_list'
        action = 'tmdb_tv_discover'
    data = {'mode': mode, 'action': action, 'name': name, 'query': query}
    _cache.set(string, data, expiration=timedelta(days=7))
    return