

furk_results = []
local_results = []
universal_results = []
