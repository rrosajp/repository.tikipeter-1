import xbmc, xbmcaddon, xbmcgui
import json
from resources.lib.modules.utils import clean_file_name
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.furkit'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
dialog = xbmcgui.Dialog()
window = xbmcgui.Window(10000)

def retrieve_kodi_library(db_type, page_no, passed_list=[]):
    import ast
    from resources.lib.modules.utils import title_key, to_utf8
    from resources.lib.modules.nav_utils import paginate_list
    if not passed_list:
        original_list = []
        if db_type == 'movies':
            JSON_req = '{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", \
            "params": {"properties": ["title", "imdbnumber"]},"id": "1"}'
            r = xbmc.executeJSONRPC(JSON_req)
            r = to_utf8(json.loads(r)['result'][db_type])
            r = sorted(r, key=lambda k: title_key(k['title']))
            original_list = [i.get('imdbnumber', None) for i in r]
        elif db_type == 'tvshows':
            JSON_req = '{"jsonrpc": "2.0", "method": "VideoLibrary.GetTvShows", \
            "params": {"properties": ["title","imdbnumber","uniqueid"]}, "id": "1"}'
            r = xbmc.executeJSONRPC(JSON_req)
            r = to_utf8(json.loads(r)['result'][db_type])
            r = sorted(r, key=lambda k: title_key(k['title']))
            original_list = [i['uniqueid']['tvdb'] if 'uniqueid' in i and 'tvdb' in i['uniqueid'] else i['imdbnumber'] if not i['imdbnumber'].startswith("tt") else None for i in r]
    else: original_list = ast.literal_eval(passed_list)
    total_pages = len(original_list)/20 + 1
    paginated_list = paginate_list(original_list, page_no, 20)
    return paginated_list, original_list, total_pages

def get_library_video(db_type, title, year, season=None, episode=None):
    import xbmcvfs
    try:
        years = (year, str(int(year)+1), str(int(year)-1))
        if db_type == 'movie':
            r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties": ["imdbnumber", "title", "originaltitle", "file"]}, "id": 1}' % years)
            r = unicode(r, 'utf-8', errors='ignore')
            r = json.loads(r)['result']['movies']
            try:
                r = [i for i in r if clean_file_name(title).lower() in clean_file_name(i['title']).lower()]
            except:
                return None
            r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovieDetails", "params": {"properties": ["streamdetails", "file"], "movieid": %s }, "id": 1}' % str(r['movieid']))
            r = unicode(r, 'utf-8', errors='ignore')
            r = json.loads(r)['result']['moviedetails']

        elif db_type == 'tvshow':
            r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties": ["title", "year"]}, "id": 1}' % years)
            r = unicode(r, 'utf-8', errors='ignore')
            r = json.loads(r)['result']['tvshows']
            try:
                r = [i for i in r if clean_file_name(title).lower() in clean_file_name(i['title']).lower()][0]
                return r
            except:
                return None

        elif db_type == 'episode':
            r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties": ["title"]}, "id": 1}' % years)
            r = unicode(r, 'utf-8', errors='ignore')
            r = json.loads(r)['result']['tvshows']
            try:
                r = [i for i in r if clean_file_name(title).lower() in (clean_file_name(i['title']).lower() if not ' (' in i['title'] else clean_file_name(i['title']).lower().split(' (')[0])][0]
            except:
                return None
            r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["file"], "tvshowid": %s }, "id": 1}' % (str(season), str(episode), str(r['tvshowid'])))
            r = unicode(r, 'utf-8', errors='ignore')
            r = json.loads(r)['result']['episodes']
            try:
                r = r[0]
            except:
                return None
            r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodeDetails", "params": {"properties": ["streamdetails", "file"], "episodeid": %s }, "id": 1}' % str(r['episodeid']))
            r = unicode(r, 'utf-8', errors='ignore')
            r = json.loads(r)['result']['episodedetails']

        url = r['file'].encode('utf-8')
        try: quality = int(r['streamdetails']['video'][0]['width'])
        except: quality = -1
        if quality > 1920: quality = '2160p'
        if quality >= 1920: quality = '1080p'
        if 1280 <= quality < 1900: quality = 'HD'
        if quality < 1280: quality = 'HQ'

        release_details = []
        try:
            f = xbmcvfs.File(url) ; s = f.size() ; f.close()
            s = '%.2f GB' % (float(s)/1024/1024/1024)
            release_details.append(s)
        except: pass
        try:
            c = r['streamdetails']['video'][0]['codec']
            if c == 'avc1': c = 'h264'
            release_details.append(c)
        except: pass
        try:
            ac = r['streamdetails']['audio'][0]['codec']
            if ac == 'dca': ac = 'dts'
            if ac == 'dtshd_ma': ac = 'dts-hd ma'
            release_details.append(ac)
        except: pass

        try:
            ach = r['streamdetails']['audio'][0]['channels']
            if ach == 1: ach = 'mono'
            if ach == 2: ach = '2.0'
            if ach == 6: ach = '5.1'
            if ach == 8: ach = '7.1'
            release_details.append(ach)
        except: pass

        release_details = ' | '.join(release_details)
        release_details = release_details.encode('utf-8')
        return {'label': title, 'path': url, 'quality': quality, 'release_details': release_details}
    except: pass

def set_bookmark_kodi_library(db_type, tmdb_id, curr_time, season='', episode=''):
    from resources.lib.modules.nav_utils import get_meta
    try:
        info = get_meta('movie', 'tmdb_id', tmdb_id) if db_type == 'movie' else get_meta('tvshow', 'tmdb_id', tmdb_id)
        title = info['title']
        year = info['year']
        years = (str(year), str(int(year)+1), str(int(year)-1))
        if db_type == 'movie': r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties": ["title"]}, "id": 1}' % years)
        else: r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties": ["title"]}, "id": 1}' % years)
        r = unicode(r, 'utf-8', errors='ignore')
        r = json.loads(r)['result']['movies'] if db_type == 'movie' else json.loads(r)['result']['tvshows']
        r = [i for i in r if title in (i['title'])][0]
        if db_type == 'episode':
            r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["file"], "tvshowid": %s }, "id": 1}' % (str(season), str(episode), str(r['tvshowid'])))
            r = unicode(r, 'utf-8', errors='ignore')
            r = json.loads(r)['result']['episodes'][0]
        (method, id_name, library_id) = ('SetMovieDetails', 'movieid', r['movieid']) if db_type == 'movie' else ('SetEpisodeDetails', 'episodeid', r['episodeid'])
        query = {"jsonrpc": "2.0", "id": "setResumePoint", "method": "VideoLibrary."+method, "params": {id_name: library_id, "resume": {"position": curr_time,}}}
        jsonResponse = json.loads(xbmc.executeJSONRPC(json.dumps(query)))
    except: pass

def mark_as_watched_unwatched_kodi_library(db_type, action, title, year, season=None, episode=None):
    from resources.lib.modules.utils import clean_file_name
    years = (year, str(int(year)+1), str(int(year)-1))
    playcount = '1' if action == 'mark_as_watched' else '0'
    if db_type == 'movie':
        try:
            r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties": ["imdbnumber", "title", "originaltitle", "file"]}, "id": 1}' % years)
            r = unicode(r, 'utf-8', errors='ignore')
            r = json.loads(r)['result']['movies']
            r = [i for i in r if clean_file_name(title).lower() in clean_file_name(i['title']).lower()]
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.SetMovieDetails", "params": {"movieid" : %s, "playcount" : %s }, "id": 1 }' % (str(r[0]['movieid']), playcount))
        except: return
    elif db_type == 'episode':
        try:
            title = title.split(' -')[0] if ' -' in title else title
            r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "params": {"filter": {"and": [{"operator": "contains", "field": "title", "value": "%s"}, {"operator": "contains", "field": "year", "value": "%s"}]}, "properties": ["title"]}, "method": "VideoLibrary.GetTVShows", "id": "libTags"}' % (str(title), str(year)))
            r = unicode(r, 'utf-8', errors='ignore')
            r = json.loads(r)['result']['tvshows'][0]
            if clean_file_name(title).lower() in clean_file_name(r['title']).lower(): tvshowid = r['tvshowid']
            else: return
            r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["file"], "tvshowid": %s }, "id": 1}' % (str(season), str(episode), str(tvshowid)))
            r = unicode(r, 'utf-8', errors='ignore')
            r = json.loads(r)['result']['episodes']
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.SetEpisodeDetails", "params": {"episodeid" : %s, "playcount" : %s }, "id": 1 }' % (str(r[0]['episodeid']), playcount))
        except: return
    try:
        (method, id_name, library_id) = ('SetMovieDetails', 'movieid', r[0]['movieid']) if db_type == 'movie' else ('SetEpisodeDetails', 'episodeid', r[0]['episodeid'])
        query = {"jsonrpc": "2.0", "id": "setResumePoint", "method": "VideoLibrary."+method, "params": {id_name: library_id, "resume": {"position": 0,}}}
        jsonResponse = json.loads(xbmc.executeJSONRPC(json.dumps(query)))
    except:pass

def batch_mark_episodes_as_watched_unwatched_kodi_library(show_info, list_object):
    media = list_object['media']
    action = list_object['action']
    title = list_object['name']
    year = list_object['year']
    episode_list = list_object['season_ep_list']
    tvshowid = list_object['tvshowid']
    playcount = 1 if action == 'mark_as_watched' else 0
    title = title.split(' -')[0] if ' -' in title else title
    tvshowid = str(show_info['tvshowid'])
    ep_ids = []
    action_list = []
    count = 1
    bg_dialog = xbmcgui.DialogProgressBG()
    bg_dialog.create('Please Wait', '')
    try:
        for item in episode_list:
            try:
                season = item.split('<>')[0]
                episode = item.split('<>')[1]
                r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["file", "playcount"], "tvshowid": %s }, "id": 1}' % (str(season), str(episode), str(tvshowid)))
                r = unicode(r, 'utf-8', errors='ignore')
                r = json.loads(r)['result']['episodes']
                ep_ids.append('%s<>%s' % (r[0]['episodeid'], r[0]['playcount']))
            except: pass
        for item in ep_ids:
            try:
                ep_id = item.split('<>')[0]
                current_playcount = item.split('<>')[1]
                if int(current_playcount) != playcount:
                    xbmc.sleep(50)
                    display = 'Syncing Kodi Library Watched Status'
                    bg_dialog.update(int(float(count) / float(len(ep_ids)) * 100), 'Please Wait', '%s' % display)
                    count += 1
                    t = '{"jsonrpc": "2.0", "method": "VideoLibrary.SetEpisodeDetails", "params": {"episodeid" : %d, "playcount" : %d }, "id": 1 }' % (int(ep_id) ,playcount)
                    t = json.loads(t)
                    action_list.append(t)
                else: pass
            except: pass
        bg_dialog.update(100, 'Please Wait', 'Finalizing Sync with Kodi Library')
        r = xbmc.executeJSONRPC(json.dumps(action_list))
        bg_dialog.close()
        return r
    except: pass

        