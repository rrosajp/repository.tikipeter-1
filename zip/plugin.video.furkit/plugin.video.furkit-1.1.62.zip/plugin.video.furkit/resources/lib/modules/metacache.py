#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcvfs
import os
import datetime
import time
import sqlite3 as database
# from resources.lib.modules.utils import logger

class MetaCache():

    def __init__(self):
        self.db_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.furkit'), '')
        self.dbfile = xbmc.translatePath("%s/metacache.db" % self.db_path).decode('utf-8')
        self._win = xbmcgui.Window(10000)
        self.db_status = self._get_db_status()
        self.autoclean_interval = 2
        self._check_cleanup()

    def get(self, db_type, id_type, media_id):
        result = None
        try:
            current_time = self._get_timestamp(datetime.datetime.now())
            dbcon = database.connect(self.dbfile)
            dbcur = dbcon.cursor()
            dbcur.execute("SELECT meta, expires FROM metadata WHERE db_type = ? AND %s = ?" % id_type, (str(db_type), str(media_id)))
            cache_data = dbcur.fetchone()
            if cache_data:
                if cache_data[1] > current_time:
                    result = eval(cache_data[0])
                else:
                    dbcur.execute("DELETE FROM metadata WHERE db_type = ? AND %s = ?" % id_type, (str(db_type), str(media_id)))
                    dbcon.commit()
                    dbcon.close()
        except: pass
        return result

    def set(self, db_type, meta, expiration=datetime.timedelta(days=30)):
        try:
            expires = self._get_timestamp(datetime.datetime.now() + expiration)
            if self.db_status:
                dbcon = database.connect(self.dbfile)
                dbcur = dbcon.cursor()
                dbcur.execute("INSERT INTO metadata VALUES (?, ?, ?, ?, ?, ?)", (str(db_type), str(meta['tmdb_id']), str(meta['imdb_id']), str(meta['tvdb_id']), repr(meta), int(expires)))
                dbcon.commit()
                dbcon.close()
            else: pass
        except: return

    def delete(self, db_type, id_type, media_id):
        try:
            dbcon = database.connect(self.dbfile)
            dbcur = dbcon.cursor()
            dbcur.execute("DELETE FROM metadata WHERE db_type = ? AND %s = ?" % id_type, (str(db_type), str(media_id)))
            dbcon.commit()
            dbcon.close()
        except: return

    def _get_db_status(self):
        if not xbmcvfs.exists(self.dbfile):
            from resources.lib.modules.settings import initialize_databases
            return initialize_databases()
        else: return True

    def _check_cleanup(self):
        try:
            next_run = datetime.datetime.fromtimestamp(time.mktime(time.strptime(self._win.getProperty("metacache.clean.lastexecuted").encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
            now = datetime.datetime.now()
            if now > next_run:
                self._do_cleanup()
                self._win.setProperty("metacache.clean.lastexecuted", str(datetime.datetime.now() + datetime.timedelta(hours=self.autoclean_interval)).split('.')[0])
            else:
                pass
        except:
            self._win.setProperty("metacache.clean.lastexecuted", str(datetime.datetime.now() + datetime.timedelta(hours=self.autoclean_interval)).split('.')[0])

    def _do_cleanup(self):
        current_time = self._get_timestamp(datetime.datetime.now())
        if self._win.getProperty("metacachecleanbusy"): return
        self._win.setProperty("metacachecleanbusy", "busy")
        dbcon = database.connect(self.dbfile)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT tmdb_id, expires FROM metadata")
        for cache_data in dbcur.fetchall():
            if current_time > cache_data[1]:
                dbcur.execute("DELETE FROM metadata WHERE tmdb_id = ?", (cache_data[0],))
                dbcon.commit()
        dbcon.close()
        dbcon = database.connect(self.dbfile)
        dbcon.execute("VACUUM")
        self._win.setProperty("metacache.clean.lastexecuted", str(datetime.datetime.now() + datetime.timedelta(hours=self.autoclean_interval)).split('.')[0])
        self._win.clearProperty("metacachecleanbusy")

    def _get_timestamp(self, date_time):
        return int(time.mktime(date_time.timetuple()))

