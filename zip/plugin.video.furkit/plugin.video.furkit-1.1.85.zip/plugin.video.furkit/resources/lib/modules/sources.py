
import xbmc
import threading
from operator import itemgetter
from resources.lib.modules import global_vars as g
from resources.lib.modules.nav_utils import build_url, close_all_dialog, show_busy_dialog, hide_busy_dialog
from resources.lib.modules.workers import Thread
from resources.lib.sources.furk import FurkSource
from resources.lib.sources.easynews import EasyNewsSource
from resources.lib.sources.local_library import LocalLibrarySource
from resources.lib.modules import settings
# from resources.lib.modules.utils import logger


class Sources:
    def __init__(self, use_dialog, from_library):
        self.origin = 'context' if from_library else None
        self.autoplay = settings.auto_play(self.origin)
        self.prefer_hevc = settings.prefer_hevc(self.origin)
        self.check_library = settings.check_library()
        self.include_prerelease_results = settings.include_prerelease_results(self.origin)
        self.include_uncached_results = settings.include_uncached_results()
        self.use_dialog = True if use_dialog else False
        self.from_library = True if from_library else False

    def get_sources(self, db_type, title, year=None, season=None, episode=None, imdb_id=None):
        close_all_dialog()
        self.db_type = db_type
        self.title = title
        self.year = year
        self.season = season if season else ''
        self.episode = episode if episode else ''
        self.imdb_id = imdb_id
        self.search_info = self._search_info()
        return self._collect_results()

    def _collect_results(self):
        show_busy_dialog()
        threads = []
        active_scrapers = settings.active_scrapers()
        if 'local' in active_scrapers:
            if self.check_library:
                if self._check_library_before_search(): return g.local_results
            else: threads.append(Thread(LocalLibrarySource().results, self.search_info))
        if 'furk' in active_scrapers:
            threads.append(Thread(FurkSource().results, self.search_info))
        if 'easynews' in active_scrapers:
            threads.append(Thread(EasyNewsSource().results, self.search_info))
        [i.start() for i in threads]
        [i.join() for i in threads]
        all_results = g.local_results + g.furk_results + g.easynews_results
        return self._filter_results(all_results)

    def _filter_results(self, orig_results):
        results = []
        cached_results = [i for i in orig_results if not ('UNCACHED' in i['display_name'] or 'ACTIVE' in i['display_name'])]
        self.uncached_results = [i for i in orig_results if ('UNCACHED' in i['display_name'] or 'ACTIVE' in i['display_name'])]
        quality_filter = self._quality_filter()
        include_local_in_filter = settings.include_local_in_filter(self.autoplay)
        for item in cached_results:
            if item.get("local") and not include_local_in_filter: results.append(item)
            elif item.get("quality") in quality_filter: results.append(item)
        return self._sort_results(results)

    def _sort_results(self, results):
        for item in results:
            item['quality_rank'] = self._get_quality_rank(item.get("quality"))
            item['name_rank'] = self._get_name_rank(item.get("display_name"))
        results = sorted(results, key=itemgetter('name_rank', 'quality_rank', 'size'), reverse=True)
        return self._return_results(results)

    def _return_results(self, results):
        hide_busy_dialog()
        if self.autoplay:
            return self._filter_autoplay(results)
        if self.include_uncached_results: results += self.uncached_results
        return results

    def _filter_autoplay(self, results):
        local_file = [i for i in results if i.get("local")]
        if local_file: results = local_file
        else:
            if self.prefer_hevc:
                hevc_list = [dict(i, **{'hevc':self._get_hevc_status(i.get("display_name"))}) for i in results]
                hevc_list = [i for i in hevc_list if i.get("hevc")]
                if hevc_list: results = hevc_list
        results = [dict(i, **{'autoplay':True}) for i in results]
        return results

    def _check_library_before_search(self):
        import xbmcgui
        LocalLibrarySource().results(self.search_info)
        if g.local_results:
            line = '%s (%s)' % (self.title, self.year) if self.db_type == 'movie' else '%s - %dx%.2d' % (self.title, int(self.season), int(self.episode))
            if xbmcgui.Dialog().yesno("%s found in Kodi Database" % line, "Would you like to play the local file?", '', '', 'Yes', 'No') == 0:
                g.local_results[0]['play_local'] = True
                return True
            else:
                g.local_results = []
                return False
        else: pass

    def _search_info(self):
        return {'db_type':self.db_type, 'title': self.title, 'year': self.year,
                'season': self.season, 'episode': self.episode, 'imdb_id': self.imdb_id}

    def _quality_filter(self):
        sl = ['results_quality', 'autoplay_quality', 'results_quality_library', 'autoplay_quality_library']
        if not self.from_library: setting = sl[0] if not self.autoplay else sl[1]
        elif self.from_library: setting = sl[2] if not self.autoplay else sl[3]
        quality_filter = settings.quality_filter(setting)
        if self.include_prerelease_results: quality_filter += ['SCR', 'CAM', 'TELE']
        return quality_filter

    def _get_quality_rank(self, quality):
        if quality == '4K': return 6
        elif quality == '1080p': return 5
        elif quality == '720p': return 4
        elif quality == 'SD': return 3
        elif quality in ['SCR', 'CAM', 'TELE']: return 2
        else: return 1

    def _get_name_rank(self, name):
        if 'LOCAL' in name: return 2
        else: return 1

    def _get_hevc_status(self, description):
        if 'HEVC' in description: return True 
        else: return False
