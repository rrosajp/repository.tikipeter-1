
# import threading
# from urlparse import parse_qsl
import xbmc, xbmcgui, xbmcplugin
import sys, os
import json
import urllib
from operator import itemgetter
from resources.lib.modules import global_vars as g
from resources.lib.sources.furk import FurkSource
from resources.lib.sources.easynews import EasyNewsSource
from resources.lib.sources.local_library import LocalLibrarySource
from resources.lib.modules.workers import Thread
from resources.lib.modules.utils import clean_file_name, to_utf8
from resources.lib.indexers.furk import t_file_browser, seas_ep_query_list, add_uncached_file
from resources.lib.modules.nav_utils import get_meta, build_url, setView, close_all_dialog, show_busy_dialog, hide_busy_dialog
from resources.lib.modules import settings
# from resources.lib.modules.utils import logger

__handle__ = int(sys.argv[1])
window = xbmcgui.Window(10000)
dialog = xbmcgui.Dialog()
default_furk_icon = os.path.join(settings.get_theme(), 'furk.png')

class Sources:
    def __init__(self):
        close_all_dialog()

    def playback_prep(self, vid_type, tmdb_id, query, tvshowtitle=None, season=None, episode=None, ep_name=None, plot=None, meta=None, from_library=False, background='false'):
        self.from_library = from_library
        self.not_widget = xbmc.getInfoLabel('Container.PluginName')
        self.action = 'XBMC.Container.Update(%s)' if self.not_widget else 'XBMC.RunPlugin(%s)'
        self.use_dialog = True if self.from_library or not self.not_widget else settings.use_dialog()
        self.origin = 'context' if self.from_library else None
        self.autoplay = settings.auto_play(self.origin)
        self.prefer_hevc = settings.prefer_hevc(self.origin)
        self.check_library = settings.check_library()
        self.include_prerelease_results = settings.include_prerelease_results(self.origin)
        self.include_uncached_results = settings.include_uncached_results()
        self.search_provider = settings.search_provider()
        self.meta = json.loads(meta) if meta else get_meta("movie" if vid_type == "movie" else "tvshow", 'tmdb_id', tmdb_id)
        self.vid_type = vid_type
        self.tmdb_id = tmdb_id
        self.season = int(season) if season else ''
        self.episode = int(episode) if episode else ''
        display_name = clean_file_name(urllib.unquote(query)) if vid_type == 'movie' else '%s - %dx%.2d' % (self.meta['title'], self.season, self.episode)
        if from_library: self.meta.update({'plot': plot, 'from_library': 'true', 'ep_name': ep_name})
        self.meta.update({'query': query, 'vid_type': self.vid_type, 'media_id': self.tmdb_id,
            'rootname': display_name, 'tvshowtitle': self.meta['title'], 'season': self.season,
            'episode': self.episode, 'background': background})
        self.search_info = self._search_info()
        window.clearProperty('furkit_media_meta')
        window.setProperty('furkit_media_meta', json.dumps(self.meta))
        self.get_sources()

    def get_sources(self):
        if self.search_provider == 'universal': return self._universal_results()
        else: return self._collect_results()

    def _universal_results(self):
        from resources.lib.sources.universal_scrapers import UniversalScrapersSource
        show_busy_dialog()
        link = UniversalScrapersSource().results(self.search_info)
        return UniversalScrapersSource().resolve_universal(link)

    def _collect_results(self):
        show_busy_dialog()
        threads = []
        active_scrapers = settings.active_scrapers()
        if 'local' in active_scrapers:
            if self.check_library:
                if self._check_library_before_search():
                    results = g.local_results
                    window.clearProperty('furkit_search_results')
                    window.setProperty('furkit_search_results', json.dumps(results))
                    return xbmc.executebuiltin(self.action % build_url({'mode': 'play_display_results', 'use_dialog': self.use_dialog, 'from_library': self.from_library}))
            else: threads.append(Thread(LocalLibrarySource().results, self.search_info))
        if 'furk' in active_scrapers:
            threads.append(Thread(FurkSource().results, self.search_info))
        if 'easynews' in active_scrapers:
            threads.append(Thread(EasyNewsSource().results, self.search_info))
        [i.start() for i in threads]
        [i.join() for i in threads]
        all_results = g.local_results + g.furk_results + g.easynews_results
        return self._filter_results(all_results)

    def _filter_results(self, orig_results):
        results = []
        cached_results = [i for i in orig_results if not 'uncached' in i]
        self.uncached_results = [i for i in orig_results if 'uncached' in i]
        quality_filter = self._quality_filter()
        include_local_in_filter = settings.include_local_in_filter(self.autoplay)
        for item in cached_results:
            if item.get("local") and not include_local_in_filter: results.append(item)
            elif item.get("quality") in quality_filter: results.append(item)
        return self._sort_results(results)

    def _sort_results(self, results):
        for item in results:
            item['quality_rank'] = self._get_quality_rank(item.get("quality"))
            item['name_rank'] = self._get_name_rank(item.get("display_name"))
        results = sorted(results, key=itemgetter('name_rank', 'quality_rank', 'size'), reverse=True)
        return self._return_results(results)

    def _return_results(self, results):
        if self.autoplay:
            return self._filter_autoplay(results)
        if self.include_uncached_results: results += self.uncached_results
        window.clearProperty('furkit_search_results')
        window.setProperty('furkit_search_results', json.dumps(results))
        hide_busy_dialog()
        return xbmc.executebuiltin(self.action % build_url({'mode': 'play_display_results', 'use_dialog': self.use_dialog, 'from_library': self.from_library}))

    def display_results(self, use_dialog=False, from_library=False):
        def _autoplay_file(item):
            show_busy_dialog()
            if from_library: return _play_file(item)
            if item['provider'] in ('local', 'easynews'):
                url = build_url({'mode': 'bookmark_choice', 'url': item['url_dl']})
            else:
                filtering_list = seas_ep_query_list(meta['season'], meta['episode']) if meta['vid_type'] == 'episode' else ''
                t_files = t_file_browser(item.get("id"), filtering_list)
                url = build_url({'mode': 'bookmark_choice', 'url': t_files[0]['url_dl']})
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % url)
        def _play_file(item):
            if item['provider'] in ('local', 'easynews'):
                url = build_url({'mode': 'bookmark_choice', 'url': item['url_dl']})
            else:
                filtering_list = seas_ep_query_list(meta['season'], meta['episode']) if meta['vid_type'] == 'episode' else ''
                t_files = t_file_browser(item['id'], filtering_list, auto_play_setting)
                if not (settings.auto_play(auto_play_setting) or settings.auto_resolve(auto_play_setting)):
                    display_list = []
                    for item in t_files:
                        listitem = xbmcgui.ListItem(item['display_name'], '[I]%s[/I]' % clean_file_name(item['name']), iconImage=meta['poster'])
                        listitem.setProperty('url_dl', item['url_dl'])
                        display_list.append(listitem)
                    chosen = dialog.select("Furk Results", display_list, useDetails=True)
                    if chosen < 0: return
                    url_dl = display_list[chosen].getProperty('url_dl')
                else: url_dl = t_files[0]['url_dl']
                url = build_url({'mode': 'bookmark_choice', 'url': url_dl})
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % url)
        display_list = []
        auto_play_setting = 'library' if from_library else None
        results = json.loads(window.getProperty('furkit_search_results'))
        meta = json.loads(window.getProperty('furkit_media_meta'))
        if meta['vid_type'] == 'episode' and meta.get('background') == 'true':
            from resources.lib.modules.player import FurkitPlayer
            from resources.lib.modules.nav_utils import notification
            notification('%s %s S%02dE%02d' % ('Next Up Autoplay:', meta['title'], meta['season'], meta['episode']), 10000, meta['poster'])
            PLAYER = FurkitPlayer()
            while PLAYER.isPlaying(): xbmc.sleep(100)
        if not results: return dialog.ok('Furk It', 'No Results')
        if results[0].get('play_local', False) or results[0].get('autoplay', False): return _autoplay_file(results[0])
        try:
            for count, item in enumerate(results, 1):
                uncached = item.get('uncached', False)
                mode = 'bookmark_choice' if item['provider'] in ('local', 'easynews') else 'furk.add_uncached_file' if uncached else 'furk.media_tfile'
                play_url = item.get("url_dl") if item['provider'] in ('local', 'easynews') else ''
                url = build_url({'mode': mode, 'name': item.get('name'), 'id': item.get("id"), 'url': play_url})
                contextMenuItems = []
                display_name = item.get("display_name") if not use_dialog else item.get("display_name").replace('[B]', '').replace('[/B]', '').replace('[I]', '').replace('[/I]', '')
                display = '%02d | %s' % (count, display_name)
                listitem = xbmcgui.ListItem(display) if not use_dialog else xbmcgui.ListItem(display, '[I]%s[/I]' % clean_file_name(to_utf8(item['name'])), iconImage=meta['poster'])
                if use_dialog: listitem.setProperty('uncached', str(uncached))
                if use_dialog: listitem.setProperty('item', json.dumps(item))
                if use_dialog: display_list.append(listitem)
                listitem.setArt({'poster': meta.get('poster', ''), 'thumb': meta.get('poster', ''), 'fanart': meta.get('fanart', '')})
                playback_params = {'mode': 'playback_menu', 'from_results': True}
                add_files_params = {'mode': 'furk.add_to_files', 'name': item.get("name"), 'item_id': item.get("id")}
                down_archive_params = {'mode': 'download_file', 'name': item.get("name"), 'url': item.get("url_dl"), 'db_type': 'archive', 'image': default_furk_icon}
                contextMenuItems.append(("Playback/Search Options",'XBMC.RunPlugin(%s)' % build_url(playback_params)))
                if not item['provider'] in ('local', 'easynews') or uncached:
                    contextMenuItems.append(("Add to My Files",'XBMC.RunPlugin(%s)'  % build_url(add_files_params)))
                    contextMenuItems.append(("Download Archive",'XBMC.RunPlugin(%s)' % build_url(down_archive_params)))
                listitem.addContextMenuItems(contextMenuItems)
                if meta['vid_type'] == 'movie': listitem.setInfo('video', {'title': meta.get('title', ''), 'year': meta.get('year', ''), 'plot': meta.get('plot', '')})
                elif meta['vid_type'] == 'episode': listitem.setInfo('video', {'title': meta.get('rootname', ''), 'plot': meta.get('plot', '')})
                if not use_dialog: xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=True)
            if use_dialog:
                chosen = dialog.select("Furk It Results", display_list, useDetails=True)
                if chosen < 0: return
                chosen_result = display_list[chosen]
                chosen_item = json.loads(chosen_result.getProperty('item'))
                if chosen_result.getProperty('uncached') == 'True': return add_uncached_file(chosen_item.get('name'), chosen_item.get('id'))
                return _play_file(chosen_item)
            xbmcplugin.setContent(__handle__, 'files')
            xbmcplugin.endOfDirectory(__handle__)
            setView(settings.SETTING_MEDIA_RESULTS_VIEW)
        except: 
            return dialog.ok('%s.' % 'Furk It', '%s.' % 'Error Getting Results')

    def _search_info(self):
        return {'db_type': self.vid_type, 'title': self.meta.get('title'), 'year': self.meta.get('year'),
        'tmdb_id': self.tmdb_id, 'imdb_id': self.meta.get('imdb_id'), 'season': self.season,
        'episode': self.episode, 'premiered': self.meta.get('premiered'), 'tvdb_id': self.meta.get('tvdb_id'),
        'ep_name': self.meta.get('ep_name')}

    def _filter_autoplay(self, results):
        local_file = [i for i in results if i.get("local")]
        if local_file: results = local_file
        else:
            if self.prefer_hevc:
                hevc_list = [dict(i, **{'hevc':self._get_hevc_status(i.get("display_name"))}) for i in results]
                hevc_list = [i for i in hevc_list if i.get("hevc")]
                if hevc_list: results = hevc_list
        results = [dict(i, **{'autoplay':True}) for i in results]
        window.clearProperty('furkit_search_results')
        window.setProperty('furkit_search_results', json.dumps(results))
        return xbmc.executebuiltin(self.action % build_url({'mode': 'play_display_results', 'use_dialog': self.use_dialog, 'from_library': self.from_library}))

    def _check_library_before_search(self):
        import xbmcgui
        LocalLibrarySource().results(self.search_info)
        if g.local_results:
            line = '%s (%s)' % (self.meta['title'], self.meta['year']) if self.vid_type == 'movie' else '%s - %dx%.2d' % (self.meta['title'], int(self.meta['season']), int(self.meta['episode']))
            if xbmcgui.Dialog().yesno("%s found in Kodi Database" % line, "Would you like to play the local file?", '', '', 'Yes', 'No') == 0:
                g.local_results[0]['play_local'] = True
                return True
            else:
                g.local_results = []
                return False
        else: pass

    def _quality_filter(self):
        sl = ['results_quality', 'autoplay_quality', 'results_quality_library', 'autoplay_quality_library']
        if not self.from_library: setting = sl[0] if not self.autoplay else sl[1]
        elif self.from_library: setting = sl[2] if not self.autoplay else sl[3]
        quality_filter = settings.quality_filter(setting)
        if self.include_prerelease_results: quality_filter += ['SCR', 'CAM', 'TELE']
        return quality_filter

    def _get_quality_rank(self, quality):
        if quality == '4K': return 6
        elif quality == '1080p': return 5
        elif quality == '720p': return 4
        elif quality == 'SD': return 3
        elif quality in ['SCR', 'CAM', 'TELE']: return 2
        else: return 1

    def _get_name_rank(self, name):
        if 'LOCAL' in name: return 3
        elif 'DEBRID' in name: return 2
        else: return 1

    def _get_hevc_status(self, description):
        if 'HEVC' in description: return True 
        else: return False
