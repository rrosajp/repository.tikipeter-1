import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import os
import shutil
import json
from resources.lib.modules.nav_utils import show_busy_dialog, hide_busy_dialog, notification
from resources.lib.modules.utils import logger

dialog = xbmcgui.Dialog()

class ExternalImporter():
    def __init__(self):
        self.ext_path = None

    def import_external(self):
        self.set_import_addon()
        if not self.ext_path: return notification('External Scrapers Activation Failed. Please See Log Error', 5000)
        else:
            show_busy_dialog()
            try:
                self._make_init_file()
                if xbmcvfs.exists(self.ext_path):
                    try: xbmcvfs.rmdir(self.dest_path, True)
                    except: pass
                    shutil.copytree(self.ext_path, self.dest_path)
                    self._instances_rename(self.dest_path)
                    notification('[B]%s[/B] Scrapers Activated' % self.ext_addon.getAddonInfo('name'), 5000, self.ext_addon.getAddonInfo('icon'))
                else:
                    notification('Activation Failed. Please ensure you have Externals Scrapers Module Installed', 5000)
            except:
                notification('External Scrapers Activation Failed. Please See Log Error', 5000)
            hide_busy_dialog()
            return

    def set_import_addon(self):
        useable_addons = [
        ('plugin.video.tempest', 'plugin.video.tempest', 'from resources.lib.', ['resources', 'lib', 'sources']),
        ('plugin.video.Poached', 'script.module.eggscrapers', 'from resources.lib.', ['lib', 'eggscrapers']),
        ('plugin.video.exodusredux', 'script.module.openscrapers', 'from openscrapers.', ['lib', 'openscrapers', 'sources_openscrapers']),
        ('plugin.video.scrubsv2', 'script.module.scrubsv2', 'from resources.lib.', ['lib', 'resources', 'lib', 'sources']),
        ('plugin.video.13clowns', 'script.module.civitasscrapers', 'from resources.lib.', ['lib', 'civitasscrapers', 'sources_civitasscrapers'])
                        ]
        installed_addons = self.installed_addons()
        addons = [i for i in useable_addons if i[0] in installed_addons]
        addonList = [xbmcgui.ListItem(self.get_addon_information(i)[0].upper(), '[I]%s[/I]' % self.get_addon_information(i)[1], iconImage=self.get_addon_information(i)[2]) for i in addons]
        selected = dialog.select("Choose Add-on", addonList, useDetails=True)
        if selected == -1: return
        selected = useable_addons[selected]
        self.module_id = selected[1]
        self.replacement = selected[2]
        self.path = selected[3]
        self.ext_addon = xbmcaddon.Addon(self.module_id)
        self.sources_folder = self.module_id.split('.')[-1]
        self.dest_path = xbmc.translatePath(os.path.join(xbmcaddon.Addon("script.module.furkitscrapers").getAddonInfo('path'), 'lib', 'furkitscrapers', 'sources_%s' % self.sources_folder + '/'))
        if len(self.path) == 2: self.ext_path = xbmc.translatePath(os.path.join(self.ext_addon.getAddonInfo('path'), self.path[0], self.path[1] + '/'))
        elif len(self.path) == 3: self.ext_path = xbmc.translatePath(os.path.join(self.ext_addon.getAddonInfo('path'), self.path[0], self.path[1], self.path[2] + '/'))
        elif len(self.path) == 4: self.ext_path = xbmc.translatePath(os.path.join(self.ext_addon.getAddonInfo('path'), self.path[0], self.path[1], self.path[2], self.path[3] + '/'))
        else: self.ext_path = None

    def installed_addons(self):
        r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.GetAddons", "params": {"type":"xbmc.addon.video"}, "id": "1"}')
        r = unicode(r, 'utf-8', errors='ignore')
        r = (json.loads(r))['result']['addons']
        addons = [(str(i['addonid'])) for i in r]
        return addons

    def get_addon_information(self, item):
        name = xbmcaddon.Addon(id=item[0]).getAddonInfo('name')
        summary = xbmcaddon.Addon(id=item[0]).getAddonInfo('summary')
        icon = xbmcaddon.Addon(id=item[0]).getAddonInfo('icon')
        return (name, summary, icon)

    def _make_init_file(self):
        init_file = xbmcvfs.File(os.path.join(xbmcaddon.Addon("plugin.video.furkit").getAddonInfo('profile'), '__init__.py'), 'w')
        init_file.close()

    def _instances_rename(self, path):
        replacements = [['%s' % self.replacement, 'from furkitscrapers.']]
        directories, files = self._list_directory(path, absolute=True)
        for file in files:
            if file.endswith('.py'):
                self._replace_now(file, replacements)
        for directory in directories:
            self._instances_rename(directory)

    def _list_directory(self, path, absolute=False):
        directories, files = xbmcvfs.listdir(path)
        if absolute:
            for i in range(len(files)):
                files[i] = os.path.join(path, files[i])
            for i in range(len(directories)):
                directories[i] = os.path.join(path, directories[i])
        return directories, files

    def _replace_now(self, path, valueFrom, valueTo=None):
        data = self._read_now(path)
        if not isinstance(valueFrom, list):
            valueFrom = [[valueFrom, valueTo]]
        for replacement in valueFrom:
            data = data.replace(replacement[0], replacement[1])
        self._write_now(path, data)

    def _read_now(self, path):
        try:
            file = xbmcvfs.File(path)
            result = file.read()
            file.close()
            return result.decode('utf-8')
        except: return None

    def _write_now(self, path, value):
        file = xbmcvfs.File(path, 'w')
        result = file.write(str(value.encode('utf-8')))
        file.close()
        return result
