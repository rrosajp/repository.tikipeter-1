import xbmc, xbmcaddon, xbmcgui, xbmcplugin
import sys, os
from resources.lib.modules.workers import Thread
from resources.lib.modules.nav_utils import build_url, setView, get_meta
from resources.lib.modules.indicators_bookmarks import get_watched_status_tvshow
from resources.lib.modules.trakt import sync_watched_trakt_to_furkit
from resources.lib.indexers.tvshows import aired_episode_number_tvshow, build_episode
from resources.lib.modules import settings
try: from sqlite3 import dbapi2 as database
except ImportError: from pysqlite2 import dbapi2 as database
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.furkit'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__addon_profile__ = xbmc.translatePath(__addon__.getAddonInfo('profile'))
__handle__ = int(sys.argv[1])

PROGRESS_NEXT_EPISODE_VIEW = settings.SETTING_PROGRESS_NEXT_EPISODE_VIEW
NEXT_EPISODE_COLOUR = __addon__.getSetting(settings.SETTING_NEXT_EPISODE_COLOUR)
WATCHED_DB = os.path.join(__addon_profile__, "watched_status.db")
window = xbmcgui.Window(10000)
result = []

def build_next_episode():
    sync_watched_trakt_to_furkit()
    threads = []
    ep_list = []
    if settings.watched_indicators() in (1, 2):
        from resources.lib.modules.trakt import trakt_get_next_episodes
        info = trakt_get_next_episodes()
        for item in info: ep_list.append({"tmdb_id": item['show']['ids']['tmdb'], "season": item['season'], "episode": item['number'], "last_played": item['show']['last_watched_at']})
    else:
        settings.check_database(WATCHED_DB)
        dbcon = database.connect(WATCHED_DB)
        dbcur = dbcon.cursor()
        dbcur.execute('''SELECT media_id, season, episode, last_played FROM watched_status WHERE db_type=? GROUP BY media_id''', ('episode',))
        rows = dbcur.fetchall()
        for item in rows: ep_list.append({"tmdb_id": item[0], "current_season": int(item[1]), "current_episode": int(item[2]), "last_played": item[3]})
        ep_list = [x for x in ep_list if x['tmdb_id'] not in check_for_next_episode_excludes()]
    for item in ep_list: threads.append(Thread(process_eps, item))
    [i.start() for i in threads]
    [i.join() for i in threads]
    r = [i for i in result if i is not None]
    r = sort_next_eps(r)
    listitem = [i['listitem'] for i in r]
    xbmcplugin.addDirectoryItems(__handle__, listitem, len(listitem))
    xbmcplugin.setContent(__handle__, 'episodes')
    xbmcplugin.endOfDirectory(__handle__)
    setView(PROGRESS_NEXT_EPISODE_VIEW)

def process_eps(item):
    from datetime import datetime
    import time
    meta = get_meta('tvshow', 'tmdb_id', item['tmdb_id'])
    if get_watched_status_tvshow(item['tmdb_id'], aired_episode_number_tvshow(meta))[0] == 1: return
    try:
        if settings.watched_indicators() in (1, 2):
            resformat = "%Y-%m-%dT%H:%M:%S.%fZ"
            unwatched = False
            curr_last_played = item['last_played']
            season = item['season']
            episode = item['episode']
        else:
            resformat = "%Y-%m-%d %H:%M:%S"
            unwatched = True if item['current_episode'] == 0 else False
            curr_last_played = item['last_played']
            season_info = [i for i in meta['season_data'] if i['season_number'] == item['current_season']][0]
            season = item['current_season'] if item['current_episode'] < season_info['episode_count'] else season_info['season_number'] + 1
            episode = item['current_episode'] + 1 if item['current_episode'] < season_info['episode_count'] else 1
        try: datetime_object = datetime.strptime(curr_last_played, resformat)
        except TypeError: datetime_object = datetime(*(time.strptime(curr_last_played, resformat)[0:6]))
        result.append(build_episode({"tmdb_id": item['tmdb_id'], "season": season, "episode": episode, "meta": meta, "curr_last_played_parsed": datetime_object, "unwatched": unwatched, "action": "next_episode"}))
    except: pass

def sort_next_eps(result):
    if settings.nextep_sortorder() == 'Recently Watched':
        return sorted(result, key=lambda i: i['curr_last_played_parsed'], reverse=True)
    return sorted(result, key=lambda i: i['first_aired'], reverse=True)

def add_next_episode_unwatched():
    from urlparse import parse_qsl
    from resources.lib.modules.nav_utils import notification
    from resources.lib.modules.indicators_bookmarks import mark_as_watched_unwatched
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    if params.get('action') == 'add': action, line1 = 'mark_as_watched', '%s Added to Furk It Next Episode' % params.get('title')
    else: action, line1 = 'mark_as_unwatched', '%s Removed from Furk It Next Episode' % params.get('title')
    mark_as_watched_unwatched('episode', params.get('tmdb_id'), action, season=1, episode=0)
    notification(line1, time=2000)

def add_to_remove_from_next_episode_excludes():
    from urlparse import parse_qsl
    from resources.lib.modules.nav_utils import notification
    settings.check_database(WATCHED_DB)
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    action = params.get('action')
    media_id = str(params.get('media_id'))
    title = str(params.get('title'))
    dbcon = database.connect(WATCHED_DB)
    if action == 'add':
        dbcon.execute("INSERT INTO exclude_from_next_episode VALUES (?, ?)", (media_id, title))
        line1 = '[B]{}[/B] excluded from Furk It Next Episode'.format(title.upper())
    elif action == 'remove':
        dbcon.execute("DELETE FROM exclude_from_next_episode where media_id=?", (media_id,))
        line1 = '[B]{}[/B] included in Furk It Next Episode'.format(title.upper())
    dbcon.commit()
    dbcon.close()
    notification('{}'.format(line1), time=5000)
    xbmc.executebuiltin("Container.Refresh")

def check_for_next_episode_excludes():
    from urlparse import parse_qsl
    from resources.lib.modules.nav_utils import notification
    settings.check_database(WATCHED_DB)
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    dbcon = database.connect(WATCHED_DB)
    dbcur = dbcon.cursor()
    dbcur.execute('''SELECT media_id FROM exclude_from_next_episode''')
    row = dbcur.fetchall()
    dbcon.close()
    return [str(i[0]) for i in row]

def build_next_episode_manager():
    import json
    from urlparse import parse_qsl
    from resources.lib.indexers.tvshows import aired_episode_number_tvshow
    from resources.lib.modules.nav_utils import get_meta, add_dir
    from resources.lib.modules.indicators_bookmarks import get_watched_status_tvshow
    sync_watched_trakt_to_furkit()
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    VIEW_NEM = __addon__.getSetting(settings.SETTING_MAIN_VIEW)
    xbmcplugin.setContent(__handle__, 'tvshows')
    sorted_list = []
    if params.get('action') == 'manage_in_progress':
        if settings.watched_indicators() in (1, 2):
            from resources.lib.modules.trakt import trakt_get_next_episodes
            tmdb_list, exclude_list = trakt_get_next_episodes(include_hidden=True)
            heading = 'Select item below to Hide/Unhide from Trakt Progress:'
        else:
            settings.check_database(WATCHED_DB)
            dbcon = database.connect(WATCHED_DB)
            dbcur = dbcon.cursor()
            dbcur.execute('''SELECT media_id FROM watched_status WHERE db_type=? GROUP BY media_id''', ('episode',))
            rows = dbcur.fetchall()
            tmdb_list = [row[0] for row in rows]
            exclude_list = check_for_next_episode_excludes()
            heading = 'Select item below to Include/Exclude in Furk It Next Episode:'
        add_dir({'mode': 'nill'}, '[I][COLOR=grey][B]INFO:[/B][/COLOR] [COLOR=grey2]%s[/COLOR][/I]' % heading, iconImage='settings.png')
        use_dialog = True
        for tmdb_id in tmdb_list:
            try:
                cm = []
                meta = get_meta('tvshow', 'tmdb_id', tmdb_id)
                rootname = meta['title'] + " (" + str(meta['year']) + ")"
                meta['rootname'] = rootname
                meta_json = json.dumps(meta)
                (playcount, overlay) = get_watched_status_tvshow(meta['tmdb_id'], aired_episode_number_tvshow(meta))
                if settings.watched_indicators() in (1, 2):
                    action, display = 'unhide' if str(meta['tmdb_id']) in exclude_list else 'hide', '[COLOR=red][EXCLUDED][/COLOR] %s' % meta['title'] if str(meta['tmdb_id']) in exclude_list else '[COLOR=green][INCLUDED][/COLOR] %s' % meta['title']
                    url_params = {"mode": "hide_unhide_trakt_items", "action": action, "media_type": "shows", "media_id": meta['tmdb_id'], "section": "progress_watched"}
                else:
                    action, display = 'remove' if str(meta['tmdb_id']) in exclude_list else 'add', '[COLOR=red][EXCLUDED][/COLOR] %s' % meta['title'] if str(meta['tmdb_id']) in exclude_list else '[COLOR=green][INCLUDED][/COLOR] %s' % meta['title']
                    url_params = {'mode': 'add_to_remove_from_next_episode_excludes', 'action': action, 'title': meta['title'], 'media_id': meta['tmdb_id']}
                url = build_url(url_params)
                browse_url = build_url({'mode': 'build_season_list', 'meta': meta_json})
                cm.append(("Browse '%s'" % meta['title'],'XBMC.Container.Update(%s)' % browse_url))
                listitem = xbmcgui.ListItem(display)
                listitem.addContextMenuItems(cm, replaceItems=False)
                listitem.setArt({'poster': meta['poster'], 'fanart': meta['fanart']})
                listitem.setCast(meta['cast'])
                listitem.setInfo(
                    'video', {
                        'title': meta['title'], 'size': '0', 'duration': meta['duration'],
                        'plot': meta['plot'], 'rating': meta['rating'], 'premiered': meta['premiered'],
                        'studio': meta['studio'],'year': meta['year'],
                        'genre': meta['genre'],'imdbnumber': meta['imdb_id'], 'votes': meta['votes'],
                        'playcount': playcount, 'overlay': overlay})
                sorted_list.append({'display': display, 'listing': (url, listitem, True)})
            except:
                from resources.lib.modules.nav_utils import notification
                notification('No TV Shows Present', time=5000)
                pass
        sorted_items = sorted(sorted_list, key=lambda k: k['display'])
        xbmcplugin.addDirectoryItems(__handle__, [i['listing'] for i in sorted_items], len(sorted_items))
    elif params.get('action') == 'manage_unwatched':
        settings.check_database(WATCHED_DB)
        dbcon = database.connect(WATCHED_DB)
        dbcur = dbcon.cursor()
        dbcur.execute('''SELECT media_id FROM watched_status WHERE episode = ?''', (0,))
        rows = dbcur.fetchall()
        tmdb_list = [row[0] for row in rows]
        sorted_list = []
        if tmdb_list:
            add_dir({'mode': 'nill'}, '[B]INFO:[/B] Select item below to remove from Furk It Next Episode:', iconImage='settings.png')
            for tmdb_id in tmdb_list:
                cm = []
                meta = get_meta('tvshow', 'tmdb_id', tmdb_id)
                rootname = meta['title'] + " (" + str(meta['year']) + ")"
                meta['rootname'] = rootname
                meta_json = json.dumps(meta)
                display = '[COLOR=%s][UNWATCHED][/COLOR] %s' % (NEXT_EPISODE_COLOUR, meta['title'])
                url_params = {'mode': 'add_next_episode_unwatched', 'action': 'remove', 'title': meta['title'],
                            'tmdb_id': meta['tmdb_id'], 'tvdb_id': meta['tvdb_id'], 'imdb_id': meta['imdb_id']}
                url = build_url(url_params)
                browse_url = build_url({'mode': 'build_season_list', 'meta': meta_json})
                cm.append(("Browse '%s'" % meta['title'],'XBMC.Container.Update(%s)' \
                    % browse_url))
                listitem = xbmcgui.ListItem(display)
                listitem.addContextMenuItems(cm, replaceItems=False)
                listitem.setArt({'poster': meta['poster'], 'fanart': meta['fanart']})
                listitem.setCast(meta['cast'])
                listitem.setInfo(
                    'video', {
                        'title': meta['title'], 'size': '0', 'duration': meta['duration'],
                        'plot': meta['plot'], 'rating': meta['rating'], 'premiered': meta['premiered'],
                        'studio': meta['studio'],'year': meta['year'],
                        'genre': meta['genre'],'imdbnumber': meta['imdb_id'], 'votes': meta['votes']})
                sorted_list.append({'display': display, 'listing': (url, listitem, True)})
            sorted_items = sorted(sorted_list, key=lambda k: k['display'])
            xbmcplugin.addDirectoryItems(__handle__, [i['listing'] for i in sorted_items], len(sorted_items))
        else:
            from resources.lib.modules.nav_utils import notification
            notification('No Unwatched Shows Present', time=5000)
            pass
    xbmcplugin.endOfDirectory(__handle__)
    setView(VIEW_NEM)

def next_episode_unwatched_highlight_choice():
    from resources.lib.modules.utils import color_chooser
    dialog = 'Please choose Color for Unwatched Highlight...'
    chosen_color = color_chooser(dialog)
    if not chosen_color: return
    __addon__.setSetting(settings.SETTING_NEXT_EPISODE_COLOUR, chosen_color)
    xbmc.executebuiltin("Container.Refresh")

def next_episode_function_choice():
    from resources.lib.modules.utils import selection_dialog
    from resources.lib.modules.nav_utils import toggle_setting
    sortorder_toggle = 'Airdate' if __addon__.getSetting('nextep.sortorder') == 'Recently Watched' else 'Recently Watched'
    listing = [('Manage In Progress Shows', 'manage_in_progress'), ('Change Sort Order to [B]%s[/B]' % sortorder_toggle, 'toggle_nextep_sortorder')]
    if settings.watched_indicators() == 0:
        listing += [('Manage Unwatched Shows', 'manage_unwatched'), ('Manage Unwatched Colour Highlights', 'highlight_choice')]
    chosen = selection_dialog([i[0] for i in listing], [i[1] for i in listing], "Choose Furk It Next Episode Property to Manage...")
    if not chosen: return
    if chosen in ('manage_in_progress', 'manage_unwatched'): url = 'Container.Update(plugin://plugin.video.furkit/?mode=%s&action=%s)' % ('build_next_episode_manager', chosen)
    elif chosen == 'highlight_choice': url = 'Container.Update(plugin://plugin.video.furkit/?mode=%s)' % 'next_episode_unwatched_highlight_choice'
    elif chosen == 'toggle_nextep_sortorder': url = 'Container.Refresh'; toggle_setting('nextep.sortorder', sortorder_toggle)
    xbmc.executebuiltin(url)

def next_episode_from_playback(meta, from_library=None):
    from resources.lib.modules.nav_utils import notification
    info = {}
    if settings.autoplay_next_prompt(from_library):
        max_playcount = settings.autoplay_next_number(from_library)
        try: playcount = int(window.getProperty('playcount'))
        except: playcount = 1
        if playcount == max_playcount:
            continue_playing = xbmcgui.Dialog().yesno('Furk It Next Episode', '[B]Are you still watching %s?[/B]' % meta['title'], '', '', 'Still Watching', 'Not Watching', 10000)
            if continue_playing == 0:
                playcount = 0
                window.clearProperty('playcount')
            else:
                notification('Furk It Next Episode Cancelled', 6000)
                window.clearProperty('playcount')
                return {'pass': 'pass'}
        playcount += 1
        window.setProperty('playcount', str(playcount))
    try:
        season_info = [i for i in meta['season_data'] if i['season_number'] == meta['season']]
        for item in season_info:
            season = meta['season'] if int(meta['episode']) < item['episode_count'] else meta['season'] + 1
            episode = meta['episode'] + 1 if meta['episode'] < item['episode_count'] else 1
        info.update({'season': season, 'episode': episode, 'url': build_next_episode_play(meta, season, episode, from_library)})
        return info
    except:
        window.clearProperty('playcount')
        notification('Error fetching Next Episode Info', 6000)
        return {'pass': 'pass'}

def build_next_episode_play(meta, season, episode, from_library=None):
    import json
    from resources.lib.modules.tmdb import tmdb_season_summary
    infoLabels = tmdb_season_summary(meta['tmdb_id'], season)
    ep_data = infoLabels['episodes']
    ep_data = [i for i in ep_data if int(i['season_number']) == int(season) and int(i['episode_number']) == int(episode)][0]
    play_name = meta['title'] + ' S%.2dE%.2d' % (int(season), int(episode))
    display_name = '%s - %dx%.2d' % (meta['title'], int(season), int(episode))
    meta.update({'vid_type': 'episode', 'rootname': display_name, 'plot': ep_data['overview']})
    meta_json = json.dumps(meta)
    url_params = {'mode': 'play_media', 'background': 'true', 'vid_type': 'episode',
    'query': play_name, 'tvshowtitle': meta['rootname'], 'season': season, 'episode': episode,
    'premiered': ep_data['air_date'], 'ep_name': ep_data['name'], 'meta': meta_json}
    if from_library: url_params.update({'library': 'true', 'plot': ep_data['overview']})
    return build_url(url_params)
