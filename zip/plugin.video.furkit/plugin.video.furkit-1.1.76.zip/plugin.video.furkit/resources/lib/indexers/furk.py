import xbmc, xbmcaddon, xbmcplugin, xbmcgui
import sys, os, json
import urllib
from urlparse import parse_qsl
from resources.lib.modules.nav_utils import build_url, setView
from resources.lib.modules.furk_api import FurkAPI
from resources.lib.modules.sources import Sources
from resources.lib.modules.utils import clean_file_name, to_utf8
from resources.lib.modules import settings
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.furkit'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__handle__ = int(sys.argv[1])
__url__ = sys.argv[0]
addon_dir = xbmc.translatePath(__addon__.getAddonInfo('path'))
icon_directory = settings.get_theme()
dialog = xbmcgui.Dialog()
window = xbmcgui.Window(10000)
default_furk_icon = os.path.join(icon_directory, 'furk.png')
fanart = os.path.join(addon_dir, 'fanart.jpg')

FURK_FILES_VIEW  = settings.SETTING_FURK_FILES_VIEW
MEDIA_RESULTS_VIEW = settings.SETTING_MEDIA_RESULTS_VIEW
PACK_RESULTS_VIEW = settings.SETTING_PACK_RESULTS_VIEW

Furk = FurkAPI()

def my_furk_files():
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    files = Furk.file_get_video() if params.get('db_type') == 'video' else Furk.file_get_audio()
    furk_file_browser(files, params, display_mode='file_browse')
    xbmcplugin.endOfDirectory(__handle__)
    setView(FURK_FILES_VIEW)

def search_furk():
    from resources.lib.modules.history import add_to_search_history
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    default = params.get('suggestion', '')
    search_title = clean_file_name(params.get('query')) if ('query' in params and params.get('query') != 'NA') else None
    if not search_title: search_title = dialog.input('Enter search Term', type=xbmcgui.INPUT_ALPHANUM, defaultt=default)
    if not search_title: return
    search_name = clean_file_name(urllib.unquote(search_title))
    search_method = 'search' if 'accurate_search' in params else 'direct_search'
    search_setting = 'furk_video_queries' if params.get('db_type') == 'video' else 'furk_audio_queries'
    list_type = 'video' if params.get('db_type') == 'video' else 'audio'
    add_to_search_history(search_name, search_setting)
    files = Furk.direct_search(search_name) if search_method == 'direct_search' else Furk.search(search_name)
    try: files = [i for i in files if i['is_ready'] == '1' and i['type'] == list_type]
    except: return dialog.ok('No results', 'No results')
    furk_file_browser(files, params)
    xbmcplugin.endOfDirectory(__handle__)
    setView(FURK_FILES_VIEW)

def furk_results(use_dialog, from_library):
    def _autoplay_file(item):
        if from_library: return _play_file(item)
        if item.get("local"):
            url = build_url({'mode': 'bookmark_choice', 'url': item['url_dl']})
        else:
            filtering_list = seas_ep_query_list(meta['season'], meta['episode']) if meta['vid_type'] == 'episode' else ''
            t_files = t_file_browser(item.get("id"), filtering_list)
            url = build_url({'mode': 'bookmark_choice', 'url': t_files[0]['url_dl']})
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % url)
    def _play_file(item):
        if item.get("local"):
            url = build_url({'mode': 'bookmark_choice', 'url': item['url_dl']})
        else:
            filtering_list = seas_ep_query_list(meta['season'], meta['episode']) if meta['vid_type'] == 'episode' else ''
            t_files = t_file_browser(item['id'], filtering_list, auto_play_setting)
            if not (settings.auto_play(auto_play_setting) or settings.auto_resolve(auto_play_setting)):
                display_list = []
                for item in t_files:
                    listitem = xbmcgui.ListItem(item['display_name'], '[I]%s[/I]' % clean_file_name(item['name']), iconImage=meta['poster'])
                    listitem.setProperty('url_dl', item['url_dl'])
                    display_list.append(listitem)
                chosen = dialog.select("Furk Results", display_list, useDetails=True)
                if chosen < 0: return
                url_dl = display_list[chosen].getProperty('url_dl')
            else: url_dl = t_files[0]['url_dl']
            url = build_url({'mode': 'bookmark_choice', 'url': url_dl})
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % url)
    def _check_universal(heading, meta):
        if settings.check_universal() and settings.universal_fallback():
            if settings.prompt_for_fallback() and not settings.auto_play() and not dialog.yesno("%s." % heading, "Do you want to Search Universal Scrapers?"): return
            meta_json = json.dumps(meta)
            if meta['vid_type'] == 'movie': url_params = {'mode': 'play_media', 'provider': 'universal', 'vid_type': 'movie', 'query': meta['rootname'], 'meta': meta_json}
            else: url_params = {'mode': 'play_media', 'provider': 'universal', 'vid_type': 'episode', 'query': meta['query'],
                'tvshowtitle': meta['tvshowtitle'], 'season': meta['season'], 'episode': meta['episode'], 'premiered': meta['premiered'],
                'ep_name': meta['ep_name'], 'meta': meta_json}
            if 'library' in params: url_params['library'] = 'True'
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % build_url(url_params))
            return
        else: dialog.ok('%s.' % heading, '%s.' % heading)
    from resources.lib.modules.nav_utils import get_meta
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    display_list = []
    auto_play_setting = 'library' if from_library == True else None
    meta = json.loads(params.get('meta')) if 'meta' in params else get_meta("movie" if params.get("vid_type") == "movie" else "tvshow", 'tmdb_id', params.get('tmdb_id'))
    display_name = clean_file_name(urllib.unquote(params.get('query'))) if params.get('vid_type') == 'movie' else '%s - %dx%.2d' % (meta.get('title', ''), int(params.get('season')) if 'season' in params else '', int(params.get('episode')) if 'episode' in params else '')
    if from_library: meta.update({'plot': params.get('plot', ''), 'from_library': 'true'})
    meta.update({'query': params.get('query'), 'vid_type': params.get('vid_type'), 'media_id': meta.get('tmdb_id', ''), 'rootname': display_name, 'tvshowtitle': meta.get('title', ''), 'season': int(params.get('season')) if 'season' in params else '', 'episode': int(params.get('episode')) if 'episode' in params else '', 'premiered': params.get('premiered', ''), 'ep_name': params.get('ep_name', '')})
    window.setProperty('furkit_media_meta', json.dumps(meta))
    results = Sources(use_dialog, from_library).get_sources(meta['vid_type'], meta.get('title', ''), meta.get('year', ''), meta['season'], meta['episode'])
    if meta['vid_type'] == 'episode' and 'background' in params:
        from resources.lib.modules.player import FurkitPlayer
        from resources.lib.modules.nav_utils import notification
        notification('%s %s S%02dE%02d' % ('Next Up Autoplay:', meta['title'], meta['season'], meta['episode']), 10000, meta['poster'])
        PLAYER = FurkitPlayer()
        while PLAYER.isPlaying(): xbmc.sleep(100)
    try:
        if not results: return _check_universal('No Furk Results', meta)
        if results[0].get('play_local', False) or results[0].get('autoplay', False): return _autoplay_file(results[0])
        display_list = []
        for count, item in enumerate(results, 1):
            mode = 'bookmark_choice' if item.get("local") else 'furk.media_tfile'
            play_url = item.get("url_dl") if item.get("local") else ''
            url = build_url({'mode': mode, 'id': item.get("id"), 'url': play_url})
            contextMenuItems = []
            display_name = item.get("display_name") if not use_dialog else item.get("display_name").replace('[B]', '').replace('[/B]', '').replace('[I]', '').replace('[/I]', '')
            display = '%02d | %s' % (count, display_name)
            listitem = xbmcgui.ListItem(display) if not use_dialog else xbmcgui.ListItem(display, '[I]%s[/I]' % clean_file_name(item['name']), iconImage=meta['poster'])
            if use_dialog: listitem.setProperty('item', json.dumps(item))
            if use_dialog: display_list.append(listitem)
            listitem.setArt({'poster': meta.get('poster', ''), 'thumb': meta.get('poster', ''), 'fanart': meta.get('fanart', '')})
            playback_params = {'mode': 'playback_menu', 'from_results': True}
            add_files_params = {'mode': 'furk.add_to_files', 'name': item.get("name"), 'item_id': item.get("id")}
            down_archive_params = {'mode': 'download_file', 'name': item.get("name"), 'url': item.get("url_dl"), 'db_type': 'archive', 'image': default_furk_icon}
            contextMenuItems.append(("Playback/Search Options",'XBMC.RunPlugin(%s)' % build_url(playback_params)))
            if not item.get("local"):
                contextMenuItems.append(("Add to My Files",'XBMC.RunPlugin(%s)'  % build_url(add_files_params)))
                contextMenuItems.append(("Download Archive",'XBMC.RunPlugin(%s)' % build_url(down_archive_params)))
            listitem.addContextMenuItems(contextMenuItems)
            if meta['vid_type'] == 'movie': listitem.setInfo('video', {'title': meta.get('title', ''), 'year': meta.get('year', ''), 'plot': meta.get('plot', '')})
            elif meta['vid_type'] == 'episode': listitem.setInfo('video', {'title': meta.get('rootname', ''), 'plot': meta.get('plot', '')})
            if not use_dialog: xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=True)
        if use_dialog:
            chosen = dialog.select("Furk Results", display_list, useDetails=True)
            if chosen < 0: return
            return _play_file(json.loads(display_list[chosen].getProperty('item')))
        xbmcplugin.endOfDirectory(__handle__)
        setView(MEDIA_RESULTS_VIEW)
    except: return _check_universal('Error Getting Furk Results', meta)

def furk_tfile_video():
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    t_files = [i for i in Furk.t_files(params.get('id')) if 'video' in i['ct'] and 'bitrate' in i]
    try:
        for count, item in enumerate(t_files, 1):
            contextMenuItems = []
            url_params = {'mode': 'media_play', 'url': item['url_dl'], 'rootname': 'nill'}
            url = build_url(url_params)
            name = clean_file_name(item['name']).upper()
            if 1200 < int(item['height']) > 2100: display_res = '2160p'
            elif 1000 < int(item['height']) < 1200: display_res = '1080p'
            elif 680 < int(item['height']) < 1000: display_res = 'HD'
            else: display_res = 'SD'
            display_name = '%02d | [B]%s[/B] | [B]%.2f GB[/B] | %smbps | [I]%s[/I]' % \
            (count, display_res, float(item['size'])/1073741824, str(round(float(item['bitrate'])/1000, 2)), name)
            listitem = xbmcgui.ListItem(display_name)
            down_file_params = {'mode': 'download_file', 'name': item['name'], 'url': item['url_dl'], 'db_type': 'file', 'image': default_furk_icon}
            contextMenuItems.append(("Download File",'XBMC.RunPlugin(%s)' % build_url(down_file_params)))
            listitem.addContextMenuItems(contextMenuItems)
            listitem.setThumbnailImage(default_furk_icon)
            listitem.setArt({'fanart': fanart})
            listitem.setInfo('video', {'title': display_name, 'size': int(item['size']), 'duration': item['length']})
            listitem.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=False)
        xbmcplugin.endOfDirectory(__handle__)
        setView(FURK_FILES_VIEW)
    except: pass

def furk_tfile_audio():
    window.clearProperty('furkit_t_files_json')
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    excludes = ['', 'cover', 'covers', 'scan', 'scans', 'playlists']
    t_files = Furk.t_files(params.get('id'))
    item_path_list = sorted(list(set([clean_file_name(i['path']) for i in t_files if clean_file_name(i['path']).lower() not in excludes])))
    if not item_path_list:
        if dialog.yesno("Furk It Music Player", 'Browse Songs or Play Full Album?', '', '', 'Play Now','Browse'):
            return browse_audio_album(t_files, params.get('name'))
        from resources.lib.modules.player import FurkitPlayer
        FurkitPlayer().playAudioAlbum(t_files, params.get('name'))
        return browse_audio_album(t_files, params.get('name'))
    for x in item_path_list:
        url_params = {'mode': 'furk.browse_audio_album', 'item_path': x}
        url = build_url(url_params)
        listitem = xbmcgui.ListItem(x.upper())
        listitem.setThumbnailImage(default_furk_icon)
        listitem.setArt({'fanart': fanart})
        xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=True)
    t_files_json = json.dumps(t_files)
    window.setProperty('furkit_t_files_json', str(t_files_json))
    xbmcplugin.endOfDirectory(__handle__)
    setView(FURK_FILES_VIEW)

def browse_audio_album(t_files=None, name=None):
    def build_list_object():
        contextMenuItems = []
        url_params = {'mode': 'media_play', 'url': item['url_dl'], 'rootname': 'nill'}
        url = build_url(url_params)
        track_name = clean_file_name(batch_replace(to_utf8(item['name']), formats)).upper()
        listitem = xbmcgui.ListItem(track_name)
        down_file_params = {'mode': 'download_file', 'name': item['name'], 'url': item['url_dl'], 'image': default_furk_icon, 'db_type': 'file'}
        contextMenuItems.append(("Download File",'XBMC.RunPlugin(%s)' % build_url(down_file_params)))
        listitem.addContextMenuItems(contextMenuItems)
        listitem.setThumbnailImage(default_furk_icon)
        listitem.setArt({'fanart': fanart})
        listitem.setInfo(type='music',infoLabels={'title': track_name, 'size': int(item['size']), 'album': item['path'], 'duration': item['length']})
        listitem.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=False)
    from resources.lib.modules.utils import batch_replace
    formats = ('.3gp', ''),('.aac', ''),('.flac', ''),('.m4a', ''),('.mp3', ''),('.ogg', ''),('.raw', ''),('.wav', ''),('.wma', ''),('.webm', ''),('.ra', ''),('.rm', '')
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    seperate = False
    if not t_files:
        seperate = True
        t_fs = window.getProperty('furkit_t_files_json')
        t_files = json.loads(t_fs)
    t_files = [i for i in t_files if 'audio' in i['ct']]
    if seperate:
        if dialog.yesno("Furk It Music Player", 'Browse Songs or Play Full Album?', '', '', 'Play Now','Browse'):
            for item in t_files:
                item_path = clean_file_name(item['path'])
                if item_path == params.get('item_path'):
                    build_list_object()
            xbmcplugin.endOfDirectory(__handle__)
            setView(FURK_FILES_VIEW)
        else:
            from resources.lib.modules.player import FurkitPlayer
            FurkitPlayer().playAudioAlbum(t_files, from_seperate=True)
    else:
        for item in t_files:
            build_list_object()
        xbmcplugin.endOfDirectory(__handle__)
        setView(FURK_FILES_VIEW)

def media_tfile():
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    meta = json.loads(window.getProperty('furkit_media_meta'))
    t_files = Furk.t_files(params.get('id'))
    t_files = [i for i in t_files if 'video' in i['ct'] and 'bitrate' in i]
    if settings.auto_resolve():
        try:
            name, url_dl, size = filter_furk_tlist(t_files, (None if meta['vid_type'] == 'movie' else seas_ep_query_list(meta['season'], meta['episode'])))
            url_params = {'mode': 'bookmark_choice', 'url': url_dl}
            url = build_url(url_params)
            return xbmc.executebuiltin('XBMC.RunPlugin(%s)' % url)
        except: return
    for count, item in enumerate(t_files, 1):
        try:
            cmenu = []
            url_params = {'mode': 'bookmark_choice', 'url': item['url_dl']}
            url = build_url(url_params)
            name = clean_file_name(item['name'])
            video_quality, video_type = get_release_quality(item['name'], item['url_dl'], t_file='yep')
            display_name = '%02d | [B]%s[/B] | [B]%s[/B] | [B]%.2f GB[/B] | [I]%s[/I]' % (count, video_quality, video_type, float(item['size'])/1073741824, name.upper())
            playback_params = {'mode': 'playback_menu', 'from_results': True}
            down_file_params = {'mode': 'download_file', 'name': item['name'], 'url': item['url_dl'], 'meta': json.dumps(meta)}
            cmenu.append(("Playback/Search Options",'XBMC.RunPlugin(%s)' % build_url(playback_params)))
            cmenu.append(("Download File",'XBMC.RunPlugin(%s)' % build_url(down_file_params)))
            listitem = xbmcgui.ListItem(display_name)
            listitem.setArt({'poster': meta.get('poster', ''), 'thumb': meta.get('poster', ''), 'fanart': meta.get('fanart', '')})
            listitem.addContextMenuItems(cmenu)
            if meta.get('vid_type') == 'movie': listitem.setInfo('video', {'title': meta.get('title', ''), 'year': meta.get('year', ''), 'plot': meta.get('plot', '')})
            else: listitem.setInfo('video', {'title': meta['rootname'], 'plot': meta.get('plot', '')})
            xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=True)
        except: pass
    xbmcplugin.endOfDirectory(__handle__)
    setView(PACK_RESULTS_VIEW)

def my_furk_audio_favourites():
    from resources.lib.modules.favourites import retrieve_favourites
    results = retrieve_favourites('', 'audio')
    for item in results:
        try:
            name = item.split('<>')[0]
            item_id = item.split('<>')[1]
            url_dl = item.split('<>')[2]
            size = item.split('<>')[3]
            display_size = str(round(float(size)/1048576000, 1))
            display = '[B]%sGB[/B] | [I]%s[/I]' % (display_size, name)
            contextMenuItems = []
            url_params = {'mode': 'furk.furk_tfile_audio', 'name': name, 'id': item_id}
            url = build_url(url_params)
            con_remove_favs = {'mode': 'remove_from_favourites', 'db_type': 'audio', 'tmdb_id': item}
            con_download_archive = {'mode': 'download_file', 'name': name, 'url': url_dl, 'image': default_furk_icon, 'db_type': 'archive'}
            contextMenuItems.append(("Remove from Furk It Favourites",'XBMC.RunPlugin(%s)' % build_url(con_remove_favs)))
            contextMenuItems.append(("Download Archive",'XBMC.RunPlugin(%s)' % build_url(con_download_archive)))
            listitem = xbmcgui.ListItem(display)
            listitem.addContextMenuItems(contextMenuItems)
            listitem.setThumbnailImage(default_furk_icon)
            listitem.setArt({'fanart': fanart})
            listitem.setInfo(type='video', infoLabels={'title': display, 'size': int(size)})
            xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=True)
        except: pass
    xbmcplugin.endOfDirectory(__handle__)
    setView(FURK_FILES_VIEW)

def furk_file_browser(files, params, display_mode='search'):
    files_num = 'files_num_video' if params.get('db_type') == 'video' else 'files_num_audio'
    list_type = 'video' if params.get('db_type') == 'video' else 'music'
    mode = 'furk.furk_tfile_video' if params.get('db_type') == 'video' else 'furk.furk_tfile_audio'
    for count, item in enumerate(files, 1):
        try:
            name = clean_file_name(item['name']).upper()
            item_id = item['id']
            url_dl = item['url_dl']
            size = item['size']
            is_protected = item.get('is_protected')
            display_size = str(round(float(size)/1048576000, 1))
            info_unprotected = '[B] %s GB | %s files | [/B]' % (display_size, item[files_num])
            info_protected = '[COLOR=green]%s[/COLOR]' % info_unprotected
            info_search = '%02d | [B]%s GB[/B] | [B]%s files[/B] |' % (count, display_size, item[files_num])
            info = info_search if display_mode == 'search' else info_protected if is_protected == '1' else info_unprotected if is_protected == '0' else None
            display = '%s [I] %s [/I]' % (info, name)
            url_params = {'mode': mode, 'name': name, 'id': item_id}
            url = build_url(url_params)
            contextMenuItems = []
            con_add_favs = {'mode': 'add_to_favourites_audio', 'name': name, '_id': item_id, 'url_dl': url_dl, 'size': size}
            con_download_archive = {'mode': 'download_file', 'name': item.get("name"), 'url': url_dl, 'db_type': 'archive', 'image': default_furk_icon}
            con_remove_files = {'mode': 'furk.remove_from_files', 'name': name, 'item_id': item_id}
            con_protect_files = {'mode': 'furk.myfiles_protect_unprotect', 'action': 'protect', 'name': name, 'item_id': item_id}
            con_unprotect_files = {'mode': 'furk.myfiles_protect_unprotect', 'action': 'unprotect', 'name': name, 'item_id': item_id}
            con_add_to_files = {'mode': 'furk.add_to_files', 'name': name, 'item_id': item_id}
            if params.get('db_type') == 'audio': contextMenuItems.append(("Add to Furk It Favourites",'XBMC.RunPlugin(%s)' % build_url(con_add_favs)))
            if display_mode == 'search': contextMenuItems.append(("Add to My Files",'XBMC.RunPlugin(%s)' % build_url(con_add_to_files)))
            contextMenuItems.append(("Download Archive",'XBMC.RunPlugin(%s)' % build_url(con_download_archive)))
            contextMenuItems.append(("Remove from My Files",'XBMC.RunPlugin(%s)' % build_url(con_remove_files)))
            if is_protected == '0': contextMenuItems.append(("Protect File",'XBMC.RunPlugin(%s)' % build_url(con_protect_files)))
            if is_protected == '1': contextMenuItems.append(("Unprotect File",'XBMC.RunPlugin(%s)' % build_url(con_unprotect_files)))
            listitem = xbmcgui.ListItem(display)
            listitem.addContextMenuItems(contextMenuItems)
            listitem.setArt({'thumb': default_furk_icon, 'fanart': fanart})
            listitem.setInfo(type=list_type, infoLabels={'title': display, 'size': int(size)})
            xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=True)
        except: pass

def t_file_browser(item_id, filtering_list=None, source=None):
    origin = settings.define_origin(source)
    t_files = [i for i in Furk.t_files(item_id) if 'video' in i['ct']]
    if settings.auto_play(origin) or settings.auto_resolve(origin):
        name, url_dl, size = filter_furk_tlist(t_files, filtering_list)
        return [{'name': name, 'url_dl': url_dl, 'size': size}]
    return [{'name': i['name'].upper(), 'display_name': '[B]%02d | %s | %s | %.2f GB' % (c, get_release_quality(i['name'], i['url_dl'], t_file='yep')[0], get_release_quality(i['name'], i['url_dl'], t_file='yep')[1], float(i['size'])/1073741824), 'url_dl': i['url_dl'], 'size': i['size']} for c, i in enumerate(t_files, 1)]

def filter_furk_tlist(t_files, filtering_list=None):
    t_files = [i for i in t_files if 'video' in i['ct'] and any(x in i['name'].lower() for x in filtering_list) and not any(x in i['name'].lower() for x in ['furk320', 'sample'])][0] if filtering_list else [i for i in t_files if 'is_largest' in i][0]
    return t_files['name'], t_files['url_dl'], t_files['size']

def seas_ep_query_list(season, episode):
    return ['s%02de%02d' % (int(season), int(episode)), '%dx%02d' % (int(season), int(episode)),
            '%02dx%02d' % (int(season), int(episode))]

def get_release_quality(release_name, release_link=None, t_file=None):
    import re
    if release_name is None: return
    try: release_name = release_name
    except: pass
    try:
        vid_quality = None
        release_name = release_name.upper()
        fmt = re.sub('(.+)(\.|\(|\[|\s)(\d{4}|S\d*E\d*|S\d*)(\.|\)|\]|\s)', '', release_name)
        fmt = re.split('\.|\(|\)|\[|\]|\s|-', fmt)
        fmt = [i.lower() for i in fmt]
        if any(i in ['dvdscr', 'r5', 'r6'] for i in fmt): vid_quality = 'SCR'
        elif any(i in ['camrip', 'tsrip', 'hdcam', 'hd-cam', 'hdts', 'dvdcam', 'dvdts', 'cam', 'telesync', 'ts'] for i in fmt): vid_quality = 'CAM'
        elif any(i in ['tc', 'hdtc', 'telecine', 'tc720p', 'tc720', 'hdtc'] for i in fmt): vid_quality = 'TELE'
        elif '2160p' in fmt: vid_quality = '2160p'
        elif '1080p' in fmt: vid_quality = '1080p'
        elif '720p' in fmt: vid_quality = '720p'
        elif 'brrip' in fmt: vid_quality = '720p'
        if not vid_quality:
            if release_link:
                release_link = release_link.lower()
                try: release_link = release_link
                except: pass
                if any(i in ['dvdscr', 'r5', 'r6'] for i in release_link): vid_quality = 'SCR'
                elif any(i in ['camrip', 'tsrip', 'hdcam', 'hdts', 'dvdcam', 'dvdts', 'cam', 'telesync', 'ts'] for i in release_link): vid_quality = 'CAM'
                elif any(i in ['tc', 'hdtc', 'telecine', 'tc720p', 'tc720', 'hdtc'] for i in release_link): vid_quality = 'TELE'
                elif '2160' in release_link: vid_quality = '4K'
                elif '1080' in release_link: vid_quality = '1080p'
                elif '720' in release_link: vid_quality = '720p'
                elif '.hd' in release_link: vid_quality = 'SD'
                else: vid_quality = 'SD'
            else: vid_quality = 'SD'
        if not t_file:
            return vid_quality
        else:
            vid_type = 'H264'
            if any(i in ['hevc', 'h265', 'x265'] for i in fmt): vid_type = 'HEVC'
            return vid_quality, vid_type
    except:
        if not t_file:
            return 'SD'
        else:
            return 'SD', 'x264'

def add_to_files(name='', item_id=''):
    from resources.lib.modules.nav_utils import notification
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    name = params.get('name') if 'name' in params else name
    item_id = params.get('item_id') if 'item_id' in params else item_id
    resp = dialog.yesno('Are you sure?', "Add\n[B]%s[/B]\nto My Furk Files?" % name)
    if resp:
        response = Furk.file_link(item_id)
        if response['status'] == 'ok':
            notification('{}'.format('Item added to My Furk Files'), 3500)
        else:
            notification('{}'.format('Error - [B][I]%s[/I][/B]' % response['status']), 3500)
        return (None, None)
        dialog.close()
    else: return

def remove_from_files(name='', item_id=''):
    from resources.lib.modules.nav_utils import notification
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    name = params.get('name')
    item_id = params.get('item_id')
    resp = dialog.yesno('Are you sure?', "Remove [B][I]%s[/I][/B]  from My Furk Files?" % name)
    if resp:
        response = Furk.file_unlink(item_id)
        if response['status'] == 'ok':
            notification('{}'.format('Item removed from My Furk Files'), 3500)
            xbmc.executebuiltin("Container.Refresh")
        else:
            notification('{}'.format('Error - [B][I]%s[/I][/B]' % response['status']), 3500)
        return (None, None)
        dialog.close()
    else: return

def myfiles_protect_unprotect(name='', item_id='', action=''):
    from resources.lib.modules.nav_utils import notification
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    name = params.get('name') if 'name' in params else name
    item_id = params.get('item_id') if 'item_id' in params else item_id
    action = params.get('action') if 'action' in params else action
    is_protected = '1' if action == 'protect' else '0'
    line1 = 'File added to Protected List' if action == 'protect' else 'File removed from Protected List'
    try:
        response = Furk.file_protect(item_id, is_protected)
        if response['status'] == 'ok':
            xbmc.executebuiltin("Container.Refresh")
            notification(line1, time=7000)
    except: return

def account_info():
    from resources.lib.modules.utils import regex_from_to
    accinfo = Furk.account_info()
    account_type = accinfo['premium']['name']
    month_time_left = float(accinfo['premium']['bw_month_time_left'])/60/60/24
    try: total_time_left = float(accinfo['premium']['time_left'])/60/60/24
    except: total_time_left = ''
    try: bw_used_month = float(accinfo['premium']['bw_used_month'])/1073741824
    except: bw_used_month = ''
    try: bw_limit_month = float(accinfo['premium']['bw_limit_month'])/1073741824
    except: bw_limit_month = ''
    try: is_not_last_month = accinfo['premium']['is_not_last_month']
    except: is_not_last_month = ''
    try: renewal_date = accinfo['premium']['to_dt']
    except: renewal_date = ''
    try: rem_bw_limit_month = bw_limit_month - bw_used_month
    except: rem_bw_limit_month = ''
    if account_type == 'LIFETIME':
        remaining_text = 'You have [B]{0}[/B] days left in your current month. You have used [B]{1}GB[/B] of your data allowance, and have [B]{2}GB[/B] remaining.'.format(round(month_time_left, 2), round(bw_used_month, 2), round(rem_bw_limit_month, 2))
        return dialog.ok('Account Type: {0} - {1}GB per month '.format(account_type, round(bw_limit_month, 0)),remaining_text)
    if is_not_last_month == '1':
        remaining_text = 'You have [B]{0}[/B] days left in your current subscription. Your subscription resets on [B]{1}[/B]'.format(round(total_time_left, 2), renewal_date)
    else: 
        remaining_text = 'You will need to [B]renew[/B] your subscription in [B]{0}[/B] days. Date of renewal is [B]{1}[/B]'.format(round(total_time_left, 2), renewal_date)
    return dialog.ok('Account Type: {0} - {1}GB per month '.format(account_type, round(bw_limit_month, 0)),
        'You have [B]{0}[/B] days remaining for your current month, and have [B]{1}GB[/B] of data remaining. {2}.'.format(round(month_time_left, 2), round(rem_bw_limit_month, 2), remaining_text))

