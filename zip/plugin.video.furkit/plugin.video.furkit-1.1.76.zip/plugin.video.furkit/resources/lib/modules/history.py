# -*- coding: utf-8 -*-
import xbmcaddon
# from resources.lib.modules.utils import logger

__addon__ = xbmcaddon.Addon(id='plugin.video.furkit')

def add_to_search_history(search_name, search_list):
    try:
        recent = __addon__.getSetting(search_list).split('|')
        if search_name in recent: recent.remove(search_name)
        recent.insert(0, search_name)
        recent = recent[:10]
        __addon__.setSetting(id=search_list, value='|'.join(recent))
    except: return

def remove_from_history():
    import xbmc
    import sys
    from urlparse import parse_qsl
    from resources.lib.modules.nav_utils import notification
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    try:
        sl = __addon__.getSetting(params['setting_id']).split('|')
        sl.remove(params.get('name'))
        __addon__.setSetting(id=params['setting_id'], value='|'.join(sl))
        notification('[B]%s[/B] Removed from History' % params.get('name').upper(), 3500)
        xbmc.executebuiltin('Container.Refresh')
    except: return

def clear_search_history():
    import xbmcgui
    from resources.lib.modules.nav_utils import notification
    dialog = xbmcgui.Dialog()
    try:
        choice_list = [('Delete Movie Search History', 'movie_queries', 'Movie'),
                        ('Delete TV Show Search History', 'tvshow_queries', 'TV Show'),
                        ('Delete Furk Video Search History', 'furk_video_queries', 'Furk Video'), 
                        ('Delete Furk Audio Search History', 'furk_audio_queries', 'Furk Audio')]
        selection = dialog.select('Choose Search History to Delete', [i[0] for i in choice_list])
        if selection < 0: return
        setting = choice_list[selection][1]
        __addon__.setSetting(setting, "")
        notification("%s Search History Removed" % choice_list[selection][2], 3500)
    except: return

def search_history():
    import xbmc, xbmcgui, xbmcplugin
    import sys, os
    from urlparse import parse_qsl
    import urllib
    from resources.lib.modules.nav_utils import build_url, setView
    from resources.lib.modules.settings import get_theme, SETTING_MAIN_VIEW
    try:
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        (search_setting, display_title) = ('movie_queries', 'MOVIE') if params['action'] == 'movie' else ('tvshow_queries', 'TVSHOW') if params['action'] == 'tvshow' \
            else ('furk_video_queries', 'FURK VIDEO') if params['action'] == 'video' else ('furk_audio_queries', 'FURK AUDIO') if params['action'] == 'audio' else ''
        history = __addon__.getSetting(search_setting).split('|')
        if '' in history: history.remove('')
        for h in history:
            contextMenuItems = []
            name = urllib.unquote(h)
            url_params = {'mode': 'build_movie_list', 'action': 'tmdb_movies_search', 'query': name} if params['action'] == 'movie' \
                else {'mode': 'build_tvshow_list', 'action': 'tmdb_tv_search', 'query': name} if params['action'] == 'tvshow' \
                else {'mode': 'furk.search_furk', 'db_type': 'video', 'query': name} if params['action'] == 'video' \
                else {'mode': 'furk.search_furk', 'db_type': 'audio', 'music': True, 'query': name} if params['action'] == 'audio' \
                else ''
            display = '[B]%s SEARCH : [/B]' % display_title + name 
            url = build_url(url_params)
            contextMenuItems.append(("Remove from history",'XBMC.RunPlugin(%s?mode=%s&setting_id=%s&name=%s)' \
                % (sys.argv[0], 'remove_from_history', search_setting, name)))
            listitem = xbmcgui.ListItem(display, iconImage=os.path.join(get_theme(), 'search.png'))
            listitem.setArt({'fanart': os.path.join(xbmc.translatePath(__addon__.getAddonInfo('path')), 'fanart.jpg')})
            listitem.setInfo(type='video', infoLabels={'Title': name})
            listitem.addContextMenuItems(contextMenuItems)
            xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, isFolder=True)
        setView(__addon__.getSetting(SETTING_MAIN_VIEW))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    except: pass
    