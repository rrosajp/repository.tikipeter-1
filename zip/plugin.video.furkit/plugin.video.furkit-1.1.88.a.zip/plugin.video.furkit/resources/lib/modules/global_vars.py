

local_results = []
furk_results = []
easynews_results = []
universal_results = []
