# -*- coding: utf-8 -*-

import xbmc, xbmcaddon
import universalscrapers
from resources.lib.modules.nav_utils import build_url, hide_busy_dialog, show_busy_dialog, notification
# from resources.lib.modules.utils import logger

__addon__ = xbmcaddon.Addon(id='plugin.video.furkit')

class UniversalScrapersSource:

    def __init__(self):
        self.provider = 'universal'
        self.sources = []

    def results(self, info):
        hide_busy_dialog()
        self.info = info
        self.db_type = self.info.get("db_type")
        self.title = self.info.get("title")
        self.year = self.info.get("year")
        self.premiered = self.info["premiered"].split('-')[0] if "premiered" in self.info else ''
        self.season = self.info.get("season", "")
        self.episode = self.info.get("episode", "")
        self.imdb_id = self.info.get("imdb_id", "")
        self.tvdb_id = self.info.get("tvdb_id", "")
        self.ep_name = self.info.get("ep_name", "0")
        self.timeout = int(__addon__.getSetting('universal.timeout'))
        self.allow_debrid = True if __addon__.getSetting('universal.debrid') == 'true' else False
        if self.db_type == 'movie':
            link = universalscrapers.scrape_movie_with_dialog(self.title, self.year, self.imdb_id, timeout=self.timeout, enable_debrid=self.allow_debrid)
        else:
            link = universalscrapers.scrape_episode_with_dialog(self.title, self.year, self.premiered, self.season, self.episode, self.imdb_id, self.tvdb_id, timeout=self.timeout, enable_debrid=self.allow_debrid)
        if not link: return
        return link

    def resolve_universal(self, link):
        show_busy_dialog()
        try:
            url = link.get("url")
            if not link.get("direct"):
                import resolveurl
                hmf = resolveurl.HostedMediaFile(url=url, include_disabled=True, include_universal=True)
                if hmf.valid_url() == True: url = hmf.resolve()
                if url == False or url == None: raise Exception()
            play_url = build_url({'mode': 'bookmark_choice', 'url': url})
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % play_url)
        except:
            hide_busy_dialog()
            notification('Error playing back file. Please rescrape sources and try again.', 6500)


