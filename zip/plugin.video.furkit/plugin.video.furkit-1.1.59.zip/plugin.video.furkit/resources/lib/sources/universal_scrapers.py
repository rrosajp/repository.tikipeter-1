# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import json
import urllib
import universalscrapers
import sys
import random
import time
from operator import itemgetter
from resources.lib.sources.local_library import LocalLibrarySource
from resources.lib.modules.nav_utils import hide_busy_dialog, build_url, setView
from resources.lib.modules import global_vars as g
from resources.lib.modules import workers
from resources.lib.modules import settings
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.furkit'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__handle__ = int(sys.argv[1])
dialog = xbmcgui.Dialog()
window = xbmcgui.Window(10000)
MEDIA_RESULTS_VIEW = __addon__.getSetting(settings.SETTING_MEDIA_RESULTS_VIEW)

class UniversalScrapersSource:

    def __init__(self, use_dialog=False, from_library=False):
        self.origin = 'context' if from_library else None
        self.autoplay = settings.auto_play(self.origin)
        self.prefer_hevc = settings.prefer_hevc(self.origin)
        self.use_dialog = True if use_dialog else False
        self.from_library = True if from_library else False
        self.sources = []

    def results(self, meta, info):
        window.clearProperty('furkit_media_meta')
        hide_busy_dialog()
        self.info = json.loads(info)
        self.db_type = self.info.get("db_type", "")
        self.title = self.info.get("title", "")
        self.year = self.info.get("year", "")
        self.premiered = self.info["premiered"].split('-')[0] if "premiered" in self.info else ''
        self.season = self.info.get("season", "")
        self.episode = self.info.get("episode", "")
        self.imdb_id = self.info.get("imdb_id", "")
        self.tvdb_id = self.info.get("tvdb_id", "")
        self.ep_name = self.info.get("ep_name", "0")
        self._update_meta(meta)
        if (settings.check_library() or self.autoplay):
            if self._check_library_before_search():
                g.universal_results.append(g.local_results[0])
                xbmc.executebuiltin('XBMC.RunPlugin(%s)' % build_url({'mode': 'resolve_universal', 'info': json.dumps(g.universal_results[0])}))
                return
            else: pass
        else: LocalLibrarySource().results(self.info)
        items = self._get_scrapers()
        results = self._filter_results(items)
        try:
            if results:
                for i in results:
                    g.universal_results.append({'name': i.get("source"),
                        'display_name': i.get("display_name"),
                        'quality': i.get("quality"),
                        'size': 0,
                        'url_dl': i.get("url"),
                        'id': None,
                        'local': i.get("local", False),
                        'direct': i.get("direct")})
                if self.autoplay: return self.auto_play_universal()
                else: return self.display_universal_results()
        except: pass

    def _get_scrapers(self):
        progressDialog = xbmcgui.DialogProgress()
        progressDialog.create('Furk It Universal Sources', '')
        progressDialog.update(0, 'Preparing Universal Sources...')
        self.timeout = int(__addon__.getSetting('universal.timeout'))
        self.allow_debrid = True if __addon__.getSetting('universal.debrid') == 'true' else False
        if self.db_type == 'movie':
            links_scraper = universalscrapers.scrape_movie(self.title, self.year, self.imdb_id, timeout=self.timeout, enable_debrid=self.allow_debrid)
        else:
            links_scraper = universalscrapers.scrape_episode(self.title, self.year, self.premiered, self.season, self.episode, self.imdb_id, self.tvdb_id, timeout=self.timeout, enable_debrid=self.allow_debrid)
        thread = workers.Thread(self._get_sources, links_scraper, progressDialog)
        thread.start()
        for i in range(0, self.timeout * 2):
            try:
                if xbmc.abortRequested: return sys.exit()
                try:
                    if progressDialog.iscanceled():
                        progressDialog.close()
                        break
                except: pass
                if not thread.is_alive(): break
                time.sleep(0.5)
            except: pass
        try: progressDialog.close()
        except: pass
        return self.sources

    def _get_sources(self, links_scraper, progressDialog):
        num_scrapers = len(universalscrapers.relevant_scrapers())
        count = 0
        string1 = "Time Elapsed %s"
        string2 = "%s seconds"
        string3 = "Remaining providers: %s"
        countLOCAL = count1080p = count720p = countSD = 0
        seperator = "[B][COLOR=%s]%s[/COLOR]  |  [/B]"
        if g.local_results:
            [i.update( {"url":i['url_dl']}) for i in g.local_results]
            self.sources.append(g.local_results[0])
            countLOCAL += 1
        for scraper_links in links_scraper():
                try:
                    if xbmc.abortRequested: return sys.exit()
                    if progressDialog.iscanceled(): break
                    count += 1
                    percent = int((count * 100) / num_scrapers)
                    if scraper_links is not None:
                        random.shuffle(scraper_links)
                    for scraper_link in scraper_links:
                        try:
                            q = scraper_link['quality'].lower()
                            if q in ["1080", "1080p"]:
                                count1080p += 1
                                scraper_link["quality"] = "1080p"
                            elif q in ["hd", "720p", "720", "560p", "560", "dvd", "bluray"]:
                                count720p += 1
                                scraper_link['quality'] = "720p"
                            else:
                                countSD += 1
                                scraper_link["quality"] = "SD"
                        except: pass
                        self.sources.append(scraper_link)
                        try:
                            if progressDialog.iscanceled():
                                progressDialog.close()
                                break
                        except: pass
                except: pass
                progressDialog.update(percent, "[B]Local: [/B]" + seperator % ('gold', str(countLOCAL)) + "[B]1080p: [/B]" + seperator % ('lime', str(count1080p)) + "[B]720p: [/B]" + seperator % ('lime', str(count720p)) + "[B]SD: [/B]" + seperator % ('lime', str(countSD)) + "[B]Total: [/B]" + seperator.replace('  |  ', '') % ('red', str(len(self.sources))), string3 % (num_scrapers - count))

    def display_universal_results(self):
        if self.use_dialog:
            meta = json.loads(window.getProperty('furkit_media_meta'))
            count = 0
            display_list = []
            for item in g.universal_results:
                count += 1
                display = '%02d | %s' % (count, item.get("display_name").replace('[B]', '').replace('[/B]', '').replace('[I]', '').replace('[/I]', ''))
                listitem = xbmcgui.ListItem(display, '[I]%s[/I]' % meta.get("rootname"), iconImage=meta.get("poster"))
                listitem.setProperty('item', json.dumps(item))
                display_list.append(listitem)
            chosen = dialog.select("Furk It Universal Results", display_list, useDetails=True)
            if chosen >= 0:
                item = display_list[chosen].getProperty('item')
                return self.resolve_universal(item)
            else: return
        else:
            universal_files_list = []
            count = 0
            meta = json.loads(window.getProperty('furkit_media_meta'))
            for item in g.universal_results:
                contextMenuItems = []
                playback_params = {'mode': 'playback_menu', 'from_results': True}
                down_archive_params = {'mode': 'download_file_universal', 'info': json.dumps(item)}
                url = build_url({'mode': 'resolve_universal', 'info': json.dumps(item)})
                count += 1
                display = '%02d | %s' % (count, item.get("display_name"))
                listitem = xbmcgui.ListItem(display)
                listitem.setArt({'thumb': meta.get("poster"), 'fanart': meta.get("fanart")})
                if not item.get("local"): contextMenuItems.append(("Download File",'XBMC.RunPlugin(%s)' % build_url(down_archive_params)))
                contextMenuItems.append(("Playback/Search Options",'XBMC.RunPlugin(%s)' % build_url(playback_params)))
                listitem.addContextMenuItems(contextMenuItems, replaceItems=False)
                if meta.get("vid_type") == 'movie': listitem.setInfo('video', {'title': meta.get("title"), 'year': meta.get("year"), 'plot': meta.get("plot")})
                else: listitem.setInfo('video', {'title': meta.get("title"), 'plot': meta.get("plot")})
                universal_files_list.append((url, listitem, True))
            xbmcplugin.addDirectoryItems(__handle__, universal_files_list, len(universal_files_list))
            setView(MEDIA_RESULTS_VIEW)
            xbmcplugin.endOfDirectory(__handle__)
            return

    def auto_play_universal(self):
        xbmc.sleep(2000)
        progressDialog = xbmcgui.DialogProgress()
        progressDialog.create('Furk It Universal Sources', '', '', '')
        count = int(len(g.universal_results))
        for item in g.universal_results:
            count -= 1
            string1 = '[I]%s[/I]' % item.get('display_name').replace('[I]', '').replace('[/I]', '').replace('[B]', '').replace('[/B]', '')
            string2 = '[B]Remaining Sources:[/B]   %s'
            progressDialog.update(-1, '[B]Resolving:[/B]   %s' % string1, string2 % count, '')
            if self.resolve_universal(json.dumps(item)): return True
            else: pass
            try:
                if xbmc.abortRequested: return sys.exit()
                try:
                    if progressDialog.iscanceled(): break
                except: pass
                if not thread.is_alive(): break
                time.sleep(0.5)
            except: pass
        try: progressDialog.close()
        except: pass

    def resolve_universal(self, item_info):
        info = json.loads(item_info)
        meta = json.loads(window.getProperty('furkit_media_meta'))
        url = info.get("url_dl")
        try:
            if not info.get("direct"):
                import resolveurl
                hmf = resolveurl.HostedMediaFile(url=url, include_disabled=True, include_universal=True)
                if hmf.valid_url() == True: url = hmf.resolve()
                if url == False or url == None: raise Exception()
            play_url = build_url({'mode': 'bookmark_choice', 'url': url})
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % play_url)
            return True
        except: return False

    def download_file_universal(self, item_info):
        info = json.loads(item_info)
        meta = json.loads(window.getProperty('furkit_media_meta'))
        url = info.get("url_dl")
        try:
            if not info.get("direct"):
                import resolveurl
                hmf = resolveurl.HostedMediaFile(url=url, include_disabled=True, include_universal=True)
                if hmf.valid_url() == True: url = hmf.resolve()
                if url == False or url == None: raise Exception()
            name = '{0}.{1}'.format(meta.get("rootname"), url.rsplit('.',1)[1]) if not info.get("direct") else '{0}.mp4'.format(meta.get("rootname"))
            url_params = {'mode': 'download_file', 'name': name, 'url': url, 'image': meta.get("poster")}
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % build_url(url_params))
        except:
            from resources.lib.modules.nav_utils import notification
            notification('Error with Downloading', 5000)

    def _check_library_before_search(self):
        LocalLibrarySource(self.use_dialog).results(self.info)
        if g.local_results:
            if self.autoplay: return True
            else:
                line = '%s (%s)' % (self.title, self.year) if self.db_type == 'movie' else '%s - %dx%.2d' % (self.title, int(self.season), int(self.episode))
                if xbmcgui.Dialog().yesno("%s found in Kodi Database" % line, "Would you like to play the local file?", '', '', 'Yes', 'No') == 0:
                    g.local_results[0]['play_local'] = True
                    return True
                else:
                    g.local_results = []
                    return False
        else: pass

    def _update_meta(self, meta):
        meta = json.loads(meta)
        media_id = meta.get('tmdb_id', '')
        meta['vid_type'] = self.db_type
        display_name = '{0} ({1})'.format(self.title, self.year) if meta['vid_type'] == 'movie' else '%s - %dx%.2d' % (self.title, int(self.season), int(self.episode))
        meta.update({'media_id': media_id, 'rootname': display_name, 'tvshowtitle': self.title, 'season': (int(self.season) if self.db_type == 'episode' else ''), 'episode': (int(self.episode) if self.db_type == 'episode' else ''), 'ep_name': self.ep_name})
        window.setProperty('furkit_media_meta', json.dumps(meta))

    def _build_display_name(self, item):
        if item.get("local"): return item.get("display_name")
        try: source = item.get("source").split('.')[0].lower()
        except: source = item.get("source").lower()
        scraper = '[B]DEBRID |[/B] {}'.format(item.get("scraper")) if (source in settings.get_rd_hosts() and self.allow_debrid) else '{}'.format(item.get("scraper"))
        source = '[B]{}[/B]'.format(source)
        quality = '[I]{}[/I]'.format(item.get("quality")) if not item.get("quality") in ['4K', '1080p', '720p'] else '[B][I]{}[/I][/B]'.format(item.get("quality"))
        return '{0}  |  {1}  |  {2}'.format(quality, scraper, source).upper()

    def _get_quality_rank(self, results):
        if 'local' in results.get("display_name").lower(): return 5
        elif results.get("quality") == '4K': return 5
        elif results.get("quality") == '1080p': return 4
        elif results.get("quality") == '720p': return 3
        elif results.get("quality") == 'SD': return 2
        else: return 1

    def _get_name_rank(self, name):
        if 'debrid' in name.lower(): return 2
        else: return 1

    def _filter_results(self, orig_results):
        results = []
        quality_filter = self._quality_filter()
        for item in orig_results:
            if item.get("local") and not settings.include_local_in_filter(self.autoplay): results.append(item)
            elif item.get("quality") in quality_filter: results.append(item)
        return self._sort_results(results)

    def _sort_results(self, results):
        for r in results:
            r['display_name'] = self._build_display_name(r)
            r['quality_rank'] = self._get_quality_rank(r)
            r['name_rank'] = self._get_name_rank(r.get("display_name"))
        return sorted(results, key=itemgetter('quality_rank', 'name_rank'), reverse=True)

    def _quality_filter(self):
        sl = ['results_quality', 'autoplay_quality', 'results_quality_library', 'autoplay_quality_library']
        if not self.from_library: setting = sl[0] if not self.autoplay else sl[1]
        elif self.from_library: setting = sl[2] if not self.autoplay else sl[3]
        quality_filter = settings.quality_filter(setting)
        pre_release_list = ['SCR', 'CAM', 'TELE', 'HDCAM']
        [quality_filter.append(item) for item in pre_release_list if settings.include_prerelease_results(self.origin)]
        return quality_filter

