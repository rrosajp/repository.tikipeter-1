import xbmc, xbmcgui, xbmcaddon
import sys, os
from urlparse import parse_qsl
from resources.lib.modules.nav_utils import notification
from resources.lib.modules import settings
try: from sqlite3 import dbapi2 as database
except ImportError: from pysqlite2 import dbapi2 as database
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.furkit'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__addon_profile__ = xbmc.translatePath(__addon__.getAddonInfo('profile'))

dialog = xbmcgui.Dialog()

FAVOURITES_DB = os.path.join(__addon_profile__, 'favourites.db')

def add_to_favourites(db_type=None, tmdb_id=None, title=None):
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    settings.check_database(FAVOURITES_DB)
    db_type = params.get('db_type', db_type)
    tmdb_id = params.get('tmdb_id', tmdb_id)
    title = params.get('title', title)
    try:
        dbcon = database.connect(FAVOURITES_DB)
        dbcur = dbcon.cursor()
        dbcur.execute("INSERT INTO favourites VALUES (?, ?, ?)", (db_type, str(tmdb_id), title))
        dbcon.commit()
        dbcon.close()
        notification('%s added to Favourites' % title.upper(), 2000)
    except: notification('%s already in Favourites' % title.upper(), 4000)

def remove_from_favourites():
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    settings.check_database(FAVOURITES_DB)
    dbcon = database.connect(FAVOURITES_DB)
    dbcur = dbcon.cursor()
    dbcur.execute("DELETE FROM favourites where db_type=? and tmdb_id=?", (params.get('db_type'), str(params.get('tmdb_id'),)))
    dbcon.commit()
    dbcon.close()
    xbmc.executebuiltin("Container.Refresh")
    notification('%s removed from Favourites' % params.get('title').upper(), 1200)

def retrieve_favourites(page_no, db_type, passed_list=[]):
    import ast
    from resources.lib.modules.nav_utils import paginate_list
    from resources.lib.modules.utils import title_key
    limit = 40
    if not passed_list:
        settings.check_database(FAVOURITES_DB)
        dbcon = database.connect(FAVOURITES_DB)
        dbcur = dbcon.cursor()
        dbcur.execute('''SELECT tmdb_id, title FROM favourites WHERE db_type=?''', (db_type,))
        rows = dbcur.fetchall()
        dbcon.close()
        if db_type == 'audio': return list(set([i[0] for i in rows]))
        data = [{'tmdb_id': str(i[0]), 'title': str(i[1])} for i in rows]
        data = sorted(data, key=lambda k: title_key(k['title']))
        original_list = [i['tmdb_id'] for i in data]
    else: original_list = ast.literal_eval(passed_list)
    paginated_list, total_pages = paginate_list(original_list, page_no, limit)
    return paginated_list, original_list, total_pages, limit

def clear_favourites():
    settings.check_database(FAVOURITES_DB)
    fl = ['Movie Favourites', 'TV Show Favourites', 'Music Favourites']
    fl_choose = dialog.select("Choose Favourites to Erase", fl)
    if fl_choose >= 0:
        if fl[fl_choose] == 'Movie Favourites':
            db_type = 'movie'
        elif fl[fl_choose] == 'TV Show Favourites':
            db_type = 'tvshow'
        else:
            db_type = 'audio'
        confirm = dialog.yesno('Are you sure?', 'Continuing will erase all your {}'.format(fl[fl_choose]))
        if confirm == True:
            dbcon = database.connect(FAVOURITES_DB)
            dbcur = dbcon.cursor()
            dbcur.execute("DELETE FROM favourites WHERE db_type=?", (db_type,))
            dbcur.execute("VACUUM")
            dbcon.commit()
            dbcon.close()
            notification('{}'.format(fl[fl_choose] + ' Erased'), 3000)
        else:
            return
    else:
        return

def add_to_favourites_audio():
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    try:
        dialog = xbmcgui.Dialog()
        fav_title = dialog.input('Choose Name for New Furk It Music Favourite', type=xbmcgui.INPUT_ALPHANUM, defaultt=params.get('name'))
        audio_id = '%s<>%s<>%s<>%s' % (fav_title, params.get('id'), params.get('url_dl'), params.get('size'))
        add_to_favourites('audio', audio_id, fav_title)
    except: notification('Error Adding Item to Favourites', 3500)



