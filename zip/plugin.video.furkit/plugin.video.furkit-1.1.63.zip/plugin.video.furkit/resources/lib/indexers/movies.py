import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import sys
import json
from urlparse import parse_qsl
from resources.lib.modules.nav_utils import get_meta, build_url, add_dir, setView
from resources.lib.modules.indicators_bookmarks import get_watched_status, get_resumetime
from resources.lib.modules.trakt import sync_watched_trakt_to_furkit
from resources.lib.modules import workers
from resources.lib.modules import global_vars as g
from resources.lib.modules import settings
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.furkit'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__handle__ = int(sys.argv[1])
addon_dir = xbmc.translatePath(__addon__.getAddonInfo('path'))
dialog = xbmcgui.Dialog()
MOVIES_VIEW  = settings.SETTING_MOVIES_VIEW

class Movies:
    
    def __init__(self, _list=None, idtype=None, action=None):
        self.list = [] if not _list else _list
        self.items = []
        self.new_page = None
        self.total_pages = None
        self.id_type = 'tmdb_id' if not idtype else idtype
        self.action = action
        sync_watched_trakt_to_furkit()

    def fetch_list(self):
        try:
	        if not settings.check_tmdbapi(): return
	        params = dict(parse_qsl(sys.argv[2].replace('?','')))
	        worker = True
	        self.mode = params.get('mode')
	        page_no = int(params.get('new_page', 1))
	        total_pages = None
	        var_module = 'tmdb' if 'tmdb' in self.action else 'trakt' if 'trakt' in self.action else 'imdb' if 'imdb' in self.action else ''
	        try: exec('from resources.lib.modules.%s import %s as function' % (var_module, self.action))
	        except: pass
	        if self.action in ('tmdb_movies_popular','tmdb_movies_blockbusters','tmdb_movies_in_theaters',
	            'tmdb_movies_top_rated','tmdb_movies_upcoming','tmdb_movies_latest_releases','tmdb_movies_premieres',
	            'trakt_movies_trending','trakt_movies_anticipated','trakt_movies_top10_boxoffice'):
	            data = function(page_no)
	            for item in (data['results'] if 'tmdb' in self.action else data): self.list.append((item['id'] if 'tmdb' in self.action else item['movie']['ids']['tmdb'] if 'movie' in item else item['ids']['tmdb'] if 'movie' not in item else None))
	            if self.action not in ('trakt_list_movies_watchlist', 'tmdb_movies_watchlist', 'trakt_movies_premieres', 'trakt_movies_top10_boxoffice'): self.new_page = {'mode': self.mode, 'action': self.action, 'new_page': str((data['page'] if 'tmdb' in self.action else page_no) + 1), 'foldername': self.action}
	        if self.action in ('trakt_collection', 'trakt_watchlist'):
	            data, passed_list, total_pages, limit = function(page_no, 'movies', params.get('passed_list', ''))
	            for item in data: self.list.append(item)
	            if total_pages > 2: self.total_pages = total_pages
	            if len(data) == limit: self.new_page = {'mode': self.mode, 'action': self.action, 'new_page': str(page_no + 1), 'passed_list': passed_list, 'foldername': self.action}
	        elif self.action in ('imdb_movies_languages', 'imdb_movies_oscar_winners'):
	            self.id_type = 'imdb_id'
	            self.list = function(params['language'], page_no) if self.action == 'imdb_movies_languages' else function(page_no)
	            self.new_page = {'mode': self.mode, 'action': self.action, 'language': params.get('language', None), 'new_page': str(page_no + 1), 'foldername': self.action}
	        elif self.action == ('trakt_movies_mosts'):
	            for item in (function(params['period'], params['duration'], page_no)): self.list.append((item['movie']['ids']['tmdb'] if 'movie' in item else item['ids']['tmdb'] if 'movie' not in item else None))
	            self.new_page = {'mode': self.mode, 'action': self.action, 'period': params['period'], 'duration': params['duration'], 'new_page': str(page_no + 1), 'foldername': self.action}
	        elif self.action == 'tmdb_movies_genres':
	            genre_id = params['genre_id'] if 'genre_id' in params else self.multiselect_genres(params.get('genre_list'))
	            if not genre_id: return
	            data = function(genre_id, page_no)
	            self.list = [i['id'] for i in data['results']]
	            if data['page'] < data['total_pages']: self.new_page = {'mode': self.mode, 'action': self.action, 'new_page': str(data['page'] + 1), 'genre_id': genre_id, 'foldername': genre_id}
	        elif self.action == 'tmdb_movies_year':
	            data = function(params['year'], page_no)
	            self.list = [i['id'] for i in data['results']]
	            if data['page'] < data['total_pages']: self.new_page = {'mode': self.mode, 'action': self.action, 'new_page': str(data['page'] + 1), 'year': params.get('year'), 'foldername': params.get('year')}
	        elif self.action == 'tmdb_movies_certifications':
	            data = function(params['certification'], page_no)
	            self.list = [i['id'] for i in data['results']]
	            if data['page'] < data['total_pages']: self.new_page = {'mode': self.mode, 'action': self.action, 'new_page': str(data['page'] + 1), 'certification': params.get('certification'), 'foldername': params.get('certification')}
	        elif self.action in ('favourites_movies', 'subscriptions_movies', 'kodi_library_movies', 'watched_movies'):
	            (var_module, import_function) = ('favourites', 'retrieve_favourites') if 'favourites' in self.action else ('subscriptions', 'retrieve_subscriptions') if 'subscriptions' in self.action else ('indicators_bookmarks', 'get_watched_items') if 'watched' in self.action else ('kodi_library', 'retrieve_kodi_library') if 'library' in self.action else ''
	            try: exec('from resources.lib.modules.%s import %s as function' % (var_module, import_function))
	            except: return
	            if self.action == 'kodi_library_movies': self.id_type = 'imdb_id'
	            data, passed_list, total_pages, limit = function(page_no, 'movie', params.get('passed_list', ''))
	            for item in data: self.list.append(item)
	            if total_pages > 2: self.total_pages = total_pages
	            if len(data) == limit: self.new_page = {'mode': self.mode, 'action': self.action, 'new_page': str(page_no + 1), 'passed_list': passed_list, 'foldername': self.action}
	        elif self.action == 'in_progress_movies':
	            from resources.lib.modules.in_progress import in_progress_movie as function
	            self.list = function('movie')
	            xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
	        elif self.action == 'tmdb_movies_similar':
	            data = function(params['tmdb_id'], page_no)
	            self.list = [i['id'] for i in data['results']]
	            if data['page'] < data['total_pages']: self.new_page = {'mode': self.mode, 'action': self.action, 'new_page': str(data['page'] + 1), 'foldername': self.action, 'tmdb_id': params.get('tmdb_id')}
	        elif self.action == 'trakt_movies_related':
	            for item in function(params['imdb_id'], page_no): self.list.append((item['movie']['ids']['tmdb'] if 'movie' in item else item['ids']['tmdb'] if 'movie' not in item else None))
	            self.new_page = {'mode': self.mode, 'action': self.action, 'new_page': str(int((params.get('new_page') if 'new_page' in params else 1)) + 1), 'foldername': self.action, 'imdb_id': params.get('imdb_id')}
	        elif self.action == 'trakt_recommendations':
	            for item in function('movies'): self.list.append(item['ids']['tmdb'])
	        elif self.action == 'tmdb_popular_people':
	            import os
	            worker = False
	            icon_directory = settings.get_theme()
	            data = function(page_no)
	            for item in data['results']:
	                actor_poster = "http://image.tmdb.org/t/p/original%s" % item['profile_path'] if item['profile_path'] else os.path.join(icon_directory, 'app_logo.png')
	                url_params = {'mode': 'build_movie_list', 'action': 'tmdb_movies_actor_roles', 'actor_id': item['id']}
	                url = build_url(url_params)
	                listitem = xbmcgui.ListItem(item['name'])
	                listitem.setArt({'poster': actor_poster, 'fanart': os.path.join(addon_dir, 'fanart.jpg')})
	                xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=True)
	            if data['page'] < data['total_pages']: self.new_page = {'mode': self.mode, 'action': self.action, 'new_page': str(int(data['page']) + 1), 'foldername': self.action}
	        elif self.action == 'tmdb_movies_actor_roles':
	            self.list = [i['id'] for i in function(params['actor_id'])['cast']]
	        elif self.action in ('tmdb_movies_search', 'tmdb_movies_people_search'):
	            import urllib
	            if params.get('query') == 'NA':
	                search_title = dialog.input("Search Furk It", type=xbmcgui.INPUT_ALPHANUM)
	                search_name = urllib.unquote(search_title)
	            else: search_name = urllib.unquote(params.get('query'))
	            if not search_name: return
	            data = function(search_name, page_no)
	            self.list = [i['id'] for i in (data['results'] if self.action == 'tmdb_movies_search' else data['cast'])]
	            if self.action == 'tmdb_movies_search':
	                if data['page'] < data['total_pages']: self.new_page = {'mode': self.mode, 'action': self.action, 'new_page': str(int(data['page']) + 1), 'query': search_name, 'foldername': search_name}
	        if self.total_pages: add_dir({'mode': 'build_navigate_to_page', 'current_page': page_no, 'total_pages': self.total_pages, 'transfer_mode': self.mode, 'transfer_action': self.action, 'passed_list': passed_list, 'foldername': self.action}, 'Go to Page....', iconImage='item_jump.png')
	        if worker: self.worker()
	        if self.new_page: add_dir(self.new_page, 'Next Page >>', iconImage='item_next.png')
        except: pass
        xbmcplugin.setContent(__handle__, 'movies')
        xbmcplugin.endOfDirectory(__handle__)
        setView(MOVIES_VIEW)

    def build_movie_content(self):
        content = sorted(self.items, key=lambda k: k['item_no'])
        for i in content:
            try:
                cmenu = []
                watched_indicators = settings.watched_indicators()
                if not 'rootname' in i: i['rootname'] = '{0} ({1})'.format(i['title'], i['year'])
                meta_json = json.dumps(i)
                url_params = {'mode': 'play_media', 'vid_type': 'movie', 'query': i['rootname'], 'meta': meta_json}
                url = build_url(url_params)
                from_search = 'true' if self.action in ('tmdb_movies_search', 'tmdb_movies_people_search') else 'false'
                playback_params = {'mode': 'playback_menu', 'suggestion': i['rootname']}
                hide_recommended_params = {'mode': 'trakt.hide_recommendations', 'db_type': 'movies', 'imdb_id': i['imdb_id']}
                extended_info_url = 'RunScript(script.extendedinfo,info=extendedinfo,title=%s,imdb_id=%s)' % (i['title'], i['imdb_id'])
                watched_title = 'Trakt' if watched_indicators == 2 else "Trakt & Furk It" if watched_indicators == 1 else 'Furk It'
                (state, action) = ('Watched', 'mark_as_watched') if i['playcount'] == 0 else ('Unwatched', 'mark_as_unwatched')
                (state2, action2) = ('Watched', 'mark_as_watched') if state == 'Unwatched' else ('Unwatched', 'mark_as_unwatched')
                watched_unwatched_params = {"mode": "mark_movie_as_watched_unwatched", "action": action, "media_id": i['tmdb_id'], "from_search": from_search, "title": i['title'], "year": i['year']}
                add_remove_params = {"mode": "build_add_to_remove_from_list", "meta": meta_json, "media_type": "movie", "from_search": from_search, "orig_mode": self.action}
                sim_rel_params = {"mode": "similar_related_choice", "db_type": "movies" , "tmdb_id": i['tmdb_id'], "imdb_id": i['imdb_id'], "from_search": from_search}
                listitem = xbmcgui.ListItem(i['title'])
                listitem.setProperty("resumetime", get_resumetime('movie', i['tmdb_id']))
                cmenu.append(("Mark %s %s" % (state, watched_title),"XBMC.RunPlugin(%s)" % build_url(watched_unwatched_params)))
                if listitem.getProperty("resumetime") != '0.000000': cmenu.append(("Mark %s %s" % (state2, watched_title), 'XBMC.RunPlugin(%s)' % build_url({"mode": "mark_movie_as_watched_unwatched", "action": action2, "media_id": i['tmdb_id'], "from_search": from_search, "title": i['title'], "year": i['year']})))
                cmenu.append(("Playback/Search Options","XBMC.RunPlugin(%s)" % build_url(playback_params)))
                cmenu.append(("Add to/Remove from...","XBMC.RunPlugin(%s)" % build_url(add_remove_params)))
                cmenu.append(("Similar/Related Movies","XBMC.RunPlugin(%s)" % build_url(sim_rel_params)))
                if self.action == 'trakt_recommendations': cmenu.append(("Hide from Recommendations", "XBMC.RunPlugin(%s)" % build_url(hide_recommended_params)))
                cmenu.append(("Extended Info", "%s" % extended_info_url))
                listitem.addContextMenuItems(cmenu)
                listitem.setCast(i['cast'])
                del i['cast']
                listitem.setArt({'poster': i['poster'], 'fanart': i['fanart']})
                listitem.setInfo('Video', i)
                xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=False)
            except: pass

    def set_info(self, item_no):
        meta = get_meta('movie', self.id_type, self.list[item_no], 720)
        playcount, overlay = get_watched_status('movie', meta['tmdb_id'])
        self.items.append({'item_no': item_no, 'mediatype': 'movie', 'trailer': str(meta['trailer']),
            'title': meta['title'], 'size': '0', 'duration': meta['duration'],
            'plot': meta['plot'], 'rating': meta['rating'], 'premiered': meta['premiered'], 
            'studio': meta['studio'],'year': meta['year'], 'tmdb_id': meta['tmdb_id'],
            'genre': meta['genre'],'tagline': meta['tagline'], 'code': meta['imdb_id'],
            'imdbnumber': meta['imdb_id'], 'imdb_id': meta['imdb_id'],
            'director': meta['director'], 'writer': meta['writer'], 'votes': meta['votes'],
            'playcount': playcount, 'overlay': overlay, 'poster': meta['poster'],
            'fanart': meta['fanart'], 'cast': meta['cast'], 'mpaa': meta['certification']})

    def worker(self):
        total = len(self.list)
        threads = []
        [threads.append(workers.Thread(self.set_info, i)) for i in range(total) if i <= total]
        [i.start() for i in threads]
        [i.join() for i in threads]
        self.build_movie_content()

    def multiselect_genres(self, genre_list):
        import os, ast
        dialog = xbmcgui.Dialog()
        genre_list = ast.literal_eval(genre_list)
        choice_list = []
        icon_directory = settings.get_theme()
        for genre, value in sorted(genre_list.items()):
            listitem = xbmcgui.ListItem(genre, '', iconImage=os.path.join(icon_directory, value[1]))
            listitem.setProperty('genre_id', value[0])
            choice_list.append(listitem)
        chosen_genres = dialog.multiselect("Select Genres to Include in Search", choice_list, useDetails=True)
        if not chosen_genres: return
        genre_ids = [choice_list[i].getProperty('genre_id') for i in chosen_genres]
        return ','.join(genre_ids)
