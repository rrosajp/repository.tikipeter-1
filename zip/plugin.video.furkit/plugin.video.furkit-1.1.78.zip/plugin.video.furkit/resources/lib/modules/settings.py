import xbmc, xbmcaddon
import os
# from resources.lib.modules.utils import logger

__addon__ = xbmcaddon.Addon(id='plugin.video.furkit')
ADDON_PATH = xbmc.translatePath(__addon__.getAddonInfo('path'))
DATA_PATH = xbmc.translatePath(__addon__.getAddonInfo('profile'))

SETTING_TRAKT_ACCESS_TOKEN = "trakt_access_token"
SETTING_TRAKT_REFRESH_TOKEN = "trakt_refresh_token"
SETTING_TRAKT_EXPIRES_AT = "trakt_expires_at"
SETTING_TMDB_API = "tmdb_api"
SETTING_TMDB_SESSION = "tmdb_session_id"
SETTING_MAIN_VIEW = "view.main"
SETTING_FURK_FILES_VIEW = "view.furk_files"
SETTING_MEDIA_RESULTS_VIEW = "view.media_results"
SETTING_PACK_RESULTS_VIEW = "view.pack_results"
SETTING_MOVIES_VIEW = "view.movies"
SETTING_TVSHOWS_VIEW = "view.tvshows"
SETTING_SEASONS_VIEW = "view.seasons"
SETTING_EPISODES_VIEW = "view.episodes"
SETTING_PROGRESS_NEXT_EPISODE_VIEW = "view.progress_next_episode"
SETTING_LIST_VIEW = "view.list"
SETTING_TRAKT_LIST_VIEW = "view.trakt_list"
SETTING_DATETIME_OFFSET = "datetime.offset"

def addon_installed(addon_id):
    if xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id): return True
    else: return False

def get_theme():
    theme = __addon__.getSetting('furkit.theme').lower()
    if theme in ['-', '']: theme = 'Light'
    if addon_installed('script.furkit.artwork'):
        __addon__.setSetting('theme_installed', 'true')
        return os.path.join(xbmcaddon.Addon('script.furkit.artwork').getAddonInfo('path'), 'resources', 'media', theme)
    else:
        __addon__.setSetting('theme_installed', 'false')
        return 'null'

def check_database(database):
    import xbmcvfs
    if not xbmcvfs.exists(database):
        from resources.lib.modules.settings import initialize_databases
        initialize_databases()

def use_dialog():
    if __addon__.getSetting('use_dialog') == "Dialog": return True
    else: return False

def fav_default():
    if __addon__.getSetting('favourites_default') == "true" and __addon__.getSetting('favourites_enabled') == "true": return True
    else: return False

def addon():
    return __addon__

def show_specials():
    if __addon__.getSetting('show_specials') == 'true': return True
    else: return False

def resume_type(origin):
    if __addon__.getSetting('resume_autoplay') == 'true' and auto_play(origin): return 'Automatic'
    return __addon__.getSetting('resume')

def adjusted_datetime(str=False):
    from datetime import datetime, timedelta
    d = datetime.utcnow() - timedelta(hours=int(__addon__.getSetting(SETTING_DATETIME_OFFSET)))
    d = datetime.date(d)
    if str: return d.strftime('%Y-%m-%d')
    else: return d
    
def movies_directory():
    return xbmc.translatePath(__addon__.getSetting('movies_directory'))
    
def tv_show_directory():
    return xbmc.translatePath(__addon__.getSetting('tv_shows_directory'))

def download_directory(db_type):
    setting = 'movie_download_directory' if db_type == 'movie' else 'tvshow_download_directory' if db_type == 'episode' else 'furk_file_download_directory'
    if __addon__.getSetting(setting) != '': return xbmc.translatePath( __addon__.getSetting(setting))
    else: return False

def backup_directory():
    return __addon__.getSetting('backup_directory')

def quality_filter(setting):
    return __addon__.getSetting(setting).split(', ')

def include_prerelease_results(origin=None):
    setting = 'include_prerelease_results' if origin == None else 'include_prerelease_results_library'
    if __addon__.getSetting(setting) == "true": return True
    else: return False

def include_local_in_filter(autoplay=None):
    setting = 'include_local_in_filter' if not autoplay else 'include_local_in_filter_autoplay'
    if __addon__.getSetting(setting) == "true": return True
    else: return False

def auto_play(origin=None):
    setting = 'auto_play' if origin == None else 'auto_play_library'
    if __addon__.getSetting(setting) == "true": return True
    else: return False

def auto_resolve(origin=None):
    setting = 'auto_resolve' if origin == None else 'auto_resolve_library'
    if __addon__.getSetting(setting) == "true": return True
    else: return False

def autoplay_next_episode(origin=None):
    setting_autoplay = 'auto_play' if origin == None else 'auto_play_library'
    setting_next_ep = 'autoplay_next_episode' if origin == None else 'autoplay_next_episode_library'
    if __addon__.getSetting(setting_next_ep) == "true" and __addon__.getSetting(setting_autoplay) == 'true': return True
    else: return False

def autoplay_next_prompt(origin=None):
    setting = 'autoplay_next_still_watching' if origin == None else 'autoplay_next_still_watching_library'
    if __addon__.getSetting(setting) == 'true': return True
    else: return False

def autoplay_next_number(origin=None):
    setting = 'autoplay_next_number' if origin == None else 'autoplay_next_number_library'
    return int(__addon__.getSetting(setting))

def prefer_hevc(origin=None):
    setting = 'prefer_hevc' if origin == None else 'prefer_hevc_library'
    if __addon__.getSetting(setting) == "true": return True
    else: return False

def sync_kodi_library_watchstatus():
    if __addon__.getSetting('sync_kodi_library_watchstatus') == "true": return True
    else: return False

def define_origin(source=None):
    return None if source == None else 'context'

def watched_indicators():
    if __addon__.getSetting('trakt_user') == '': return 0
    if __addon__.getSetting('watched_indicators') == '0': return 0
    elif __addon__.getSetting('watched_indicators') == '1' and __addon__.getSetting('sync_furkit_watchstatus') == 'true': return 1
    else: return 2

def check_library():
    if __addon__.getSetting('check_library') == "true" and __addon__.getSetting('auto_play') != "true": return True
    else: return False

def subscription_update():
    if __addon__.getSetting('subscription_update') == "true": return True
    else: return False

def skip_duplicates():
    if __addon__.getSetting('skip_duplicates') == "true": return True
    else: return False

def update_library_after_service():
    if __addon__.getSetting('update_library_after_service') == "true": return True
    else: return False

def prompt_for_fallback():
    if __addon__.getSetting('universal_prompt_fallback') == "true": return True
    else: return False

def universal_fallback():
    if __addon__.getSetting('universal_fallback') == "true": return True
    else: return False

def search_provider():
    if not check_universal(): return 'furk'
    if __addon__.getSetting('search.provider') == '0': return 'furk'
    return 'universal'

def library_use_custom_list():
    if __addon__.getSetting('library_use_custom_list') == 'true': return True
    else: return False

def library_default_movie_list_valid():
    if __addon__.getSetting('library_default_movie_list') == 'None': return False
    else: return True

def library_default_tvshow_list_valid():
    if __addon__.getSetting('library_default_tvshow_list') == 'None': return False
    else: return True

def library_default_list_name(db_type):
    setting_id = 'library_default_movie_list' if db_type == 'movie' else 'library_default_tvshow_list'
    return __addon__.getSetting(setting_id)

def subscription_timer():
    hours_list = [1, 2, 4, 6, 8, 10, 12, 14, 15, 18, 24]
    return hours_list[int(__addon__.getSetting('subscription_timer'))]

def set_resume():
    return float(__addon__.getSetting('resume.threshold'))

def set_watched():
    return float(__addon__.getSetting('watched.threshold'))

def set_nextep():
    return float(__addon__.getSetting('nextep.threshold'))

def nextep_display_settings():
    from ast import literal_eval
    include_airdate = literal_eval(__addon__.getSetting('nextep.include_airdate').title())
    airdate_colour = __addon__.getSetting('nextep.airdate_colour')
    unaired_colour = __addon__.getSetting('nextep.unaired_colour')
    unwatched_colour = __addon__.getSetting('nextep.unwatched_colour')
    return {'include_airdate': include_airdate, 'airdate_colour': airdate_colour,
            'unaired_colour': unaired_colour, 'unwatched_colour': unwatched_colour}

def nextep_content_settings():
    from ast import literal_eval
    sort_type = int(__addon__.getSetting('nextep.sort_type'))
    sort_order = int(__addon__.getSetting('nextep.sort_order'))
    sort_key = 'curr_last_played_parsed' if sort_type == 0 else 'first_aired' if sort_type == 1 else 'name'
    sort_direction = True if sort_order == 0 else False
    include_unaired = literal_eval(__addon__.getSetting('nextep.include_unaired').title())
    include_unwatched = literal_eval(__addon__.getSetting('nextep.include_unwatched').title())
    return {'sort_key': sort_key, 'sort_direction': sort_direction,
            'include_unaired': include_unaired, 'include_unwatched': include_unwatched}

def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

def check_tmdbapi():
    tmdb_api = xbmcaddon.Addon(id='plugin.video.furkit').getSetting(SETTING_TMDB_API)
    if not tmdb_api or tmdb_api == '':
        import xbmcgui
        dialog = xbmcgui.Dialog()
        if dialog.yesno("No TMDb API set!", "Furk It requires you to supply a valid TMDb API", "to view lists.  Would you like to go to settings and supply one?"):
            from resources.lib.modules.nav_utils import open_settings
            open_settings('0.7')
        return False
    return True

def check_universal():
    if addon_installed('script.module.universalscrapers'): return True
    else: return False

def initialize_databases():
    import xbmcvfs
    if not xbmcvfs.exists(DATA_PATH): xbmcvfs.mkdirs(DATA_PATH)
    NAVIGATOR_DB = os.path.join(DATA_PATH, "navigator.db")
    METACACHE_DB = os.path.join(DATA_PATH, "metacache.db")
    WATCHED_DB = os.path.join(DATA_PATH, "watched_status.db")
    FAVOURITES_DB = os.path.join(DATA_PATH, "favourites.db")
    SUBSCRIPTIONS_DB = os.path.join(DATA_PATH, "subscriptions.db")
    VIEWS_DB = os.path.join(DATA_PATH, "views.db")
    FURKIT_DB = os.path.join(DATA_PATH, "furkit_cache.db")
    if not xbmcvfs.exists(NAVIGATOR_DB):
        try: from sqlite3 import dbapi2 as database
        except ImportError: from pysqlite2 import dbapi2 as database
        dbcon = database.connect(NAVIGATOR_DB)
        dbcon.execute("""CREATE TABLE IF NOT EXISTS navigator
                          (list_name text, list_type text, list_contents text) 
                       """)
        dbcon.execute("""CREATE TABLE IF NOT EXISTS navigator_favourites
                          (list_contents text) 
                       """)
        dbcon.close()
    if not xbmcvfs.exists(METACACHE_DB):
        try: from sqlite3 import dbapi2 as database
        except: from pysqlite2 import dbapi2 as database
        dbcon = database.connect(METACACHE_DB)
        dbcon.execute("""CREATE TABLE IF NOT EXISTS metadata
                          (db_type text not null, tmdb_id text not null, imdb_id text, tvdb_id text,
                          meta text, expires integer, unique (db_type, tmdb_id))
                       """)
        dbcon.close()
    if not xbmcvfs.exists(WATCHED_DB):
        try: from sqlite3 import dbapi2 as database
        except: from pysqlite2 import dbapi2 as database
        dbcon = database.connect(WATCHED_DB)
        dbcon.execute("""CREATE TABLE IF NOT EXISTS progress
                          (db_type text, media_id text, season integer, episode integer,
                          resume_point text, curr_time text,
                          unique(db_type, media_id, season, episode)) 
                       """)
        dbcon.execute("""CREATE TABLE IF NOT EXISTS watched_status
                          (db_type text, media_id text, season integer,
                          episode integer, last_played text, title text,
                          unique(db_type, media_id, season, episode)) 
                       """)
        dbcon.execute("""CREATE TABLE IF NOT EXISTS exclude_from_next_episode
                          (media_id text, title text) 
                       """)
        dbcon.execute("""CREATE TABLE IF NOT EXISTS unwatched_next_episode
                          (media_id text) 
                       """)
        dbcon.close()
    if not xbmcvfs.exists(FAVOURITES_DB):
        try:from sqlite3 import dbapi2 as database
        except ImportError:from pysqlite2 import dbapi2 as database
        dbcon = database.connect(FAVOURITES_DB)
        dbcon.execute("""CREATE TABLE IF NOT EXISTS favourites
                          (db_type text, tmdb_id text, title text, unique (db_type, tmdb_id)) 
                       """)
        dbcon.close()
    if not xbmcvfs.exists(SUBSCRIPTIONS_DB):
        try: from sqlite3 import dbapi2 as database
        except ImportError: from pysqlite2 import dbapi2 as database
        dbcon = database.connect(SUBSCRIPTIONS_DB)
        dbcon.execute("""CREATE TABLE IF NOT EXISTS subscriptions
                          (db_type text, tmdb_id text, title text, unique (db_type, tmdb_id)) 
                       """)
        dbcon.close()
    if not xbmcvfs.exists(VIEWS_DB):
        try: from sqlite3 import dbapi2 as database
        except ImportError: from pysqlite2 import dbapi2 as database
        dbcon = database.connect(VIEWS_DB)
        dbcon.execute("""CREATE TABLE IF NOT EXISTS views
                          (view_type text, view_id text, unique (view_type)) 
                       """)
        dbcon.close()
    if not xbmcvfs.exists(FURKIT_DB):
        try: from sqlite3 import dbapi2 as database
        except ImportError: from pysqlite2 import dbapi2 as database
        dbcon = database.connect(FURKIT_DB)
        dbcon.execute("""CREATE TABLE IF NOT EXISTS furkitcache
                           (id text UNIQUE, expires integer, data text, checksum integer)
                            """)
        dbcon.close()   
    return True

def get_rd_hosts():
    try:
        valid_hosts = [
            "1fichier.com",
            "alterupload.com",
            "cjoint.net",
            "desfichiers.com",
            "dfichiers.com",
            "megadl.fr",
            "mesfichiers.org",
            "piecejointe.net",
            "pjointe.com",
            "tenvoi.com",
            "dl4free.com",
            "24uploading.com",
            "2shared.com",
            "4shared.com",
            "alfafile.net",
            "big4shared.com",
            "bitporno.com",
            "catshare.net",
            "cbs.com",
            "clicknupload.me",
            "clicknupload.com",
            "clicknupload.link",
            "clicknupload.org",
            "dailymotion.com",
            "datafile.com",
            "datafilehost.com",
            "datei.to",
            "datoporn.co",
            "depositfiles.com",
            "depositfiles.org",
            "dfiles.eu",
            "dfiles.ru",
            "dl.free.fr",
            "easybytez.com",
            "extmatrix.com",
            "faststore.org",
            "filefactory.com",
            "fileover.net",
            "filerio.com",
            "filerio.in",
            "filesabc.com",
            "filesflash.com",
            "filesflash.net",
            "filesmonster.com",
            "flashx.tv",
            "flashx.ws",
            "flashx.cc",
            "flashx.bz",
            "flashx.co",
            "gigapeta.com",
            "gigasize.com",
            "docs.google.com",
            "drive.google.com",
            "gulfup.com",
            "hitfile.net",
            "hulkshare.com",
            "icerbox.com",
            "inclouddrive.com",
            "isra.cloud",
            "keep2share.cc",
            "k2s.cc",
            "keep2s.cc",
            "k2share.cc",
            "load.to",
            "mediafire.com",
            "mega.co.nz",
            "mega.nz",
            "nitroflare.com",
            "oboom.com",
            "openload.co",
            "openload.io",
            "oload.tv",
            "oload.info",
            "oload.stream",
            "oload.site",
            "oload.win",
            "oload.download",
            "sky.fm",
            "radiotunes.com",
            "di.fm",
            "classicalradio.com",
            "jazzradio.com",
            "rapidgator.net",
            "rg.to",
            "rapidvideo.com",
            "rarefile.net",
            "real-debrid.com",
            "redbunker.net",
            "redtube.com",
            "canalplus.fr",
            "d8.tv",
            "c8.fr",
            "mycanal.fr",
            "rockfile.eu",
            "rockfile.co",
            "rutube.ru",
            "salefiles.com",
            "scribd.com",
            "sendspace.com",
            "share-online.biz",
            "solidfiles.com",
            "soundcloud.com",
            "streamango.com",
            "fruitstreams.com",
            "fruitadblock.net",
            "streamcherry.com",
            "thevideo.me",
            "thevideo.io",
            "tvad.me",
            "thevideo.website",
            "vev.io",
            "turbobit.net",
            "tusfiles.net",
            "ulozto.net",
            "uloz.to",
            "ulozto.sk",
            "unibytes.com",
            "uploadc.com",
            "uploadc.ch",
            "uploaded.net",
            "uploaded.to",
            "ul.to",
            "uploading.com",
            "upstore.net",
            "uptobox.com",
            "uptostream.com",
            "userporn.com",
            "userscloud.com",
            "veevr.com",
            "vidlox.tv",
            "vidoza.net",
            "vimeo.com",
            "vk.com",
            "wipfiles.net",
            "worldbytez.com",
            "youporn.com",
            "youtube.com",
            "yunfile.com",
            "filemarkets.com",
            "5xpan.com",
            "dix3.com",
            "dfpan.com",
            "pwpan.com",
            "tadown.com",
            "zippyshare.com"
        ]
        return [i.split('.')[0].lower() for i in valid_hosts]
    except: return []


