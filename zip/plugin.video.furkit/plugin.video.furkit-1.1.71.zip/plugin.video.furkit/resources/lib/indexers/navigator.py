import sys, os
import xbmc, xbmcvfs, xbmcaddon, xbmcplugin, xbmcgui
import urllib
import json
from urlparse import parse_qsl
from resources.lib.modules import settings
try: from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.furkit'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__url__ = sys.argv[0]
__handle__ = int(sys.argv[1])
addon_dir = xbmc.translatePath(__addon__.getAddonInfo('path'))
profile_dir = xbmc.translatePath(__addon__.getAddonInfo('profile'))
NAVIGATOR_DB = os.path.join(profile_dir, "navigator.db")

class Navigator:
    def __init__(self, list_name=None):
        self.fav_default = settings.fav_default()
        self.view = settings.SETTING_MAIN_VIEW
        self.icon_directory = settings.get_theme()
        self.list_name = list_name
        self.fanart = os.path.join(addon_dir, 'fanart.jpg')

    def main_lists(self):
        if self.fav_default and self.list_name == 'RootList': self.build_favourites_list()
        else: self.build_main_lists()
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def certifications(self):
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        mode = 'build_movie_list' if params.get('menu_type') == 'movie' else 'build_tvshow_list'
        action = 'tmdb_movies_certifications' if params.get('menu_type') == 'movie' else 'trakt_tv_certifications'
        certifications = ('G','PG','PG-13','R','NC-17', 'NR') if params.get('menu_type') == 'movie' else ('tv-y','tv-y7','tv-g','tv-pg','tv-14','tv-ma')
        for cert in certifications:
            self.add_dir({'mode': mode, 'action': action, 'certification': cert, 'foldername': cert.upper(), 'list_name': '%ss %s Certification' % ((params.get('menu_type')).capitalize(), cert.upper()), 'info': 'Browse %s Certification for %sS.' % (cert.upper(), (params.get('menu_type')).upper())}, cert.upper(), iconImage='certifications.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def languages(self):
        languages = [('Arabic', 'ar'), ('Bosnian', 'bs'), ('Bulgarian', 'bg'), ('Chinese', 'zh'),
        ('Croatian', 'hr'), ('Dutch', 'nl'), ('English', 'en'), ('Finnish', 'fi'), ('French', 'fr'),
        ('German', 'de'), ('Greek', 'el'), ('Hebrew', 'he'), ('Hindi ', 'hi'), ('Hungarian', 'hu'),
        ('Icelandic', 'is'), ('Italian', 'it'), ('Japanese', 'ja'), ('Korean', 'ko'), ('Macedonian', 'mk'),
        ('Norwegian', 'no'), ('Persian', 'fa'), ('Polish', 'pl'), ('Portuguese', 'pt'), ('Punjabi', 'pa'),
        ('Romanian', 'ro'), ('Russian', 'ru'), ('Serbian', 'sr'), ('Slovenian', 'sl'), ('Spanish', 'es'),
        ('Swedish', 'sv'), ('Turkish', 'tr'), ('Ukrainian', 'uk')]
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        mode = 'build_movie_list' if params.get('menu_type') == 'movie' else 'build_tvshow_list'
        action = 'imdb_movies_languages' if params.get('menu_type') == 'movie' else 'imdb_tv_languages'
        for lang in languages:
            self.add_dir({'mode': mode, 'action': action, 'language': lang[1], 'foldername': lang, 'list_name': '%ss %s Language' % ((params.get('menu_type')).capitalize(), lang[0]), 'info': 'Browse %s Language %ss.' % (lang[0], (params.get('menu_type')).capitalize())}, lang[0], iconImage='languages.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def years(self):
        import datetime
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        datetime = (datetime.datetime.utcnow() - datetime.timedelta(hours = 5))
        year = datetime.strftime('%Y')
        mode = 'build_movie_list' if params.get('menu_type') == 'movie' else 'build_tvshow_list'
        action = 'tmdb_movies_year' if params.get('menu_type') == 'movie' else 'tmdb_tv_year'
        for i in range(int(year)-0, 1900, -1):
            self.add_dir({'mode': mode, 'action': action, 'year': str(i), 'foldername': '%s - %s' % (str(i), params.get('menu_type')), 'list_name': '%ss %s Premiered' % ((params.get('menu_type')).capitalize(), str(i)), 'info': 'Browse %sS that Premiered in %s.' % (params.get('menu_type').upper(), str(i))}, str(i), iconImage='calender.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def genres(self):
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        mode = 'build_movie_list' if params.get('menu_type') == 'movie' else 'build_tvshow_list'
        action = 'tmdb_movies_genres' if params.get('menu_type') == 'movie' else 'tmdb_tv_genres'
        if params.get('menu_type') == 'movie':
            genre_list = ({'Action': ['28', 'genre_action.png'], 'Adventure': ['12', 'genre_adventure.png'],
            'Animation': ['16', 'genre_animation.png'], 'Comedy': ['35', 'genre_comedy.png'],
            'Crime': ['80', 'genre_crime.png'], 'Documentary': ['99', 'genre_documentary.png'],
            'Drama': ['18', 'genre_drama.png'], 'Family': ['10751', 'genre_family.png'],
            'Fantasy': ['14', 'genre_fantasy.png'], 'History': ['36', 'genre_history.png'],
            'Horror': ['27', 'genre_horror.png'], 'Music': ['10402', 'genre_music.png'],
            'Mystery': ['9648', 'genre_mystery.png'], 'Romance': ['10749', 'genre_romance.png'],
            'Science Fiction': ['878', 'genre_scifi.png'], 'TV Movie': ['10770', 'genre_soap.png'],
            'Thriller': ['53', 'genre_thriller.png'], 'War': ['10752', 'genre_war.png'], 
            'Western': ['37', 'genre_western.png']})
        else:
            genre_list = ({'Action & Adventure': ['10759', 'genre_action.png'], 'Animation': ['16', 'genre_animation.png'],
            'Comedy': ['35', 'genre_comedy.png'], 'Crime': ['80', 'genre_crime.png'],
            'Documentary': ['99', 'genre_documentary.png'], 'Drama': ['18', 'genre_drama.png'],
            'Family': ['10751', 'genre_family.png'], 'Kids': ['10762', 'genre_kids.png'],
            'Mystery': ['9648', 'genre_mystery.png'], 'News':['10763', 'genre_news.png'],
            'Reality': ['10764', 'genre_reality.png'], 'Sci-Fi & Fantasy': ['10765', 'genre_scifi.png'],
            'Soap': ['10766', 'genre_soap.png'], 'Talk': ['10767', 'genre_talk.png'],
            'War & Politics': ['10768', 'genre_war.png'], 'Western': ['37', 'genre_western.png']})
        self.add_dir({'mode': mode, 'action': action, 'genre_list': genre_list, 'exclude_external': 'true', 'foldername': 'Multiselect', 'info': 'Select Multiple Genres for Movies that Satisfy All Selected Genres.'}, 'Multiselect...', iconImage='genres.png')
        for genre, value in sorted(genre_list.items()):
            self.add_dir({'mode': mode, 'action': action, 'genre_id': value[0], 'foldername': genre, 'list_name': '%ss %s Genre' % ((params.get('menu_type')).capitalize(), genre), 'info': 'Browse %s Genre for %ss.' % (genre, (params.get('menu_type')).capitalize())}, genre, iconImage=value[1])
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def networks(self):
        networks = [{"id":54,"name":"Disney Channel", "logo": "https://i.imgur.com/ZCgEkp6.png"},{"id":44,"name":"Disney XD", "logo": "https://i.imgur.com/PAJJoqQ.png"},
        {"id":2,"name":"ABC", "logo": "https://i.imgur.com/qePLxos.png"},{"id":493,"name":"BBC America", "logo": "https://i.imgur.com/TUHDjfl.png"},{"id":6,"name":"NBC", "logo": "https://i.imgur.com/yPRirQZ.png"},
        {"id":13,"name":"Nickelodeon", "logo": "https://i.imgur.com/OUVoqYc.png"},{"id":14,"name":"PBS", "logo": "https://i.imgur.com/r9qeDJY.png"},{"id":16,"name":"CBS", "logo": "https://i.imgur.com/8OT8igR.png"},
        {"id":19,"name":"FOX", "logo": "https://i.imgur.com/6vc0Iov.png"},{"id":21,"name":"The WB", "logo": "https://i.imgur.com/rzfVME6.png"},{"id":24,"name":"BET", "logo": "https://i.imgur.com/ZpGJ5UQ.png"},
        {"id":30,"name":"USA Network", "logo": "https://i.imgur.com/Doccw9E.png"},{"id":32,"name":"CBC", "logo": "https://i.imgur.com/unQ7WCZ.png"},
        {"id":33,"name":"MTV", "logo": "https://i.imgur.com/QM6DpNW.png"},{"id":34,"name":"Lifetime", "logo": "https://i.imgur.com/tvYbhen.png"},{"id":35,"name":"Nick Junior", "logo": "https://i.imgur.com/leuCWYt.png"},
        {"id":41,"name":"TNT", "logo": "https://i.imgur.com/WnzpAGj.png"},{"id":43,"name":"National Geographic", "logo": "https://i.imgur.com/XCGNKVQ.png"},{"id":47,"name":"Comedy Central", "logo": "https://i.imgur.com/ko6XN77.png"},
        {"id":49,"name":"HBO", "logo": "https://i.imgur.com/Hyu8ZGq.png"},{"id":55,"name":"Spike", "logo": "https://i.imgur.com/BhXYytR.png"},
        {"id":56,"name":"Cartoon Network", "logo": "https://i.imgur.com/zmOLbbI.png"},{"id":65,"name":"History Channel", "logo": "https://i.imgur.com/LEMgy6n.png"},{"id":67,"name":"Showtime", "logo": "https://i.imgur.com/SawAYkO.png"},
        {"id":68,"name":"TBS", "logo": "https://i.imgur.com/RVCtt4Z.png"},{"id":71,"name":"The CW", "logo": "https://i.imgur.com/Q8tooeM.png"},{"id":74,"name":"Bravo", "logo": "https://i.imgur.com/TmEO3Tn.png"},
        {"id":76,"name":"E!", "logo": "https://i.imgur.com/3Delf9f.png"},{"id":77,"name":"Syfy", "logo": "https://i.imgur.com/9yCq37i.png"},{"id":80,"name":"Adult Swim", "logo": "https://i.imgur.com/jCqbRcS.png"},{"id":84,"name":"TLC", "logo": "https://i.imgur.com/c24MxaB.png"},
        {"id":91,"name":"Animal Planet", "logo": "https://i.imgur.com/olKc4RP.png"},{"id":110,"name":"CTV", "logo": "https://i.imgur.com/qUlyVHz.png"},{"id":129,"name":"A&E", "logo": "https://i.imgur.com/xLDfHjH.png"},
        {"id":158,"name":"VH1", "logo": "https://i.imgur.com/IUtHYzA.png"},{"id":174,"name":"AMC", "logo": "https://i.imgur.com/ndorJxi.png"},{"id":928,"name":"Crackle", "logo": "https://i.imgur.com/53kqZSY.png"},
        {"id":202,"name":"WGN America", "logo": "https://i.imgur.com/TL6MzgO.png"},{"id":209,"name":"Travel Channel", "logo": "https://i.imgur.com/mWXv7SF.png"},{"id":213, "name":"Netflix", "logo": "https://i.imgur.com/jI5c3bw.png"},
        {"id":251,"name":"Audience", "logo": "https://i.imgur.com/5Q3mo5A.png"},{"id":270,"name":"SundanceTV", "logo": "https://i.imgur.com/qldG5p2.png"},{"id":318,"name":"Starz", "logo": "https://i.imgur.com/Z0ep2Ru.png"},{"id":173,"name":"AT-X", "logo": "https://i.imgur.com/JshJYGN.png"},
        {"id":359,"name":"Cinemax", "logo": "https://i.imgur.com/zWypFNI.png"},{"id":364,"name":"truTV", "logo": "https://i.imgur.com/HnB3zfc.png"},{"id":384,"name":"Hallmark Channel", "logo": "https://i.imgur.com/zXS64I8.png"},
        {"id":397,"name":"TV Land", "logo": "https://i.imgur.com/1nIeDA5.png.png"},{"id":1024,"name":"Amazon", "logo": "https://i.imgur.com/ru9DDlL.png"},{"id":1267,"name":"Freeform", "logo": "https://i.imgur.com/f9AqoHE.png"},{"id":64,"name":"Discovery Channel", "logo": "https://i.imgur.com/8UrXnAB.png"},
        {"id":4,"name":"BBC One", "logo": "https://i.imgur.com/u8x26te.png"},{"id":332,"name":"BBC Two", "logo": "https://i.imgur.com/SKeGH1a.png"},{"id":3,"name":"BBC Three", "logo": "https://i.imgur.com/SDLeLcn.png"},
        {"id":100,"name":"BBC Four", "logo": "https://i.imgur.com/PNDalgw.png"},{"id":214,"name":"Sky One", "logo": "https://i.imgur.com/xbgzhPU.png"},{"id":9,"name":"ITV", "logo": "https://i.imgur.com/5Hxp5eA.png"},{"id":26,"name":"Channel 4", "logo": "https://i.imgur.com/6ZA9UHR.png"},
        {"id":99,"name":"Channel 5", "logo": "https://i.imgur.com/5ubnvOh.png"},{"id":136,"name":"E4", "logo": "https://i.imgur.com/frpunK8.png"},{"id":210,"name":"HGTV", "logo": "https://i.imgur.com/INnmgLT.png"}]
        for item in sorted(networks, key=lambda k: k['name']):
            self.add_dir({'mode': 'build_tvshow_list', 'action': 'tmdb_tv_networks', 'network_id': item['id'], 'foldername': item['name'], 'list_name': '%s %s Network' % ('Tvshows', item['name']), 'info': 'Browse %s Network.'% item['name']}, item['name'], iconImage=item['logo'])
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def trakt_mosts(self):
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        final_mode = 'build_movie_list' if params.get('menu_type') == 'movie' else 'build_tvshow_list'
        action = 'trakt_movies_mosts' if params.get('menu_type') == 'movie' else 'trakt_tv_mosts'
        trakt_mosts = {'Most Played': ['played', 'most__played.png'],
        'Most Collected': ['collected', 'most__collected.png'],
        'Most Watched': ['watched', 'most__watched.png']}
        for most, value in trakt_mosts.items():
            self.add_dir({'mode': 'navigator.trakt_mosts_duration', 'action': action, 'period': value[0], 'menu_type': params.get('menu_type'), 'final_mode': final_mode, 'iconImage': value[1], 'foldername': most, 'list_name': '%ss %s' % ((params.get('menu_type')).capitalize(), most), 'info': 'Trakt %s for %ss.'% (most, (params.get('menu_type')).capitalize())}, most, iconImage=value[1])
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def trakt_mosts_duration(self):
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        durations = [('This Week', 'weekly'), ('This Month', 'monthly'), ('This Year', 'yearly'), ('All Time', 'all')]
        for duration, urlitem in durations:
            self.add_dir({'mode': params['final_mode'], 'action': params['action'], 'period': params['period'], 'duration': urlitem, 'foldername': duration, 'list_name': '%ss Most %s %s' % ((params.get('menu_type')).capitalize(), params.get('period').capitalize(), duration), 'info': 'Trakt Most %s for %s.' % (params.get('period').capitalize(), duration)}, '[B]MOST %s:[/B] %s' % (params.get('period').upper(), duration), iconImage=params['iconImage'])
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def downloads(self):
        def make_down_directory(isFolder=True):
                url = os.path.join(DOWNLOAD_PATH, item)
                listitem = xbmcgui.ListItem(item)
                listitem.setInfo('video', {'title': item})
                return xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=listitem, isFolder=isFolder)
        DOWNLOAD_PATH = settings.download_directory()
        xbmcplugin.setContent(__handle__, 'files')
        try:
            dirs, files = xbmcvfs.listdir(DOWNLOAD_PATH)
            for item in dirs: make_down_directory()
            for item in files: make_down_directory(False)
        except: pass
        xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_FULLPATH)
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def furk(self):
        self.add_dir({'mode': 'furk.my_furk_files', 'db_type': 'video', 'foldername': 'My Furk Video Files', 'list_name': 'Furk Video Files', 'info': 'Browse Furk Video files saved to My Files in Furk.'}, 'My Furk Video Files', iconImage='lists.png')
        self.add_dir({'mode': 'furk.my_furk_files', 'db_type': 'audio', 'foldername': 'My Furk Audio Files', 'list_name': 'Furk Audio Files', 'info': 'Browse Furk Audio files saved to My Files in Furk.'}, 'My Furk Audio Files', iconImage='lists.png')
        self.add_dir({'mode': 'furk.search_furk', 'db_type': 'video', 'foldername': 'Search Furk (Video)', 'list_name': 'Furk Search Video', 'info': 'Search Furk for Video files'}, 'Search Furk (Video)', iconImage='search.png')
        self.add_dir({'mode': 'furk.search_furk', 'db_type': 'audio', 'foldername': 'Search Furk (Audio)', 'list_name': 'Furk Search Audio', 'info': 'Search Furk for Audio files'}, 'Search Furk (Audio)', iconImage='search.png')
        self.add_dir({'mode': 'search_history', 'action': 'video', 'foldername': 'Video Search History', 'list_name': 'Furk Search History (Video)', 'info': 'Browse a History of Furk Video Searches. The last 10 searches are stored.'}, 'Search History (Video)', iconImage='search.png')
        self.add_dir({'mode': 'search_history', 'action': 'audio', 'foldername': 'Audio Search History', 'list_name': 'Furk Search History (Audio)', 'info': 'Browse a History of Furk Audio Searches. The last 10 searches are stored.'}, 'Search History (Audio)', iconImage='search.png')
        self.add_dir({'mode': 'furk.account_info', 'foldername': 'Account Info', 'list_name': 'Furk Account Info', 'info': 'Summary of information available from your Furk Account. Includes days remaining and current plan.'}, 'Account Info', iconImage='furk.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def favourites(self):
        self.add_dir({'mode': 'build_movie_list', 'action': 'favourites_movies', 'foldername': 'Movie Favourites', 'list_name': 'Movies Favourites', 'info': 'Browse Furk It Movie Favourites.'}, '[B]FAVOURITES : [/B]Movies', iconImage='movies.png')
        self.add_dir({'mode': 'build_tvshow_list', 'action': 'favourites_tvshows', 'foldername': 'TV Show Favourites', 'list_name': 'Tvshows Favourites', 'info': 'Browse Furk It TV Show Favourites.'}, '[B]FAVOURITES : [/B]TV Shows', iconImage='tv.png')
        self.add_dir({'mode': 'my_furk_audio_favourites', 'foldername': 'Audio Favourites', 'list_name': 'Audio Favourites', 'info': 'Browse Furk It Audio Favourites.'}, '[B]FAVOURITES : [/B]Music', iconImage='genre_music.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def subscriptions(self):
        self.add_dir({'mode': 'build_movie_list', 'action': 'subscriptions_movies', 'foldername': 'Furk It Subscriptions', 'list_name': 'Movies Subscriptions', 'info': 'Browse Furk It Movies in Subscriptions.'}, '[B]SUBSCRIPTIONS : [/B]Movies', iconImage='movies.png')
        self.add_dir({'mode': 'build_tvshow_list', 'action': 'subscriptions_tvshows', 'foldername': 'Furk It Subscriptions', 'list_name': 'Tvshows Subscriptions', 'info': 'Browse Furk It TV Shows in Subscriptions.'}, '[B]SUBSCRIPTIONS : [/B]TV Shows', iconImage='tv.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def kodi_library(self):
        self.add_dir({'mode': 'build_movie_list', 'action': 'kodi_library_movies', 'foldername': 'Movies Kodi Library', 'list_name': 'Movies Kodi Library', 'info': 'Browse Movies from your Local Kodi Library.'}, '[B]KODI LIBRARY : [/B]Movies', iconImage='movies.png')
        self.add_dir({'mode': 'build_tvshow_list', 'action': 'kodi_library_tvshows', 'foldername': 'TV Shows Kodi Library', 'list_name': 'Tvshows Kodi Library', 'info': 'Browse TV Shows from your Local Kodi Library.'}, '[B]KODI LIBRARY : [/B]TV Shows', iconImage='tv.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def in_progress(self):
        self.add_dir({'mode': 'build_movie_list', 'action': 'in_progress_movies', 'foldername': 'Movies In Progress', 'list_name': 'Movies In Progress', 'info': 'Browse Movies that are in the process of being watched.'}, '[B]IN PROGRESS : [/B]Movies', iconImage='movies.png')
        self.add_dir({'mode': 'build_tvshow_list', 'action': 'in_progress_tvshows', 'foldername': 'TV Shows In Progress', 'list_name': 'Tvshows In Progress', 'info': 'Browse TV Shows that are in the process of being watched.'}, '[B]IN PROGRESS : [/B]TV Shows', iconImage='tv.png')
        self.add_dir({'mode': 'build_in_progress_episode', 'foldername': 'Episodes In Progress', 'list_name': 'Episodes In Progress', 'info': 'Browse Episodes that are in the process of being watched.'}, '[B]IN PROGRESS : [/B]Episodes', iconImage='episode.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def watched(self):
        self.add_dir({'mode': 'build_movie_list', 'action': 'watched_movies', 'foldername': 'Furk It Watched Movies', 'list_name': 'Movies Watched', 'info': 'Browse Movies watched in Furk It.'}, '[B]WATCHED : [/B]Movies', iconImage='movies.png')
        self.add_dir({'mode': 'build_tvshow_list', 'action': 'watched_tvshows', 'foldername': 'Furk It Watched Shows', 'list_name': 'Tvshows Watched', 'info': 'Browse TV Shows watched in Furk It.'}, '[B]WATCHED : [/B]TV Shows', iconImage='tv.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def my_trakt_content(self):
        self.add_dir({'mode': 'navigator.trakt_collection', 'foldername': 'My Trakt Collections', 'list_name': 'Trakt My Collections', 'info': 'Browse your Trakt Collections.'}, 'My Trakt Collections', iconImage='traktcollection.png')
        self.add_dir({'mode': 'navigator.trakt_watchlist', 'foldername': 'My Trakt Watchlists', 'list_name': 'Trakt My Watchlists', 'info': 'Browse your Trakt Watchlists.'}, 'My Trakt Watchlists', iconImage='traktwatchlist.png')
        self.add_dir({'mode': 'trakt.get_trakt_my_lists', 'foldername': 'My Trakt Lists', 'list_name': 'Trakt My Lists', 'info': 'Browse your Trakt Lists.'}, 'My Trakt Lists', iconImage='traktmylists.png')
        self.add_dir({'mode': 'trakt.get_trakt_liked_lists', 'foldername': 'My Trakt Liked Lists', 'list_name': 'Trakt My Liked Lists', 'info': 'Browse your Trakt Liked Lists.'}, 'My Trakt Liked Lists', iconImage='traktlikedlists.png')
        self.add_dir({'mode': 'navigator.trakt_recommendations', 'foldername': 'My Trakt Recommended Lists', 'list_name': 'Trakt My Recommended Lists', 'info': 'Browse your Trakt Recommended Lists.'}, 'My Trakt Recommended Lists', iconImage='traktrecommendations.png')
        self.add_dir({'mode': 'trakt.search_trakt_lists', 'foldername': 'Search Trakt Lists', 'list_name': 'Trakt Search Lists', 'info': 'Search Trakt for Lists.'}, 'Search Trakt Lists', iconImage='search_trakt_lists.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def trakt_collection(self):
        self.add_dir({'mode': 'build_movie_list', 'action': 'trakt_collection', 'foldername': 'My Trakt Movie Collection', 'list_name': 'Movies Trakt Collection', 'info': 'Access your Trakt Movie Collection.'}, 'My Movie Collection', iconImage='movies.png')
        self.add_dir({'mode': 'build_tvshow_list', 'action': 'trakt_collection', 'foldername': 'My Trakt TV Show Collection', 'list_name': 'Tvshows Trakt Collection', 'info': 'Access your Trakt TV Show Collection.'}, 'My TV Show Collection', iconImage='tv.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def trakt_watchlist(self):
        self.add_dir({'mode': 'build_movie_list', 'action': 'trakt_watchlist', 'foldername': 'My Trakt Movie Watchlist', 'list_name': 'Movies Trakt Watchlist', 'info': 'Access your Trakt Movie Watchlist.'}, 'My Movie Watchlist', iconImage='movies.png')
        self.add_dir({'mode': 'build_tvshow_list', 'action': 'trakt_watchlist', 'foldername': 'My Trakt TV Show Watchlist', 'list_name': 'Tvshows Trakt Watchlist', 'info': 'Access your Trakt TV Show Watchlist.'}, 'My TV Show Watchlist', iconImage='tv.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def trakt_recommendations(self):
        self.add_dir({'mode': 'build_movie_list', 'action': 'trakt_recommendations', 'foldername': 'My Trakt Movie Recommendations', 'list_name': 'Trakt My Movie Recommendations', 'info': 'Access your Trakt Movie Recommendations.'}, 'My Trakt Movie Recommendations', iconImage='movies.png')
        self.add_dir({'mode': 'build_tvshow_list', 'action': 'trakt_recommendations', 'foldername': 'My Trakt TV Show Recommendations', 'list_name': 'Trakt My TV Show Recommendations', 'info': 'Access your Trakt TV Show Recommendations.'}, 'My Trakt TV Show Recommendations', iconImage='tv.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def search(self):
        self.add_dir({'mode': 'build_movie_list', 'action': 'tmdb_movies_search', 'query': 'NA', 'foldername': 'Movies', 'variable': '$INFO[System.TotalUptime]', 'info': 'Search Movies.', 'list_name': 'Search Movies'}, '[B]SEARCH : [/B]Movies', iconImage='search_movie.png')
        self.add_dir({'mode': 'build_tvshow_list', 'action': 'tmdb_tv_search', 'query': 'NA', 'foldername': 'TV Shows', 'variable': '$INFO[System.TotalUptime]', 'info': 'Search TV Shows.', 'list_name': 'Search TV Shows'}, '[B]SEARCH : [/B]TV Shows', iconImage='search_tv.png')
        self.add_dir({'mode': 'build_movie_list', 'action': 'tmdb_movies_people_search', 'query': 'NA', 'foldername': 'People - Movies', 'variable': '$INFO[System.TotalUptime]', 'info': 'Search People (Movies).', 'list_name': 'Search People (Movies)'}, '[B]SEARCH : [/B]People (Movies)', iconImage='search_movies_people.png')
        self.add_dir({'mode': 'build_tvshow_list', 'action': 'tmdb_tv_people_search', 'query': 'NA', 'foldername': 'People - TV Shows', 'variable': '$INFO[System.TotalUptime]', 'info': 'Search People (TV Shows).', 'list_name': 'Search People (TV Shows)'}, '[B]SEARCH : [/B]People (TV Shows)', iconImage='search_tv_shows_people.png')
        self.add_dir({'mode': 'furk.search_furk', 'db_type': 'video', 'foldername': 'Search Furk (Video)', 'variable': '$INFO[System.TotalUptime]', 'info': 'Search Furk Video files.', 'list_name': 'Search Furk (Video)'}, '[B]SEARCH : [/B]Furk (Video)', iconImage='search_furk.png')
        self.add_dir({'mode': 'furk.search_furk', 'db_type': 'audio', 'foldername': 'Search Furk (Audio)', 'variable': '$INFO[System.TotalUptime]', 'info': 'Search Furk Audio files.', 'list_name': 'Search Furk (Audio)'}, '[B]SEARCH : [/B]Furk (Audio)', iconImage='search_furk.png')
        self.add_dir({'mode': 'search_history', 'action': 'movie', 'foldername': 'Movie Search', 'info': 'Browse Movie Search History.', 'list_name': 'Search History Movies'}, '[B]HISTORY : [/B]Movie Search', iconImage='search.png')
        self.add_dir({'mode': 'search_history', 'action': 'tvshow', 'foldername': 'TV Show Search', 'info': 'Browse TV Show Search History.', 'list_name': 'Search History TV Show Search'}, '[B]HISTORY : [/B]TV Show Search', iconImage='search.png')
        self.add_dir({'mode': 'search_history', 'action': 'video', 'foldername': 'Furk Video Search History', 'info': 'Browse Furk Video Search History.', 'list_name': 'Search History Furk (Video)'}, '[B]HISTORY : [/B]Furk Search (Video)', iconImage='search.png')
        self.add_dir({'mode': 'search_history', 'action': 'audio', 'foldername': 'Furk Audio Search History', 'info': 'Browse Furk Audio Search History.', 'list_name': 'Search History Furk (Audio)'}, '[B]HISTORY : [/B]Furk Search (Audio)', iconImage='search.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def tools(self):
        set_view_modes_menu = 'Set Furk It View Modes for all media and lists.'
        unaired_episode_color_choice = 'Choose display colour of unaired episodes.'
        next_episode_function_choice = 'Adjust settings related to Furk It Next Episode Function.'
        clear_favourites = 'Clear Furk It Movie - TV Show - Audio Favourites. This cannot be undone.'
        clear_subscriptions = 'Clear Furk It Movie or TV Show Subscriptions. This cannot be undone.'
        clear_search_history = 'Clear Furk It Movie - TV Show - Video or Audio Search History. This cannot be undone.'
        clear_meta_cache = 'Clear Furk It Meta Cache (Movie & TV Show Info and Artwork). This cannot be undone.'
        clear_list_cache = 'Clear Furk It List Cache (Furk It Menu Lists e.g. Trending). This cannot be undone.'
        remake_subscriptions = 'Remake Furk It .STRM files for Subscriptions.'
        update_tvshow_subscriptions = 'Manually Update all TV Show Subscriptions.'
        trakt_authenticate = 'Authenticate your Trakt account using device pairing. A code will appear which you must enter on the Trakt webpage.'
        furkit_trakt_resync = 'ReSync Furk It Watched Info with Trakt Watched Info.'
        display_time = '[COLOR=grey]   (%s)[/COLOR]' % str(__addon__.getSetting('service_time'))
        self.add_dir({'mode': 'navigator.set_view_modes', 'foldername': 'Set Views', 'list_name': 'Tools Set Views', 'info': set_view_modes_menu}, '[B]TOOLS : [/B]Set Views', iconImage='settings2.png')
        self.add_dir({'mode': 'unaired_episode_color_choice', 'foldername': 'Choose Unaired Episodes Highlight Colour', 'list_name': 'Tools Choose Unaired Episodes Highlight Colour', 'info': unaired_episode_color_choice}, '[B]TOOLS : [/B]Choose Unaired Episodes Highlight Colour', iconImage='settings2.png')
        self.add_dir({'mode': 'navigator.next_episode_choice', 'foldername': 'Manage Next Episode Options', 'list_name': 'Tools Manage Next Episode Options', 'info': next_episode_function_choice}, '[B]TOOLS : [/B]Manage Next Episode Options', iconImage='settings2.png')
        self.add_dir({'mode': 'clear_favourites', 'foldername': 'Clear Furk It Favourites', 'list_name': 'Tools Clear Furk It Favourites', 'info': clear_favourites}, '[B]TOOLS : [/B]Clear Furk It Favourites', iconImage='settings2.png')
        self.add_dir({'mode': 'clear_subscriptions', 'foldername': 'Clear Furk It Subscriptions', 'list_name': 'Tools Clear Furk It Subscriptions', 'info': clear_subscriptions}, '[B]TOOLS : [/B]Clear Furk It Subscriptions', iconImage='settings2.png')
        self.add_dir({'mode': 'clear_search_history', 'foldername': 'Clear Search History', 'list_name': 'Tools Clear Search History', 'info': clear_search_history}, '[B]TOOLS : [/B]Clear Search History', iconImage='settings2.png')
        self.add_dir({'mode': 'clear_cache', 'cache': 'meta', 'foldername': 'Clear Meta Cache', 'list_name': 'Tools Clear Meta Cache', 'info': clear_meta_cache}, '[B]TOOLS : [/B]Clear Meta Cache', iconImage='settings2.png')
        self.add_dir({'mode': 'clear_cache', 'cache': 'list', 'foldername': 'Clear List Cache', 'list_name': 'Tools Clear List Cache', 'info': clear_list_cache}, '[B]TOOLS : [/B]Clear List Cache', iconImage='settings2.png')
        self.add_dir({'mode': 'remake_subscriptions', 'foldername': 'Remake Furk It Subscriptions Stream Files', 'list_name': 'Tools Remake Furk It Subscriptions Stream Files', 'info': remake_subscriptions}, '[B]TOOLS : [/B]Remake Furk It Subscriptions Stream Files', iconImage='settings2.png')
        self.add_dir({'mode': 'update_subscriptions', 'foldername': 'Update Subscriptions', 'list_name': 'Tools Update Subscriptions %s' % display_time, 'info': update_tvshow_subscriptions}, '[B]TOOLS : [/B]Update Subscriptions %s' % display_time, iconImage='settings2.png')
        if settings.watched_indicators() == 1: self.add_dir({'mode': 'trakt_sync_watched_to_furkit', 'refresh': True, 'foldername': 'ReSync Furk It Watched to Trakt Watched', 'list_name': '[B]Tools[/B] - ReSync Furk It Watched to Trakt Watched', 'info': furkit_trakt_resync}, '[B]TRAKT : [/B]ReSync Furk It Watched to Trakt Watched', iconImage='settings2.png')
        self.add_dir({'mode': 'trakt_authenticate', 'foldername': '(Re)Authenticate Trakt', 'list_name': 'Tools (Re)Authenticate Trakt', 'info': trakt_authenticate}, '[B]TRAKT : [/B](Re)Authenticate Trakt', iconImage='settings2.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def settings(self):
        self.add_dir({'mode': 'open_settings', 'query': '0.2', 'foldername': 'Accounts', 'list_name': 'Settings Accounts', 'info': 'Access Account Settings.'}, '[B]SETTINGS : [/B]Accounts', iconImage='settings.png')
        self.add_dir({'mode': 'open_settings', 'query': '1.3', 'foldername': 'Appearance', 'list_name': 'Settings Appearance', 'info': 'Access Appearance Settings.'}, '[B]SETTINGS : [/B]Appearance', iconImage='settings.png')
        self.add_dir({'mode': 'open_settings', 'query': '2.3', 'foldername': 'Search Providers', 'list_name': 'Settings Search Providers', 'info': 'Access Search Provider Settings.'}, '[B]SETTINGS : [/B]Search Providers', iconImage='settings.png')
        self.add_dir({'mode': 'open_settings', 'query': '3.2', 'foldername': 'Playback', 'list_name': 'Settings Playback', 'info': 'Access Playback Settings.'}, '[B]SETTINGS : [/B]Playback', iconImage='settings.png')
        self.add_dir({'mode': 'open_settings', 'query': '3.16', 'foldername': 'Library Playback', 'list_name': 'Settings Library Playback', 'info': 'Access Library Playback Settings.'}, '[B]SETTINGS : [/B]Library Playback', iconImage='settings.png')
        self.add_dir({'mode': 'open_settings', 'query': '4.3', 'foldername': 'Watched Status', 'list_name': 'Settings Watched Status', 'info': 'Access Indicators - Resume Status Settings.'}, '[B]SETTINGS : [/B]Watched Status', iconImage='settings.png')
        self.add_dir({'mode': 'open_settings', 'query': '5.2', 'foldername': 'Subscriptions', 'list_name': 'Settings Subscriptions', 'info': 'Access Subscriptions Settings.'}, '[B]SETTINGS : [/B]Subscriptions', iconImage='settings.png')
        self.add_dir({'mode': 'open_settings', 'query': '1.15', 'foldername': 'Downloads', 'list_name': 'Settings Downloads', 'info': 'Access Download Settings.'}, '[B]SETTINGS : [/B]Downloads', iconImage='settings.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def next_episode_choice(self):
        self.add_dir({'mode': 'build_next_episode_manager', 'action': 'manage_in_progress', 'foldername': 'Manage In Progress Shows', 'list_name': 'Manage In Progress Shows', 'info': 'Manage In Progress Shows.'}, '[B]SETTINGS : [/B]Manage In Progress Shows', iconImage='settings.png')
        self.add_dir({'mode': 'build_next_episode_manager', 'action': 'manage_unwatched', 'foldername': 'Manage Unwatched Shows', 'list_name': 'Manage Unwatched Shows', 'info': 'Manage Unwatched Shows.'}, '[B]SETTINGS : [/B]Manage Unwatched Shows', iconImage='settings.png')
        self.add_dir({'mode': 'open_settings', 'query': '1.12', 'foldername': 'Manage Sort Order', 'list_name': 'Manage Sort Order', 'info': 'Sort Episodes by Recently Watched or Airdate.'}, '[B]SETTINGS : [/B]Manage Sort Order', iconImage='settings.png')
        self.add_dir({'mode': 'next_episode_unwatched_highlight_choice', 'foldername': 'Manage Unwatched Colour Highlights', 'list_name': 'Manage Unwatched Colour Highlights', 'info': 'Manage Unwatched Colour Highlights.'}, '[B]SETTINGS : [/B]Manage Unwatched Colour Highlights', iconImage='settings.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def set_view_modes(self):
        self.add_dir({'mode': 'navigator.view_chooser', 'view_setting_id': 'view.main', 'title': 'Set Main List View', 'view_type': 'files', 'exclude_external': 'true', 'info': 'Set Main List View.'},'[B]SET VIEW : [/B]Main List', iconImage='settings.png')
        self.add_dir({'mode': 'navigator.view_chooser', 'view_setting_id': 'view.furk_files', 'title': 'Set Furk Files View', 'view_type': 'files', 'exclude_external': 'true', 'info': 'Set Furk Files View.'},'[B]SET VIEW : [/B]Furk Files', iconImage='settings.png')
        self.add_dir({'mode': 'navigator.view_chooser', 'view_setting_id': 'view.movies', 'title': 'Set Movies View', 'view_type': 'movies', 'exclude_external': 'true', 'info': 'Set Movies View.'},'[B]SET VIEW : [/B]Movies', iconImage='settings.png')
        self.add_dir({'mode': 'navigator.view_chooser', 'view_setting_id': 'view.tvshows', 'title': 'Set TV Show View', 'view_type': 'tvshows', 'exclude_external': 'true', 'info': 'Set TV Show View.'},'[B]SET VIEW : [/B]TV Shows', iconImage='settings.png')
        self.add_dir({'mode': 'navigator.view_chooser', 'view_setting_id': 'view.seasons', 'title': 'Set Seasons View', 'view_type': 'seasons', 'exclude_external': 'true', 'info': 'Set Seasons View.'},'[B]SET VIEW : [/B]Seasons', iconImage='settings.png')
        self.add_dir({'mode': 'navigator.view_chooser', 'view_setting_id': 'view.episodes', 'title': 'Set Episodes View', 'view_type': 'episodes', 'exclude_external': 'true', 'info': 'Set Episodes View.'},'[B]SET VIEW : [/B]Episodes', iconImage='settings.png')
        self.add_dir({'mode': 'navigator.view_chooser', 'view_setting_id': 'view.progress_next_episode', 'title': 'Set Progress/Next Episode View', 'view_type': 'episodes', 'exclude_external': 'true', 'info': 'Set Progress/Next Episode View'},'[B]SET VIEW : [/B]Progress/Next Episode', iconImage='settings.png')
        self.add_dir({'mode': 'navigator.view_chooser', 'view_setting_id': 'view.trakt_list', 'title': 'Set Trakt Lists View', 'view_type': 'videos', 'exclude_external': 'true', 'info': 'Set Trakt Lists View.'},'[B]SET VIEW : [/B]Trakt Lists', iconImage='settings.png')
        self.add_dir({'mode': 'navigator.view_chooser', 'view_setting_id': 'view.media_results', 'title': 'Set Media Results View', 'view_type': 'files', 'exclude_external': 'true', 'info': 'Set Media Results View.'},'[B]SET VIEW : [/B]Media Results', iconImage='settings.png')
        self.add_dir({'mode': 'navigator.view_chooser', 'view_setting_id': 'view.pack_results', 'title': 'Set PACK Results View', 'view_type': 'files', 'exclude_external': 'true', 'info': 'Set PACK Results View.'},'[B]SET VIEW : [/B]PACK Results', iconImage='settings.png')
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def view_chooser(self):
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        xbmcplugin.setContent(__handle__, params.get('view_type'))
        self.add_dir({'mode': 'navigator.set_views', 'view_setting_id': params.get('view_setting_id'), 'title': params.get('title'), 'view_type': params.get('view_type'), 'exclude_external': 'true'}, 'Set view and then click here', iconImage='settings.png')
        xbmcplugin.endOfDirectory(__handle__)
        self._setView(params.get('view_setting_id'))

    def set_views(self):
        from resources.lib.modules.nav_utils import notification
        VIEWS_DB = os.path.join(profile_dir, "views.db")
        settings.check_database(VIEWS_DB)
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        view_type = params.get('view_setting_id')
        view_id = str(xbmcgui.Window(xbmcgui.getCurrentWindowId()).getFocusId())
        dbcon = database.connect(VIEWS_DB)
        dbcon.execute("DELETE FROM views WHERE view_type = '%s'" % (str(view_type)))
        dbcon.execute("INSERT INTO views VALUES (?, ?)", (str(view_type), str(view_id)))
        dbcon.commit()
        notification("%s set to %s" % (params.get('title')[3:], xbmc.getInfoLabel('Container.Viewmode').upper()), time=2000)

    def add_dir(self, url_params, list_name, iconImage='DefaultFolder.png', isFolder=True):
        cmenu = []
        icon = iconImage if 'network_id' in url_params else os.path.join(self.icon_directory, iconImage)
        info = url_params.get('info', '')
        url_params['iconImage'] = icon
        url = self._build_url(url_params)
        listitem = xbmcgui.ListItem(list_name, iconImage=icon)
        listitem.setArt({'fanart': self.fanart})
        listitem.setInfo('video', {'title': list_name, 'plot': info})
        if not 'exclude_external' in url_params:
            cmenu.append(("[B]Add[/B] Item [B]to a Menu[/B]",'XBMC.RunPlugin(%s)'% self.dump_menu_item(url_params)))
            cmenu.append(("[B]Add[/B] to [B]Menu Favourites[/B]",'XBMC.RunPlugin(%s)'% self.dump_menu_item(url_params, favourite=True)))
            listitem.addContextMenuItems(cmenu, replaceItems=False)
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=listitem, isFolder=isFolder)

    def adjust_main_lists(self):
        def db_execute():
            dbcon = database.connect(NAVIGATOR_DB)
            if list_name == 'FavouriteList':
                dbcon.execute("DELETE FROM navigator_favourites")
                dbcon.execute("INSERT INTO navigator_favourites VALUES (?)", (json.dumps(li),))
            else:
                dbcon.execute("DELETE FROM navigator where list_name=? and list_type=?", (list_name, 'edited'))
                dbcon.execute("INSERT INTO navigator VALUES (?, ?, ?)", (list_name, 'edited', json.dumps(li)))
            dbcon.commit()
        def menu_select(heading, position_list=False):
            for item in choice_items:
                line = 'Place [B]%s[/B] below [B]%s[/B]' % (menu_name, item['name']) if position_list else item['info']
                icon = item.get('iconImage') if item.get('network_id', '') != '' else os.path.join(self.icon_directory, item.get('iconImage'))
                listitem = xbmcgui.ListItem(item['name'], line, iconImage=icon)
                choice_list.append(listitem)
            if position_list: choice_list.insert(0, xbmcgui.ListItem('Top Position', 'Place [B]%s[/B] at Top of List' % menu_name, iconImage=os.path.join(self.icon_directory, 'furk.png')))
            return dialog.select(heading, choice_list, useDetails=True)
        from resources.lib.modules.nav_utils import notification
        dialog = xbmcgui.Dialog()
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        menu_name = params.get('menu_name', '')
        list_name = params.get('list_name', '')
        li = None
        method = params.get('method')
        choice_list = []
        try:
            if list_name == 'FavouriteList':
                current_position = int(params.get('position', '0'))
                li = self.get_favourites_list()
                root_default_list, root_edited_list = self._db_lists('RootList')
                root_def_file = root_default_list if not root_edited_list else root_edited_list
                root_li, root_def_li = root_def_file, root_default_list
                choice_items = root_li
            else:
                current_position = int(params.get('position', '0'))
                default_list, edited_list = self._db_lists(list_name)
                def_file = default_list if not edited_list else edited_list
                li, def_li = def_file, default_list
                choice_items = [i for i in def_li if i not in li]
        except: pass
        try:
            if method == 'move':
                choice_items = [i for i in li if i['name'] != menu_name]
                new_position = menu_select('Choose New Position of Menu Item (Insert Below Chosen Item)...', position_list=True)
                if new_position < 0 or new_position == current_position: return
                li.insert(new_position, li.pop(current_position))
                db_execute()
            elif method == 'remove':
                li = [x for x in li if x['name'] != menu_name]
                db_execute()
            elif method == 'add':
                selection = menu_select("Choose item to add to menu")
                if selection < 0: return
                selection = choice_items[selection]
                choice_list = []
                choice_items = li
                item_position = menu_select('Choose Insert Position of Menu Item (Insert Below Chosen Item)...', position_list=True)
                if item_position < 0: return
                li.insert((item_position), selection)
                db_execute()
            elif method == 'add_external':
                choice_items = self.select_from_main_menus(params.get('list_name'), params.get('item_name'))
                selection = menu_select("Choose Menu to add %s List Item Into.." % params.get('item_name'))
                if selection < 0: return
                add_to_menu_choice = choice_items[selection]
                list_name = add_to_menu_choice['action']
                default_list, edited_list = self._db_lists(list_name)
                def_file = default_list if not edited_list else edited_list
                li = def_file
                menu_item = self.make_menu_item(params)
                if not menu_item or menu_item in li: return
                choice_list = []
                choice_items = li
                item_position = menu_select('Choose Insert Position of Menu Item (Insert Below Chosen Item)...', position_list=True)
                if item_position < 0: return
                li.insert((item_position), menu_item)
                db_execute()
            elif method == 'add_favourite':
                list_name = 'FavouriteList'
                li = self.get_favourites_list()
                li = [i for i in li if i['name'] != 'Information']
                menu_item = self.make_menu_item(params)
                if not menu_item or menu_item in li: return
                choice_list = []
                choice_items = li
                item_position = 0 if len(li) == 0 else menu_select('Choose Insert Position of Menu Item (Insert Below Chosen Item)...', position_list=True)
                if item_position < 0: return
                li.insert((item_position), menu_item)
                db_execute()
                __addon__.setSetting('favourites_enabled', 'true')
            elif method == 'add_trakt':
                from resources.lib.modules.trakt import get_trakt_list_selection
                trakt_selection = json.loads(params['trakt_selection']) if 'trakt_selection' in params else get_trakt_list_selection(list_choice=True)
                if not trakt_selection: return
                name = dialog.input('Choose Display Name', type=xbmcgui.INPUT_ALPHANUM, defaultt=trakt_selection['name'])
                if not name: return
                choice_list = []
                choice_items = li
                item_position = menu_select('Choose Insert Position of Menu Item (Insert Below Chosen Item)...', position_list=True)
                if item_position < 0: return
                li.insert(item_position, {"iconImage": "traktmylists.png", "mode": "trakt.build_trakt_list", "name": name, "foldername": name, "user": trakt_selection['user'], "slug": trakt_selection['slug'], 'external_list_item': True, "info": '%s (Trakt List item).' % name})
                db_execute()
            elif method == 'add_trakt_external':
                name = dialog.input('Choose Display Name', type=xbmcgui.INPUT_ALPHANUM, defaultt=params['name'])
                if not name: return
                if list_name == 'FavouriteList':
                    li = [i for i in li if i['name'] != 'Information']
                if not li and list_name != 'FavouriteList':
                    choice_items = self.select_from_main_menus()
                    selection = menu_select("Choose Menu to add %s  Into.." % name)
                    if selection < 0: return
                    add_to_menu_choice = choice_items[selection]
                    list_name = add_to_menu_choice['action']
                    default_list, edited_list = self._db_lists(list_name)
                    li = default_list if not edited_list else edited_list
                if name in [i['name'] for i in li]: return
                choice_list = []
                choice_items = li
                item_position = 0 if len(li) == 0 else menu_select('Choose Insert Position of Menu Item (Insert Below Chosen Item)...', position_list=True)
                if item_position < 0: return
                if list_name == 'FavouriteList': __addon__.setSetting('favourites_enabled', 'true')
                li.insert(item_position, {"iconImage": "traktmylists.png", "mode": "trakt.build_trakt_list", "name": name, "foldername": name, "user": params['user'], "slug": params['slug'], 'external_list_item': True, "info": '%s (Trakt List item).' % name})
                db_execute()
            elif method == 'browse':
                heading = "Choose Removed Item to Browse Into.." if not list_name == 'FavouriteList' else "Choose Root Menu Item to Browse Into.."
                selection = menu_select(heading)
                if selection < 0: return
                mode, action, url_mode, menu_type, query = choice_items[selection]['mode'] if 'mode' in choice_items[selection] else '', choice_items[selection]['action'] if 'action' in choice_items[selection] else '', choice_items[selection]['url_mode'] if 'url_mode' in choice_items[selection] else '', choice_items[selection]['menu_type'] if 'menu_type' in choice_items[selection] else '', choice_items[selection]['query'] if 'query' in choice_items[selection] else ''
                xbmc.executebuiltin("XBMC.Container.Update(%s)" % self._build_url({'mode': mode, 'action': action, 'url_mode': url_mode, 'menu_type': menu_type, 'query': query}))
            elif method == 'reload_menu_item':
                default = eval('DefaultMenus().%s()' % list_name)
                default_item = [i for i in default if i['name'] == menu_name][0]
                li = [default_item if x['name'] == menu_name else x for x in def_file]
                list_type = 'edited' if self._db_lists(list_name)[1] else 'default'
                dbcon = database.connect(NAVIGATOR_DB)
                dbcon.execute("DELETE FROM navigator where list_name=? and list_type=?", (list_name, list_type))
                dbcon.execute("INSERT INTO navigator VALUES (?, ?, ?)", (list_name, list_type, json.dumps(li)))
                dbcon.commit()
            elif method == 'restore':
                confirm = dialog.yesno('Are you sure?', 'Continuing will Clear your Favourite Menus.' if list_name == 'FavouriteList' else 'Continuing will load the default Menu.')
                if not confirm: return
                dbcon = database.connect(NAVIGATOR_DB)
                if list_name == 'FavouriteList':
                    dbcon.execute("DELETE FROM navigator_favourites;")
                    __addon__.setSetting('favourites_enabled', 'false')
                    __addon__.setSetting('favourites_default', 'false')
                else:
                    for item in ['edited', 'default']: dbcon.execute("DELETE FROM navigator where list_name=? and list_type=?", (list_name, item))
                    dbcon.execute("INSERT INTO navigator VALUES (?, ?, ?)", (list_name, 'default', json.dumps(eval('DefaultMenus().%s()' % list_name))))
                dbcon.commit()
            if not method in ['browse']:
                    xbmc.executebuiltin('Container.Refresh')
                    notification("Process Successful", time=1500)
        except: return

    def build_main_lists(self):
        self.default_list, self.edited_list = self._db_lists()
        self.default_menu = self.default_list if not self.edited_list else self.edited_list
        current_items_from_default = [i for i in self.default_menu if not i.get('external_list_item', False)]
        list_is_full = True if len(current_items_from_default) >= len(self.default_list) else False
        item_position = 0
        try:
            for item in self.default_menu:
                cmenu = []
                info = item.get('info', '')
                name = item.get('name', '')
                icon = item.get('iconImage') if item.get('network_id', '') != '' else os.path.join(self.icon_directory, item.get('iconImage'))
                url_params = {'mode': item.get('mode', ''), 'action': item.get('action', ''),
                    'query': item.get('query', ''), 'foldername': item.get('foldername', ''),
                    'url_mode': item.get('url_mode', ''), 'menu_type': item.get('menu_type', ''),
                    'user': item.get('user', ''), 'slug': item.get('slug', ''), 'type': item.get('db_type', ''),
                    'certification': item.get('certification', ''), 'language': item.get('language', ''),
                    'year': item.get('year', ''), 'genre_id': item.get('genre_id', ''), 'iconImage': icon,
                    'network_id': item.get('network_id', ''), 'period': item.get('period', ''),
                    'duration': item.get('duration', ''), 'final_mode': item.get('final_mode', ''),
                    'db_type': item.get('db_type', ''), 'refresh': item.get('refresh', '')}
                url = self._build_url(url_params)
                if len(self.default_menu) != 1: cmenu.append(("[B]Move[/B] Item",'XBMC.RunPlugin(%s)' % \
                    self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'move', 'list_name': self.list_name, 'menu_name': name, 'position': item_position})))
                if len(self.default_menu) != 1: cmenu.append(("[B]Remove[/B] Item",'XBMC.RunPlugin(%s)' % \
                    self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'remove', 'list_name': self.list_name, 'menu_name': name, 'position': item_position})))
                if not list_is_full: cmenu.append(("[B]Add Original[/B] Item",'XBMC.RunPlugin(%s)'% \
                    self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'add', 'list_name': self.list_name, 'position': item_position})))
                if not list_is_full: cmenu.append(("[B]Browse Removed[/B] Item",'XBMC.RunPlugin(%s)'% \
                    self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'browse', 'list_name': self.list_name, 'position': item_position})))
                if self.edited_list: cmenu.append(("[B]Restore Menu[/B] to Default",'XBMC.RunPlugin(%s)'% \
                    self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'restore', 'list_name': self.list_name, 'position': item_position})))
                cmenu.append(("[B]Add[/B] Item [B]to a Menu[/B]",'XBMC.RunPlugin(%s)'% self.dump_menu_item(item)))
                if not name == 'Menu Favourites': cmenu.append(("[B]Add[/B] to [B]Menu Favourites[/B]",'XBMC.RunPlugin(%s)'% self.dump_menu_item(item, favourite=True)))
                if self.list_name in ('RootList', 'MovieList', 'TVShowList', 'FavouriteList'): cmenu.append(("[B]Add Trakt List[/B] to Menu",'XBMC.RunPlugin(%s)'% \
                    self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'add_trakt', 'list_name': self.list_name, 'position': item_position})))
                if item.get('slug'): cmenu.append(("[B]Add Trakt List[/B] to Subscriptions",'XBMC.RunPlugin(%s)' % \
                    self._build_url({'mode': 'trakt.add_list_to_subscriptions', 'user': item.get('user', ''), 'list_slug': item.get('slug', '')})))
                if name == 'Menu Favourites': cmenu.append(("[B]Clear[/B] Favourites List",'XBMC.RunPlugin(%s)'% \
                    self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'restore', 'list_name': 'FavouriteList', 'position': item_position})))
                if not item.get('slug'): cmenu.append(("[B]Reload[/B] Item",'XBMC.RunPlugin(%s)' % \
                    self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'reload_menu_item', 'list_name': self.list_name, 'menu_name': name, 'position': item_position})))
                listitem = xbmcgui.ListItem(name, thumbnailImage=icon)
                listitem.setArt({'fanart': self.fanart})
                listitem.setInfo('video', {'title': name, 'plot': info})
                listitem.addContextMenuItems(cmenu)
                item_position += 1
                xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=True)
        except: return

    def select_from_main_menus(self, current_list=[], item_list=[]):
        include_list = DefaultMenus().DefaultMenuItems()
        menus = DefaultMenus().RootList()
        menus.insert(0, {'info': 'Furk It Root Menu.', 'name': 'Root', 'iconImage': 'furk.png', 'foldername': 'Root', 'mode': 'navigator.main', 'action': 'RootList'})
        include_list = [i for i in include_list if i != current_list]
        menus = [i for i in menus if i.get('action', None) in include_list and not i.get('name') == item_list]
        return menus

    def make_menu_item(self, params):
        dialog = xbmcgui.Dialog()
        name_append_list = [('RootList', ''), ('MovieList', 'Movies '), ('TVShowList', 'Tvshows '), ('AudioList', 'Audio ')]
        orig_name = params.get('list_name', None)
        try: name = '%s%s' % ([i[1] for i in name_append_list if i[0] == orig_name][0], params.get('item_name'))
        except: name = orig_name
        name = dialog.input('Choose Display Name', type=xbmcgui.INPUT_ALPHANUM, defaultt=name)
        if not name: return
        return {'info': params.get('item_info', ''), 'name': name, 'iconImage': params.get('item_iconImage', ''),
            'mode': params.get('item_mode', ''), 'action': params.get('item_action', ''),
            'query': params.get('item_query', ''), 'foldername': params.get('item_foldername', ''),
            'url_mode': params.get('item_url_mode', ''), 'menu_type': params.get('item_menu_type', ''),
            'user': params.get('item_user', ''), 'slug': params.get('item_slug', ''),
            'type': params.get('item_db_type', ''), 'external_list_item': True, 'year': params.get('item_year', ''),
            'certification': params.get('item_certification', ''), 'language': params.get('item_language', ''),
            'genre_id': params.get('item_genre_id', ''), 'network_id': params.get('item_network_id', ''),
            'period': params.get('item_period', ''), 'duration': params.get('item_duration', ''),
            'final_mode': params.get('item_final_mode', ''), 'db_type': params.get('item_db_type', ''),
            'refresh': params.get('item_refresh', '')}

    def dump_menu_item(self, menu_item, favourite=False):
        list_name = menu_item['list_name'] if 'list_name' in menu_item else self.list_name
        method = 'add_favourite' if favourite else 'add_external'
        url_params = {'mode': 'navigator.adjust_main_lists ', 'method': method, 'list_name': list_name,
            'item_mode': menu_item.get('mode', ''), 'item_action': menu_item.get('action', ''),
            'item_query': menu_item.get('query', ''), 'item_foldername': menu_item.get('foldername', ''),
            'item_info': menu_item.get('info', ''), 'item_url_mode': menu_item.get('url_mode', ''),
            'item_menu_type': menu_item.get('menu_type', ''), 'item_user': menu_item.get('user', ''),
            'item_slug': menu_item.get('slug', ''), 'item_db_type': menu_item.get('db_type', ''),
            'item_name': menu_item.get('name', ''), 'item_iconImage': menu_item.get('iconImage', ''),
            'item_certification': menu_item.get('certification', ''), 'item_language': menu_item.get('language', ''),
            'item_year': menu_item.get('year', ''), 'item_genre_id': menu_item.get('genre_id', ''),
            'item_network_id': menu_item.get('network_id', ''),'item_period': menu_item.get('period', ''),
            'item_duration': menu_item.get('duration', ''), 'item_final_mode': menu_item.get('final_mode', ''),
            'item_refresh': menu_item.get('refresh', '')}
        return self._build_url(url_params)

    def build_favourites_list(self):
        favourites_list = self.get_favourites_list()
        list_name = 'FavouriteList'
        item_position = 0
        try:
            for item in favourites_list:
                cmenu = []
                info = item.get('info', '')
                name = item.get('name', '')
                iconImage = item.get('iconImage', '')
                icon = iconImage if item.get('network_id', '') != '' else os.path.join(self.icon_directory, iconImage)
                url_params = {'mode': item.get('mode', ''), 'action': item.get('action', ''),
                    'query': item.get('query', ''), 'foldername': item.get('foldername', ''),
                    'url_mode': item.get('url_mode', ''), 'menu_type': item.get('menu_type', ''),
                    'user': item.get('user', ''), 'slug': item.get('slug', ''), 'type': item.get('db_type', ''),
                    'certification': item.get('certification', ''), 'language': item.get('language', ''),
                    'year': item.get('year', ''), 'genre_id': item.get('genre_id', ''), 'iconImage': icon,
                    'network_id': item.get('network_id', ''), 'period': item.get('period', ''),
                    'duration': item.get('duration', ''), 'final_mode': item.get('final_mode', ''),
                    'db_type': item.get('db_type', ''), 'refresh': item.get('refresh', '')}
                url = self._build_url(url_params)
                if not name == 'Information':
                    if len(favourites_list) != 1: cmenu.append(("[B]Move[/B] Item",'XBMC.RunPlugin(%s)' % \
                        self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'move', 'list_name': list_name, 'menu_name': name, 'position': item_position})))
                    if len(favourites_list) != 1: cmenu.append(("[B]Remove[/B] Item",'XBMC.RunPlugin(%s)' % \
                        self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'remove', 'list_name': list_name, 'menu_name': name, 'position': item_position})))
                    cmenu.append(("[B]Clear Menu Favourites[/B] List",'XBMC.RunPlugin(%s)'% \
                        self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'restore', 'list_name': list_name, 'position': item_position})))
                    cmenu.append(("[B]Add Trakt List[/B] to Menu",'XBMC.RunPlugin(%s)'% \
                        self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'add_trakt', 'list_name': list_name, 'position': item_position})))
                    if item.get('slug'): cmenu.append(("[B]Add Trakt List[/B] to Subscriptions",'XBMC.RunPlugin(%s)' % \
                        self._build_url({'mode': 'trakt.add_list_to_subscriptions', 'user': item.get('user', ''), 'list_slug': item.get('slug', '')})))
                    if self.fav_default: cmenu.append(("[B]Browse[/B] Original [B]Root List[/B]",'XBMC.RunPlugin(%s)'% \
                        self._build_url({'mode': 'navigator.adjust_main_lists', 'method': 'browse', 'list_name': list_name, 'position': item_position})))
                listitem = xbmcgui.ListItem(name, thumbnailImage=icon)
                listitem.setArt({'fanart': self.fanart})
                listitem.setInfo('video', {'title': name, 'plot': info})
                listitem.addContextMenuItems(cmenu, replaceItems=False)
                item_position += 1
                xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=True)
        except: return
        self._setView()
        xbmcplugin.endOfDirectory(__handle__)

    def get_favourites_list(self):
        dbcon = database.connect(NAVIGATOR_DB)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT list_contents FROM navigator_favourites")
        try: favourites_list =  json.loads(dbcur.fetchone()[0])
        except: favourites_list = self.make_default_menu_favourites()
        return favourites_list

    def menu_favourites_info(self):
        return xbmcgui.Dialog().ok('Furk It Favourites Menu', 'Assign Favourite Menu Items and they will appear in this menu.')

    def make_default_menu_favourites(self):
        return [{"iconImage": "furk_favourites.png", "mode": "navigator.menu_favourites_info","name": "Information", "foldername": "Furk It Menu Favourites Information","info": "Select here for Information on Furk It Menu Favourites."}]

    def _build_url(self, query):
        return __url__ + '?' + urllib.urlencode(query)

    def _setView(self, view=None):
        view_type = self.view if not view else view
        try: from sqlite3 import dbapi2 as database
        except: from pysqlite2 import dbapi2 as database
        VIEWS_DB = os.path.join(profile_dir, "views.db")
        settings.check_database(VIEWS_DB)
        try:
            dbcon = database.connect(VIEWS_DB)
            dbcon.row_factory = database.Row
            dbcur = dbcon.cursor()
            dbcur.execute("SELECT view_id FROM views WHERE view_type = ?", (str(view_type),))
            view_id = dbcur.fetchone()[0]
            for i in range(0, 50):
                try: return xbmc.executebuiltin("Container.SetViewMode(%s)" % str(view_id))
                except: pass
                xbmc.sleep(100)
        except: return

    def _db_lists(self, list_name=None):
        list_name = self.list_name if not list_name else list_name
        if not xbmcvfs.exists(NAVIGATOR_DB):
            settings.initialize_databases()
            self._build_database()
        dbcon = database.connect(NAVIGATOR_DB)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT list_contents FROM navigator WHERE list_name = ? AND list_type = ?", (str(list_name), 'default'))
        default_contents = json.loads(dbcur.fetchone()[0])
        if len(default_contents) != len(eval('DefaultMenus().%s()' % list_name)):
            self._rebuild_single_database(dbcon, list_name)
            dbcur.execute("SELECT list_contents FROM navigator WHERE list_name = ? AND list_type = ?", (str(list_name), 'default'))
            default_contents = json.loads(dbcur.fetchone()[0])
        dbcur.execute("SELECT list_contents FROM navigator WHERE list_name = ? AND list_type = ?", (str(list_name), 'edited'))
        try: edited_contents = json.loads(dbcur.fetchone()[0])
        except: edited_contents = None
        return default_contents, edited_contents

    def _rebuild_single_database(self, dbcon, list_name):
        dbcon.execute("DELETE FROM navigator WHERE list_type=? and list_name=?", ('default', list_name))
        dbcon.execute("INSERT INTO navigator VALUES (?, ?, ?)", (list_name, 'default', json.dumps(eval('DefaultMenus().%s()' % list_name))))
        dbcon.commit()

    def _build_database(self):
        default_menus = DefaultMenus().DefaultMenuItems()
        dbcon = database.connect(NAVIGATOR_DB)
        for content in default_menus:
            dbcon.execute("INSERT INTO navigator VALUES (?, ?, ?)", (content, 'default', json.dumps(eval('DefaultMenus().%s()' % content))))
        dbcon.commit()

class DefaultMenus:
    def RootList(self):
        return [
            {
                "iconImage": "movies.png", 
                "mode": "navigator.main",
                "action": "MovieList",
                "name": "Movies", 
                "foldername": "Movies",
                "info": "Access Furk It Movie Menus."
            }, 
            {
                "iconImage": "tv.png", 
                "mode": "navigator.main",
                "action": "TVShowList",
                "name": "TV Shows", 
                "foldername": "TV Shows",
                "info": "Access Furk It TV Show Menus."
            }, 
            {
                "iconImage": "music.png", 
                "mode": "navigator.main",
                "action": "AudioList",
                "name": "Music", 
                "foldername": "Music",
                "info": "Access Furk It Music Menus."
            }, 
            {
                "iconImage": "search.png", 
                "mode": "navigator.search", 
                "name": "Search", 
                "foldername": "Search",
                "info": "Access Search Menus for Movies - TV Shows - Music - Furk."
            }, 
            {
                "iconImage": "furk.png", 
                "mode": "navigator.furk", 
                "name": "Furk", 
                "foldername": "Furk",
                "info": "Access Your Furk files and other information relating to your Furk account."
            }, 
            {
                "iconImage": "trakt.png", 
                "mode": "navigator.my_trakt_content", 
                "name": "My Trakt Lists", 
                "foldername": "My Trakt Lists",
                "info": "Access your Trakt Lists and Watchlists. You must be logged into Trakt to view your Lists."
            }, 
            {
                "iconImage": "favourites.png", 
                "mode": "navigator.favourites", 
                "name": "Favourites", 
                "foldername": "Favourites",
                "info": "Access Furk It Movie - TV Show - Audio Favourites."
            }, 
            {
                "iconImage": "library.png", 
                "mode": "navigator.subscriptions", 
                "name": "Subscriptions", 
                "foldername": "Subscriptions Root",
                "info": "Access Furk It Movie and TV Show Subscriptions Items."
            }, 
            {
                "iconImage": "watched_1.png", 
                "mode": "navigator.watched", 
                "name": "Watched", 
                "foldername": "Watched",
                "info": "Access Furk It Watched Items for Movies and TV Shows that have been fully watched in Furk It."
            }, 
            {
                "iconImage": "player.png", 
                "mode": "navigator.in_progress", 
                "name": "In Progress", 
                "foldername": "In Progress",
                "info": "Access Furk It In Progress Menus for Movies and TV Show Episodes currently In Progress."
            }, 
            {
                "iconImage": "downloads.png", 
                "mode": "navigator.downloads", 
                "name": "Downloads", 
                "foldername": "Furk It Downloads",
                "info": "Access your Furk It Downloads folder."
            }, 
            {
                "iconImage": "library_kodi.png", 
                "mode": "navigator.kodi_library", 
                "name": "Kodi Library", 
                "foldername": "Kodi Library Root",
                "info": "Access your Kodi Library for Movies and TV Shows."
            }, 
            {
                "iconImage": "furk_favourites.png", 
                "mode": "navigator.build_favourites_list",
                "name": "Menu Favourites", 
                "foldername": "Menu Favourites",
                "info": "Access your Favourite Menu Items."
            }, 
            {
                "iconImage": "settings2.png", 
                "mode": "navigator.tools", 
                "name": "Tools", 
                "foldername": "Tools",
                "info": "Access Furk It Tools to change some settings and set some account details such as Trakt and TMDb. Also set view modes and clear some Furk It settings such as Favourites and Subscriptions Items."
            }, 
            {
                "iconImage": "settings.png", 
                "mode": "navigator.settings", 
                "name": "Settings", 
                "foldername": "Settings",
                "info": "Access Furk It Settings from within the add-on."
            }
        ]

    def MovieList(self):
        return [
            {
                "name": "Trending", 
                "iconImage": "trending.png", 
                "foldername": "Trending", 
                "mode": "build_movie_list", 
                "action": "trakt_movies_trending",
                "info": "Browse Trending Movies."
            }, 
            {
                "name": "Popular", 
                "iconImage": "popular.png", 
                "foldername": "Popular", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_popular",
                "info": "Browse Popular Movies."
            }, 
            {
                "action": "tmdb_movies_premieres", 
                "iconImage": "fresh.png", 
                "mode": "build_movie_list", 
                "name": "Premieres", 
                "foldername": "Movies Premiering",
                "info": "Browse Movies that have Premiered in the Last Month."
            }, 
            {
                "name": "Latest Releases", 
                "iconImage": "dvd.png", 
                "foldername": "Latest Releases", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_latest_releases",
                "info": "Browse Movies Released Within the Last Month."
            }, 
            {
                "action": "trakt_movies_top10_boxoffice", 
                "iconImage": "box_office.png", 
                "mode": "build_movie_list", 
                "name": "Top 10 Box Office", 
                "foldername": "Movies Box Office",
                "info": "Browse Top 10 Movies from this Weeks Box Office."
            }, 
            {
                "name": "Blockbusters", 
                "iconImage": "most_voted.png", 
                "foldername": "Blockbusters", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_blockbusters",
                "info": "Browse Blockbuster Movies."
            }, 
            {
                "name": "In Theaters", 
                "iconImage": "intheatres.png", 
                "foldername": "In Theaters", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_in_theaters",
                "info": "Browse In Theater Movies."
            }, 
            {
                "name": "Top Rated", 
                "iconImage": "top_rated.png", 
                "foldername": "Top Rated", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_top_rated",
                "info": "Browse Top Rated Movies."
            }, 
            {
                "name": "Up Coming", 
                "iconImage": "lists.png", 
                "foldername": "Up Coming", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_upcoming",
                "info": "Browse Up Coming Movies."
            }, 
            {
                "name": "Anticipated", 
                "iconImage": "most_anticipated.png", 
                "foldername": "Anticipated", 
                "mode": "build_movie_list", 
                "action": "trakt_movies_anticipated",
                "info": "Browse Anticipated Movies."
            }, 
            {
                "name": "Oscar Winners", 
                "iconImage": "oscar-winners.png", 
                "foldername": "Oscar Winners", 
                "mode": "build_movie_list", 
                "action": "imdb_movies_oscar_winners",
                "info": "Browse Oscar Winning Movies."
            }, 
            {
                "name": "Mosts", 
                "menu_type": "movie", 
                "iconImage": "trakt.png", 
                "foldername": "Mosts", 
                "mode": "navigator.trakt_mosts",
                "info": "Access Trakt Mosts Movie Menus. Menus are Most Played, Most Collected and Most Watched. These can be filtered by This Week, This Month, This Year or All Time."
            }, 
            {
                "name": "Genres", 
                "menu_type": "movie", 
                "iconImage": "genres.png", 
                "foldername": "Genres", 
                "mode": "navigator.genres",
                "info": "Access Movies by Genres."
            }, 
            {
                "name": "Languages", 
                "menu_type": "movie", 
                "iconImage": "languages.png", 
                "foldername": "Movie Languages", 
                "mode": "navigator.languages", 
                "info": "Browse Movies by Language."
            }, 
            {
                "name": "Years", 
                "menu_type": "movie", 
                "iconImage": "calender.png", 
                "foldername": "Movie Years", 
                "mode": "navigator.years", 
                "info": "Browse Movies by Year."
            }, 
            {
                "name": "Certifications", 
                "menu_type": "movie", 
                "iconImage": "certifications.png", 
                "foldername": "Certifications", 
                "mode": "navigator.certifications",
                "info": "Access Movies by US Certifications."
            }, 
            {
                "name": "Popular People", 
                "iconImage": "genre_comedy.png", 
                "foldername": "Popular People", 
                "mode": "build_movie_list", 
                "action": "tmdb_popular_people",
                "info": "Browse Most Popular People in Movies."
            }, 
            {
                "name": "Trakt Collection", 
                "iconImage": "traktcollection.png", 
                "foldername": "Trakt Collection", 
                "mode": "build_movie_list", 
                "action": "trakt_collection",
                "info": "Browse your Trakt Movie Collection. You must be logged into Trakt to view your Collection."
            }, 
            {
                "name": "Trakt Watchlist", 
                "iconImage": "traktwatchlist.png", 
                "foldername": "Trakt Watchlist", 
                "mode": "build_movie_list", 
                "action": "trakt_watchlist",
                "info": "Browse your Trakt Movie Watchlist. You must be logged into Trakt to view your Watchlist."
            }, 
            {
                "name": "Trakt Recommendations", 
                "iconImage": "traktrecommendations.png", 
                "foldername": "Trakt Recommendations", 
                "mode": "build_movie_list", 
                "action": "trakt_recommendations",
                "info": "Browse your Trakt Recommendations. You must be logged into Trakt to view your Recommendations."
            }, 
            {
                "foldername": "Watched", 
                "iconImage": "watched_1.png", 
                "mode": "build_movie_list",  
                "action": "watched_movies", 
                "name": "Watched",
                "info": "Browse Movies that you have Watched in Furk It."
            }, 
            {
                "foldername": "In Progress", 
                "iconImage": "player.png", 
                "mode": "build_movie_list",  
                "action": "in_progress_movies", 
                "name": "In Progress",
                "info": "Browse Movies that you have begun to watch in Furk It, but haven't finished."
            }, 
            {
                "name": "Favourites", 
                "iconImage": "favourites.png", 
                "foldername": "Movie Favourites", 
                "mode": "build_movie_list", 
                "action": "favourites_movies",
                "info": "Browse Movies you have added to Furk It Favourites."
            }, 
            {
                "name": "Subscriptions", 
                "iconImage": "library.png", 
                "foldername": "Subscriptions", 
                "mode": "build_movie_list", 
                "action": "subscriptions_movies",
                "info": "Browse Movies you have added to Furk It Subscriptions."
            }, 
            {
                "name": "Kodi Library", 
                "iconImage": "library_kodi.png", 
                "foldername": "Kodi Library", 
                "mode": "build_movie_list", 
                "action": "kodi_library_movies",
                "info": "Browse Movies that are in your personal Kodi Library."
            }, 
            {
                "name": "Search", 
                "iconImage": "search.png", 
                "foldername": "Movie Search", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_search", 
                "query": "NA",
                "info": "Search for Movies by name."
            }, 
            {
                "name": "People Search", 
                "iconImage": "search_people.png", 
                "foldername": "People Movie Search", 
                "mode": "build_movie_list", 
                "action": "tmdb_movies_people_search", 
                "query": "NA",
                "info": "Search for Movies starring an Actor or Actress."
            }, 
            {
                "foldername": "Movie Search History", 
                "iconImage": "search.png", 
                "mode": "search_history", 
                "action": "movie",
                "name": "Search History",
                "info": "Access a History of Movie Searches. The last 10 searches are stored."
            }
        ]
    
    def TVShowList(self):
        return [
            {
                "action": "trakt_tv_trending", 
                "iconImage": "trending.png", 
                "mode": "build_tvshow_list", 
                "name": "Trending", 
                "foldername": "TV Trending",
                "info": "Browse Trending TV Shows."
            }, 
            {
                "action": "tmdb_tv_popular", 
                "iconImage": "popular.png", 
                "mode": "build_tvshow_list", 
                "name": "Popular", 
                "foldername": "TV Popular",
                "info": "Browse Popular TV Shows."
            }, 
            {
                "action": "tmdb_tv_premieres", 
                "iconImage": "fresh.png", 
                "mode": "build_tvshow_list", 
                "name": "Premieres", 
                "foldername": "TV Premiering",
                "info": "Browse TV Shows that have Premiered in the Last Month."
            }, 
            {
                "action": "tmdb_tv_top_rated", 
                "iconImage": "top_rated.png", 
                "mode": "build_tvshow_list", 
                "name": "Top Rated", 
                "foldername": "TV Top Rated",
                "info": "Browse Top Rated TV Shows."
            }, 
            {
                "action": "tmdb_tv_airing_today", 
                "iconImage": "live.png", 
                "mode": "build_tvshow_list", 
                "name": "Airing Today",
                "info": "Browse TVShows Airing Today."
            }, 
            {
                "action": "tmdb_tv_on_the_air", 
                "iconImage": "ontheair.png", 
                "mode": "build_tvshow_list", 
                "name": "On the Air", 
                "foldername": "TV On the Air",
                "info": "Browse TVShows On the Air."
            }, 
            {
                "name": "Up Coming", 
                "iconImage": "lists.png", 
                "foldername": "Up Coming", 
                "mode": "build_tvshow_list", 
                "action": "tmdb_tv_upcoming",
                "info": "Browse Up Coming TV Shows."
            }, 
            {
                "action": "trakt_tv_anticipated", 
                "iconImage": "most_anticipated.png", 
                "mode": "build_tvshow_list", 
                "name": "Anticipated",
                "info": "Browse Anticipated TVShows."
            }, 
            {
                "menu_type": "tvshow", 
                "iconImage": "trakt.png", 
                "mode": "navigator.trakt_mosts", 
                "name": "Mosts", 
                "foldername": "TV Trakt Mosts",
                "info": "Access Trakt Mosts TV Show Menus. Menus are Most Played, Most Collected and Most Watched. These can be filtered by This Week, This Month, This Year or All Time."
            }, 
            {
                "menu_type": "tvshow", 
                "iconImage": "genres.png", 
                "mode": "navigator.genres", 
                "name": "Genres", 
                "foldername": "TV Genres",
                "info": "Access TV Shows by Genres."
            }, 
            {
                "menu_type": "tvshow", 
                "iconImage": "networks.png", 
                "mode": "navigator.networks", 
                "name": "Networks", 
                "foldername": "TV Networks",
                "info": "Access TV Networks."
            }, 
            {
                "menu_type": "tvshow", 
                "iconImage": "languages.png", 
                "mode": "navigator.languages", 
                "name": "Languages", 
                "foldername": "TV Show Languages",
                "info": "Browse TV Shows by Language."
            }, 
            {
                "name": "Years", 
                "menu_type": "tvshow", 
                "iconImage": "calender.png", 
                "foldername": "TV Show Years", 
                "mode": "navigator.years", 
                "info": "Browse TV Shows by Year."
            }, 
            {
                "menu_type": "tvshow", 
                "iconImage": "certifications.png", 
                "mode": "navigator.certifications", 
                "name": "Certifications", 
                "foldername": "TV Show Certifications",
                "info": "Access TV Shows by US Certifications."
            }, 
            {
                "name": "Popular People", 
                "iconImage": "genre_comedy.png", 
                "foldername": "Popular People", 
                "mode": "build_tvshow_list", 
                "action": "tmdb_popular_people",
                "info": "Browse Most Popular People in TV Shows."
            }, 
            {
                "action": "trakt_collection", 
                "iconImage": "traktcollection.png", 
                "mode": "build_tvshow_list", 
                "name": "Trakt Collection", 
                "foldername": "Trakt TV Collection",
                "info": "Browse your Trakt TV Show Collection. You must be logged into Trakt to view your Collection."
            }, 
            {
                "action": "trakt_watchlist", 
                "iconImage": "traktwatchlist.png", 
                "mode": "build_tvshow_list", 
                "name": "Trakt Watchlist", 
                "foldername": "Trakt TV Watchlist",
                "info": "Browse your Trakt TV Show Watchlist. You must be logged into Trakt to view your Watchlist."
            }, 
            {
                "name": "Trakt Recommendations", 
                "iconImage": "traktrecommendations.png", 
                "foldername": "Trakt Recommendations", 
                "mode": "build_tvshow_list", 
                "action": "trakt_recommendations",
                "info": "Browse your Trakt Recommendations. You must be logged into Trakt to view your Recommendations."
            }, 
            {
                "foldername": "Watched", 
                "iconImage": "watched_1.png", 
                "mode": "build_tvshow_list",  
                "action": "watched_tvshows", 
                "name": "Watched",
                "info": "Browse TV Shows that you have Watched in Furk It."
            }, 
            {
                "action": "in_progress_tvshows", 
                "iconImage": "in_progress_tvshow.png", 
                "mode": "build_tvshow_list", 
                "name": "In Progress TV Shows", 
                "foldername": "In Progress TV Shows",
                "info": "Browse TV Shows that you have begun to watch in Furk It, but haven't finished."
            }, 
            {
                "iconImage": "player.png", 
                "mode": "build_in_progress_episode", 
                "name": "In Progress Episodes", 
                "foldername": "In Progress Episodes",
                "info": "Browse Episodes that you have begun to watch in Furk It, but haven't finished."
            }, 
            {
                "iconImage": "next_episodes.png", 
                "mode": "build_next_episode", 
                "name": "Next Episodes", 
                "foldername": "It Next Episodes",
                "info": "Next available to watch episodes based on either Trakt or Furk It watched history."
            }, 
            {
                "action": "favourites_tvshows", 
                "iconImage": "favourites.png", 
                "mode": "build_tvshow_list", 
                "name": "Favourites", 
                "foldername": "TV Show It Favourites",
                "info": "Browse TV Shows you have added to Furk It Favourites."
            }, 
            {
                "action": "subscriptions_tvshows", 
                "iconImage": "library.png", 
                "mode": "build_tvshow_list", 
                "name": "Subscriptions", 
                "foldername": "Subscriptions",
                "info": "Browse TV Shows you have added to Furk It Subscriptions."
            }, 
            {
                "action": "kodi_library_tvshows", 
                "iconImage": "library_kodi.png", 
                "mode": "build_tvshow_list", 
                "name": "Kodi Library", 
                "foldername": "Kodi Library",
                "info": "Browse TV Shows that are in your personal Kodi Library."
            }, 
            {
                "name": "Search", 
                "iconImage": "search.png", 
                "foldername": "TV Show Search", 
                "mode": "build_tvshow_list", 
                "action": "tmdb_tv_search", 
                "query": "NA",
                "info": "Search for TV Shows by name."
            }, 
            {
                "name": "People Search", 
                "iconImage": "search_people.png", 
                "foldername": "People TV Show Search", 
                "mode": "build_tvshow_list", 
                "action": "tmdb_tv_people_search", 
                "query": "NA",
                "info": "Search for TV Shows starring an Actor or Actress."
            }, 
            {
                "iconImage": "search.png", 
                "mode": "search_history", 
                "action": "tvshow",
                "name": "Search History", 
                "foldername": "TV Show Search History",
                "info": "Browse a History of TV Show Searches. The last 10 searches are stored."
            }
        ]

    def AudioList(self):
        return [
            { 
                "name": "My Furk Music Files", 
                "iconImage": "lists.png", 
                "foldername": "My Furk Audio Files", 
                "mode": "furk.my_furk_files", 
                "db_type": "audio",
                "info": "Browse Music Files and Folders saved in your Furk My Files section."
            }, 
            {
                "name": "Music Favourites", 
                "iconImage": "genre_music.png", 
                "foldername": "Audio Favourites", 
                "mode": "my_furk_audio_favourites",
                "info": "Browse Music Folders saved as Favourites in Furk It."
            }, 
            {
                "name": "Search Furk For Music", 
                "iconImage": "search.png", 
                "foldername": "Search Furk (Audio)", 
                "mode": "furk.search_furk", 
                "db_type": "audio",
                "info": "Search Furk For Music."
            }, 
            {
                "name": "Music Search History", 
                "iconImage": "search.png", 
                "foldername": "Audio Search History", 
                "mode": "search_history", 
                "action": "audio",
                "info": "Browse a History of Music Searches. The last 10 searches are stored."
            }
        ]

    def FavouriteList(self):
        return None

    def DefaultMenuItems(self):
        return ['RootList', 'MovieList', 'TVShowList', 'AudioList', 'FavouriteList']





