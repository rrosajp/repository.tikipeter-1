# -*- coding: utf-8 -*-
import xbmc, xbmcaddon
import sys, os
# from resources.lib.modules.utils import logger


__addon_id__ = 'plugin.video.furkit'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__url__ = sys.argv[0]
__handle__ = int(sys.argv[1])
addon_dir = xbmc.translatePath(__addon__.getAddonInfo('path'))
profile_dir = xbmc.translatePath(__addon__.getAddonInfo('profile'))
icon_image = __addon__.getAddonInfo('icon')
fanart = __addon__.getAddonInfo('fanart')

def build_navigate_to_page():
    import xbmcgui
    import json
    import ast
    from urlparse import parse_qsl
    from resources.lib.modules.settings import get_theme
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    page_list = []
    current_page = int(params.get('current_page'))
    total_pages = int(params.get('total_pages'))
    transfer_mode = params.get('transfer_mode', '')
    transfer_action = params.get('transfer_action', '')
    for i in range(1, total_pages+1): page_list.append(str(i))
    page_list.remove(str(current_page))
    display_list = ['Page %s' % i for i in page_list]
    choice_list = [xbmcgui.ListItem(i, '[I]Navigate to %s[/I]' % i, iconImage=os.path.join(get_theme(), 'item_jump.png')) for i in display_list]
    chosen_page = xbmcgui.Dialog().select('Furk It Page Choice...', choice_list, useDetails=True)
    if chosen_page < 0: return
    new_page = page_list[chosen_page]
    final_params = {'mode': transfer_mode, 'action': transfer_action, 'new_page': new_page, 'passed_list': params.get('passed_list', ''), 'query': params.get('query', '')}
    url_params = {'mode': 'container_update', 'final_params': json.dumps(final_params)}
    xbmc.executebuiltin('XBMC.RunPlugin(%s)' % build_url(url_params))

def container_update():
    from urlparse import parse_qsl
    import json
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % build_url(json.loads(params['final_params'])))

def get_kodi_version():
    return int(xbmc.getInfoLabel("System.BuildVersion")[0:2])

def show_busy_dialog():
    if get_kodi_version() >= 18: xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    else: xbmc.executebuiltin('ActivateWindow(busydialog)')

def hide_busy_dialog():
    if get_kodi_version() >= 18: xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    else: xbmc.executebuiltin('Dialog.Close(busydialog)')

def close_all_dialog():
    xbmc.executebuiltin('Dialog.Close(all,true)')

def sleep(time):
    xbmc.sleep(time)

def show_text(heading=None, text_file=None):
    import xbmcgui
    from urlparse import parse_qsl
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    heading = params.get('heading') if 'heading' in params else heading
    text_file = params.get('text_file') if 'text_file' in params else text_file
    text = open(text_file).read()
    try: xbmcgui.Dialog().textviewer(heading, text)
    except: return

def open_settings(query):
    try:
        xbmc.sleep(500)
        xbmc_version = get_kodi_version()
        button = (-100) if xbmc_version <= 17 else (100)
        control = (-200) if xbmc_version <= 17 else (80)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        menu, function = query.split('.')
        xbmc.executebuiltin('Addon.OpenSettings(%s)' % __addon_id__)
        xbmc.executebuiltin('SetFocus(%i)' % (int(menu) - button))
        xbmc.executebuiltin('SetFocus(%i)' % (int(function) - control))
    except: return

def toggle_setting(setting_id=None, setting_value=None, refresh=None):
    if not setting_id:
        from urlparse import parse_qsl
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        setting_id = params.get('setting_id')
        setting_value = params.get('setting_value')
        refresh = params.get('refresh')
    __addon__.setSetting(setting_id, setting_value)
    if refresh:
        xbmc.executebuiltin('Container.Refresh')

def build_url(query):
    import urllib
    from resources.lib.modules.utils import to_utf8
    return __url__ + '?' + urllib.urlencode(to_utf8(query))

def notification(line1, time=5000, icon=icon_image, sound=False):
    import xbmcgui
    xbmcgui.Dialog().notification('Furk It', line1, icon, time, sound)

def add_dir(url_params, list_name, iconImage='DefaultFolder.png', fanart=None, isFolder=True):
    import xbmcgui, xbmcplugin
    from resources.lib.modules.settings import get_theme
    icon = os.path.join(get_theme(), iconImage)
    fanart = os.path.join(addon_dir, 'fanart.jpg') if fanart == None else fanart
    info = url_params.get('info', '')
    url = build_url(url_params)
    listitem = xbmcgui.ListItem(list_name, iconImage=icon)
    listitem.setArt({'fanart': fanart})
    listitem.setInfo('video', {'title': list_name, 'plot': info})
    xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=listitem, isFolder=isFolder)

def paginate_list(item_list, page, limit=20):
    pages = [item_list[i:i+limit] for i in range(0, len(item_list), limit)]
    total_pages = len(item_list)/limit + 1
    return pages[page - 1], total_pages

def unaired_episode_color_choice():
    from resources.lib.modules.utils import color_chooser
    dialog = 'Please Choose Color for Unaired Episodes'
    chosen_color = color_chooser(dialog)
    if chosen_color: toggle_setting('unaired_episode_colour', chosen_color)
    else: pass

def setView(view_type):
    from urlparse import parse_qsl
    from resources.lib.modules.settings import check_database
    try: from sqlite3 import dbapi2 as database
    except: from pysqlite2 import dbapi2 as database
    VIEWS_DB = os.path.join(profile_dir, "views.db")
    check_database(VIEWS_DB)
    try:
        dbcon = database.connect(VIEWS_DB)
        dbcon.row_factory = database.Row
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT view_id FROM views WHERE view_type = ?", (str(view_type),))
        view_id = dbcur.fetchone()[0]
        xbmc.sleep(200)
        xbmc.executebuiltin("Container.SetViewMode(%s)" % str(view_id))
    except: pass

def similar_related_choice():
    from urlparse import parse_qsl
    from resources.lib.modules.utils import selection_dialog
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    db_type = params.get('db_type')
    meta_type = 'movie' if db_type == 'movies' else 'tvshow'
    imdb_id = params.get('imdb_id') if 'tt' in params.get('imdb_id') else get_meta(meta_type, 'tmdb_id', params.get('tmdb_id'))['imdb_id']
    dl = ['Similar','Related'] if imdb_id else ['Similar']
    fl = ['tmdb_%s_similar' % db_type,'trakt_%s_related' % db_type] if imdb_id else ['tmdb_%s_similar' % db_type]
    string = 'Please Choose Movie Search Option:' if db_type == 'movie' else 'Please Choose TV Show Search Option:'
    mode = 'build_%s_list' % meta_type
    choice = selection_dialog(dl, fl, string)
    if not choice: return
    try:
        sim_rel_params = {'mode': mode, 'action': choice, 'tmdb_id': params.get('tmdb_id'), 'imdb_id': imdb_id, 'from_search': params.get('from_search')}
        xbmc.executebuiltin('XBMC.Container.Update(%s)' % build_url(sim_rel_params))
    except: return

def cache_object(function, string, url, json=True, expiration=24):
    from datetime import timedelta
    from resources.lib.modules import furkitcache
    from resources.lib.modules.utils import to_utf8
    _cache = furkitcache.FurkItCache()
    cache = _cache.get(string)
    if cache: return to_utf8(cache)
    if json: result = function(url).json()
    else: result = function(url)
    _cache.set(string, result, expiration=timedelta(hours=expiration))
    return to_utf8(result)

def refresh_cached_data(db_type=None, id_type=None, media_id=None, from_list=False):
    from resources.lib.modules.metacache import MetaCache
    import xbmc
    from urlparse import parse_qsl
    params = dict(parse_qsl(sys.argv[2].replace('?','')))
    metacache = MetaCache()
    try:
        metacache.delete(params.get('db_type', db_type), params.get('id_type', id_type), params.get('media_id', media_id))
        if params.get('from_list', from_list): return True
        notification('Cache refreshed for item')
        xbmc.executebuiltin('Container.Refresh')
    except:
        if params.get('from_list', from_list): return False
        notification('Refreshing of Cache failed for item', 4500)

def get_trakt_movie_id(item):
    item = item['movie']['ids'] if 'movie' in item else item['ids']
    if item['tmdb']:
        return item['tmdb']
    if item['imdb']:
        meta = get_meta('tvshow', 'imdb_id', item['imdb'])
        if meta: return meta['tmdb_id']
    return None

def get_trakt_tvshow_id(item):
    item = item['show']['ids'] if 'show' in item else item['ids']
    if item['tmdb']:
        return item['tmdb']
    if item['tvdb']:
        meta = get_meta('tvshow', 'tvdb_id', item['tvdb'])
        if meta: return meta['tmdb_id']
    if item['imdb']:
        meta = get_meta('tvshow', 'imdb_id', item['imdb'])
        if meta: return meta['tmdb_id']
    return None

def get_meta(db_type, id_type, media_id, hours=168):
    from resources.lib.modules.metacache import MetaCache
    metacache = MetaCache()
    meta = None
    data = metacache.get(db_type, id_type, media_id)
    if data: return data
    try:
        from datetime import timedelta
        if db_type == 'movie': from resources.lib.modules.tmdb import tmdb_movies_simple as data
        elif db_type == 'tvshow': from resources.lib.modules.tmdb import tmdb_tv_simple as data
        if db_type == 'movie' and not id_type == 'tmdb_id': from resources.lib.modules.tmdb import tmdb_movies_simple_external_id as result
        elif db_type == 'tvshow' and not id_type == 'tmdb_id': from resources.lib.modules.tmdb import tmdb_tv_simple_external_id as result
        data = data(media_id) if id_type == 'tmdb_id' else data(result(id_type, media_id)['id'])
        meta = build_meta(data, db_type)
        metacache.set(db_type, meta, timedelta(hours=hours))
    except: pass
    return meta

def clear_cache(cache):
    if cache == 'provider':
        from resources.lib.sources.external import ExternalSource
        return ExternalSource().clearSources()
    import xbmcgui, xbmcvfs
    (cache_file, table, description) = ('metacache.db', 'metadata', 'Movie & TV Show Metadata') if cache == 'meta' else ('furkit_cache.db', 'furkitcache', 'List Data')
    if not xbmcvfs.exists(os.path.join(profile_dir, cache_file)): return
    if not xbmcgui.Dialog().yesno('Are you sure?','Furk It will Clear all %s.' % description): return
    try: from sqlite3 import dbapi2 as database
    except ImportError: from pysqlite2 import dbapi2 as database
    dbcon = database.connect(os.path.join(profile_dir, cache_file))
    dbcur = dbcon.cursor()
    dbcur.execute("DELETE FROM %s" % table)
    dbcur.execute("VACUUM")
    dbcon.commit()
    dbcon.close()
    notification('%s Cleared' % description)

def build_meta(data, db_type):
    from resources.lib.modules.settings import get_theme
    from resources.lib.modules.utils import to_utf8, try_parse_int
    meta = {}
    writer = []
    meta['cast'] = []
    meta['castandrole'] = []
    meta['studio'] = []
    meta['certification'] = ''
    meta['director'] = ''
    meta['premiered'] = ''
    meta['writer'] = ''
    meta['trailer'] = ''
    meta['tmdb_id'] = data['id'] if 'id' in data else ''
    meta['imdb_id'] = data.get('imdb_id', '') if db_type == 'movie' else data['external_ids'].get('imdb_id', '')
    meta['tvdb_id'] = data['external_ids'].get('tvdb_id', 'None')
    meta['poster'] = "http://image.tmdb.org/t/p/original%s" % data.get('poster_path') if data.get('poster_path') else icon_image
    meta['fanart'] = "http://image.tmdb.org/t/p/original%s" % data.get('backdrop_path') if data.get('backdrop_path') else fanart
    try:meta['year'] = try_parse_int(data['release_date'].split('-')[0]) if db_type == 'movie' else try_parse_int(data['first_air_date'].split('-')[0])
    except: meta['year'] == ''
    meta['duration'] = int(data['runtime'] * 60) if data.get('runtime') else ''
    meta['rating'] = data['vote_average'] if 'vote_average' in data else ''
    try: meta['genre'] = ', '.join([item['name'] for item in data['genres']])
    except: meta['genre'] == []
    meta['plot'] = to_utf8(data['overview']) if 'overview' in data else ''
    meta['title'] = to_utf8(data['title']) if db_type == 'movie' else to_utf8(data['name'])
    meta['tagline'] = to_utf8(data['tagline']) if 'tagline' in data else ''
    meta['votes'] = data['vote_count'] if 'vote_count' in data else ''
    meta['season_data'] = data['seasons'] if 'seasons' in data else ''
    meta['rootname'] = '{0} ({1})'.format(meta['title'], meta['year'])
    if db_type == 'movie':
        if data.get('production_companies'): meta['studio'] = [item['name'] for item in data['production_companies']]
        if data.get('release_date'): meta['premiered'] = data['release_date']
    else:
        try: meta['episode_run_time'] = min(data['episode_run_time']) if 'episode_run_time' in data else ''
        except: meta['episode_run_time'] = 30
        if data.get('networks', None):
            try: meta['studio'] = [item['name'] for item in data['networks']]
            except: meta['studio'] = []
        if data.get('first_air_date', None): meta['premiered'] = data.get('first_air_date', '')
        if data.get('number_of_seasons', None): meta['number_of_seasons'] = data.get('number_of_seasons', '')
        if data.get('number_of_episodes', None): meta['number_of_episodes'] = data.get('number_of_episodes', '')
        if data.get('last_episode_to_air', None): meta['last_episode_to_air'] = data.get('last_episode_to_air', '')
        if data.get('next_episode_to_air', None): meta['next_episode_to_air'] = data.get('next_episode_to_air', '')
        if data.get('in_production', None): meta['in_production'] = data.get('in_production', False) # True, False
        if data.get('status', None): meta['status'] = data.get('status', 'Ended') # Returning Series, Ended
    if 'release_dates' in data:
        for rel_info in data['release_dates']['results']:
            if rel_info['iso_3166_1'] == 'US':
                meta['certification'] = rel_info['release_dates'][0]['certification']
    if 'credits' in data:
        if 'cast' in data['credits']:
            for cast_member in data['credits']['cast']:
                cast_thumb = ''
                if cast_member['profile_path']:
                    cast_thumb = 'http://image.tmdb.org/t/p/original%s' % cast_member['profile_path']
                meta['cast'].append({'name': cast_member['name'], 'role': cast_member['character'], 'thumbnail': cast_thumb})
                meta['castandrole'].append((cast_member['name'], cast_member['character']))
        if 'crew' in data['credits']:
            for crew_member in data['credits']['crew']:
                cast_thumb = ''
                if crew_member['profile_path']:
                    cast_thumb = 'http://image.tmdb.org/t/p/original%s' % crew_member['profile_path']
                if crew_member['job'] in ['Author', 'Writer', 'Screenplay', 'Characters']:
                    writer.append(crew_member['name'])
                if crew_member['job'] == 'Director':
                    meta['director'] = crew_member['name']
            if writer: meta['writer'] = ', '.join(writer)
    if 'videos' in data:
        for video in data['videos']['results']:
            if video['site'] == 'YouTube' and video['type'] == 'Trailer' or video['type'] == 'Teaser':
                meta['trailer'] = 'plugin://plugin.video.youtube/play/?video_id=%s' % video['key']
                break
    return to_utf8(meta)


