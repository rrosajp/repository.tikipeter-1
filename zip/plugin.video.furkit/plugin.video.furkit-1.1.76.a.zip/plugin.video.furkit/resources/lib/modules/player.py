# -*- coding: utf-8 -*-
import xbmc, xbmcplugin, xbmcgui
import sys
import urllib
from urlparse import parse_qsl
from resources.lib.modules.nav_utils import hide_busy_dialog
import settings
# from resources.lib.modules.utils import logger

window = xbmcgui.Window(10000)

class FurkitPlayer(xbmc.Player):
    def __init__ (self):
        xbmc.Player.__init__(self)
        self.info = None
        self.set_resume = settings.set_resume()
        self.set_watched = settings.set_watched()
        self.set_nextep = settings.set_nextep()
        self.delete_playcount = True

    def run(self):
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        rootname = params.get('rootname', '')
        try:
            if rootname == 'nill':
                url = urllib.unquote(params.get("url"))
                self.play(url)
                return
            import json
            self.meta = json.loads(window.getProperty('furkit_media_meta'))
            rootname = self.meta['rootname'] if 'rootname' in self.meta else ''
            url = self.meta['url'] if 'url' in self.meta else params.get("url") if 'url' in params else None
            url = urllib.unquote(url)
            if not url: return
            listitem = xbmcgui.ListItem(path=url)
            try:
                listitem.setArt({'thumb': self.meta.get('poster', ''), 'poster': self.meta.get('poster', '')})
                listitem.setProperty('StartPercent', str(self.meta.get('bookmark', '')))
                if self.meta['vid_type'] == 'episode':
                    listitem.setInfo(
                        'video', {'mediatype': 'episode', 'trailer': str(self.meta['trailer']), 'title': self.meta['ep_name'],
                        'tvshowtitle': self.meta['title'], 'size': '0', 'plot': self.meta['plot'], 'year': self.meta['year'],
                        'premiered': self.meta['premiered'], 'genre': self.meta['genre'], 'season': int(self.meta['season']),
                        'episode': int(self.meta['episode']), 'duration': str(self.meta['duration']),
                        'rating': self.meta['rating'], 'tvdb': self.meta['tvdb_id'], 'imdb': self.meta['imdb_id']})
                elif self.meta['vid_type'] == 'movie':
                    listitem.setInfo(
                        'video', {'mediatype': 'movie', 'trailer': str(self.meta['trailer']),
                        'title': self.meta['title'], 'size': '0', 'duration': self.meta['duration'],
                        'plot': self.meta['plot'], 'rating': self.meta['rating'], 'premiered': self.meta['premiered'], 
                        'studio': self.meta['studio'],'year': self.meta['year'], 'tmdb_id': self.meta['tmdb_id'],
                        'genre': self.meta['genre'],'tagline': self.meta['tagline'], 'code': self.meta['imdb_id'],
                        'imdbnumber': self.meta['imdb_id'], 'imdb_id': self.meta['imdb_id'], 'tmdb': self.meta['tmdb_id'],
                        'director': self.meta['director'], 'writer': self.meta['writer'], 'imdb': self.meta['imdb_id'],
                        'votes': self.meta['votes'], 'poster': self.meta['poster'], 'fanart': self.meta['fanart']})
            except: pass
            self.play(url, listitem)
            self.monitor()
        except: return

    def monitor(self):
        self.setting = 'library' if 'from_library' in self.meta else None
        self.autoplay_next_episode = True if self.meta['vid_type'] == 'episode' and settings.autoplay_next_episode(self.setting) else False
        while not self.isPlayingVideo():
            xbmc.sleep(100)
        while self.isPlayingVideo():
            try:
                self.total_time = self.getTotalTime()
                self.curr_time = self.getTime()
                xbmc.sleep(100)
                if self.autoplay_next_episode and round(float(self.curr_time/self.total_time*100),1) >= self.set_nextep and not self.info: self.nextEpisode()
            except: pass
        self.onPlayBackStopped()

    def nextEpisode(self):
        from resources.lib.modules.next_episode import next_episode_from_playback
        self.info = next_episode_from_playback(self.meta, from_library=self.setting)
        if self.info and not 'pass' in self.info:
            self.delete_playcount = False
            xbmc.executebuiltin("RunPlugin({0})".format(self.info['url']))
        else: pass

    def mediaWatchedMarker(self):
        try:
            if self.delete_playcount: window.clearProperty('playcount')
            resume_point = round(float(self.curr_time/self.total_time*100),1)
            if self.set_resume < resume_point < self.set_watched:
                from resources.lib.modules.indicators_bookmarks import set_bookmark
                set_bookmark(self.meta['vid_type'], self.meta['media_id'], self.curr_time, self.total_time, self.meta.get('season', ''), self.meta.get('episode', ''))
            elif resume_point > self.set_watched:
                from resources.lib.modules.nav_utils import build_url
                if self.meta['vid_type'] == 'movie':
                    watched_params = {"mode": "mark_movie_as_watched_unwatched", "action": 'mark_as_watched',
                    "media_id": self.meta['media_id'], "title": self.meta['title'], "year": self.meta['year']}
                else:
                    watched_params = {"mode": "mark_episode_as_watched_unwatched", "action": "mark_as_watched",
                    "season": self.meta['season'], "episode": self.meta['episode'], "media_id": self.meta['media_id'],
                    "title": self.meta['title'], "year": self.meta['year']}
                xbmc.executebuiltin("RunPlugin(%s)" % build_url(watched_params))
            else: pass
        except: pass

    def onAVStarted(self):
        hide_busy_dialog()

    def onPlayBackStarted(self):
        hide_busy_dialog()

    def onPlayBackStopped(self):
        self.mediaWatchedMarker()

    def onPlayBackEnded(self):
        self.mediaWatchedMarker()

    def playAudioAlbum(self, t_files=None, name=None, from_seperate=False):
        import os
        import xbmcaddon
        from resources.lib.modules.utils import clean_file_name, batch_replace, to_utf8
        from resources.lib.modules.nav_utils import setView
        __addon_id__ = 'plugin.video.furkit'
        __addon__ = xbmcaddon.Addon(id=__addon_id__)
        __handle__ = int(sys.argv[1])
        addon_dir = xbmc.translatePath(__addon__.getAddonInfo('path'))
        icon_directory = settings.get_theme()
        default_furk_icon = os.path.join(icon_directory, 'furk.png')
        formats = ('.3gp', ''), ('.aac', ''), ('.flac', ''), ('.m4a', ''), ('.mp3', ''), \
        ('.ogg', ''), ('.raw', ''), ('.wav', ''), ('.wma', ''), ('.webm', ''), ('.ra', ''), ('.rm', '')
        FURK_FILES_VIEW  = settings.SETTING_FURK_FILES_VIEW
        params = dict(parse_qsl(sys.argv[2].replace('?','')))
        furk_files_list = []
        playlist=xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        playlist.clear()
        if from_seperate: t_files = [i for i in t_files if clean_file_name(i['path']) == params.get('item_path')]
        for item in t_files:
            name = item['path'] if not name else name
            if not 'audio' in item['ct']: continue
            url = item['url_dl']
            track_name = clean_file_name(batch_replace(to_utf8(item['name']), formats))
            listitem = xbmcgui.ListItem(track_name)
            listitem.setThumbnailImage(default_furk_icon)
            listitem.setInfo(type='music',infoLabels={'title': track_name, 'size': int(item['size']), 'album': clean_file_name(batch_replace(to_utf8(name), formats)),'duration': item['length']})
            listitem.setProperty('mimetype', 'audio/mpeg')
            playlist.add(url, listitem)
            if from_seperate: furk_files_list.append((url, listitem, False))
        self.play(playlist)
        if from_seperate:
            xbmcplugin.addDirectoryItems(__handle__, furk_files_list, len(furk_files_list))
            setView(FURK_FILES_VIEW)
            xbmcplugin.endOfDirectory(__handle__)




