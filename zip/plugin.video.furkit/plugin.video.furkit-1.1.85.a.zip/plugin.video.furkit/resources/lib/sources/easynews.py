import xbmcaddon
import re
import urllib
from datetime import timedelta
import base64
from resources.lib.modules.utils import clean_file_name, replace_html_codes
from resources.lib.modules import global_vars as g
from resources.lib.modules import furkitcache
from resources.lib.modules import settings
# from resources.lib.modules.utils import logger

__addon_id__ = 'plugin.video.furkit'
__addon__ = xbmcaddon.Addon(id=__addon_id__)

SORT = {'s1': 'relevance', 's1d': '-', 's2': 'dsize', 's2d': '-', 's3': 'dtime', 's3d': '-'}
SEARCH_PARAMS = {'st': 'adv', 'safeO': 0, 'sb': 1, 'fex': 'mkv, mp4, avi', 'fty[]': 'VIDEO', 'spamf': 1, 'u': '1', 'gx': 1, 'pno': 1, 'sS': 3}
SEARCH_PARAMS.update(SORT)
BR_VERS = [
    ['%s.0' % i for i in xrange(18, 53)],
    ['37.0.2062.103', '37.0.2062.120', '37.0.2062.124', '38.0.2125.101', '38.0.2125.104', '38.0.2125.111', '39.0.2171.71', '39.0.2171.95', '39.0.2171.99', '40.0.2214.93', '40.0.2214.111',
     '40.0.2214.115', '42.0.2311.90', '42.0.2311.135', '42.0.2311.152', '43.0.2357.81', '43.0.2357.124', '44.0.2403.155', '44.0.2403.157', '45.0.2454.101', '45.0.2454.85', '46.0.2490.71',
     '46.0.2490.80', '46.0.2490.86', '47.0.2526.73', '47.0.2526.80', '48.0.2564.116', '49.0.2623.112', '50.0.2661.86', '51.0.2704.103', '52.0.2743.116', '53.0.2785.143', '54.0.2840.71',
     '56.0.2924.87', '57.0.2987.133'],
    ['11.0'],
    ['8.0', '9.0', '10.0', '10.6']]

RAND_UAS = ['Mozilla/5.0 ({win_ver}{feature}; rv:{br_ver}) Gecko/20100101 Firefox/{br_ver}',
            'Mozilla/5.0 ({win_ver}{feature}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{br_ver} Safari/537.36',
            'Mozilla/5.0 ({win_ver}{feature}; Trident/7.0; rv:{br_ver}) like Gecko',
            'Mozilla/5.0 (compatible; MSIE {br_ver}; {win_ver}{feature}; Trident/6.0)']
FEATURES = ['; WOW64', '; Win64; IA64', '; Win64; x64', '']
WIN_VERS = ['Windows NT 10.0', 'Windows NT 7.0', 'Windows NT 6.3', 'Windows NT 6.2', 'Windows NT 6.1', 'Windows NT 6.0', 'Windows NT 5.1', 'Windows NT 5.0']

class EasyNewsSource:

    def __init__(self):
        self.provider = 'EASYNEWS'
        self.provider_color = settings.provider_color(self.provider.lower())
        self.base_url = 'https://members.easynews.com'
        self.search_url = '/2.0/search/solr-search/advanced'
        self.username = __addon__.getSetting('easynews_user')
        self.password = __addon__.getSetting('easynews_password')
        self.show_filenames = settings.show_filenames()
        self.max_results = int(__addon__.getSetting('easynews_limit'))
        self.max_gb = __addon__.getSetting('easynews_maxgb')
        self.max_bytes = int(self.max_gb) * 1024 * 1024 * 1024
        self.auth = 'Basic ' + base64.b64encode('%s:%s' % (self.username, self.password))


    def results(self, info):
        hosters = []
        if not self.username or not self.password: return
        self.info = info
        self.search_name = self._search_name()
        query_url = '/search?query=%s' % (urllib.quote_plus(self.search_name))
        files = self._get_links(query_url)
        if not files: return
        self.down_url = files.get('downURL')
        self.dl_farm = files.get('dlFarm')
        self.dl_port = files.get('dlPort')
        files = files.get('data', [])
        for item in files:
            try:
                post_hash, size, post_title, ext, duration = item['0'], item['4'], item['10'], item['11'], item['14']
                checks = [False] * 5
                if 'alangs' in item and item['alangs'] and 'eng' not in item['alangs']: checks[1] = True
                if re.match('^\d+s', duration) or re.match('^[0-5]m', duration): checks[2] = True
                if 'passwd' in item and item['passwd']: checks[3] = True
                if 'virus' in item and item['virus']: checks[4] = True
                if 'type' in item and item['type'].upper() != 'VIDEO': checks[5] = True
                if any(checks):
                    continue
                stream_url = self.down_url + urllib.quote('/%s/%s/%s%s/%s%s' % (self.dl_farm, self.dl_port, post_hash, ext, post_title, ext))
                
                self.file_name = post_title
                self.file_dl = stream_url + '|Authorization=%s' % (urllib.quote(self.auth))
                self.size = item['rawSize']
                self.video_info = ''
                self.details = self._get_release_details(item)
                self.video_quality = self._get_release_quality(self.file_name, self.file_dl)
                self.display_name = self._build_display_name()
                g.easynews_results.append({'name': self.file_name,
                                'display_name': self.display_name,
                                'quality': self.video_quality,
                                'size': self.size,
                                'url_dl': self.file_dl,
                                'id': self.file_dl,
                                'local': False,
                                'direct': True,
                                'provider': self.provider})
            except: pass

    def _build_display_name(self):
        display = '[B]EASYNEWS[/B]'
        quality = '[I]{}[/I] '.format(self.video_quality) if self.video_quality in ('SD', 'CAM', 'TELE', 'SCR') else '[I][B]{}[/B][/I] '.format(self.video_quality)
        display_name = '[COLOR={0}]{1} | {2} | {3}[/COLOR]'.format(self.provider_color, display.upper(), quality.upper(), self.details.upper())
        if self.show_filenames: display_name += '[COLOR={0}] | {1}[/COLOR]'.format(self.provider_color, clean_file_name(self.file_name).upper())
        return display_name

    def _search_name(self):
        search_title = clean_file_name(self.info.get("title"))
        db_type = self.info.get("db_type")
        year = self.info.get("year")
        season = self.info.get("season")
        episode = self.info.get("episode")
        if db_type == 'movie': search_name = '%s %s' % (search_title, year)
        else: search_name = '%s S%02dE%02d' % (search_title,  int(season), int(episode))
        return search_name

    def _get_links(self, url):
        _cache = furkitcache.FurkItCache()
        cache = _cache.get('easynews_%s' % self.search_name)
        if cache: result = cache
        else:
            search_url, params = self.__translate_search(url)
            html = self._http_get(search_url, params=params)
            result = self._parse_json(html, search_url)
            _cache.set('easynews_%s' % self.search_name, result, expiration=timedelta(hours=1))
        return result

    def _http_get(self, url, params=None):
        import urllib2
        import urlparse
        MAX_RESPONSE = 1024 * 1024 * 5
        if not self.username or not self.password:
            return ''
        headers = {'Authorization': self.auth}
        parts = urlparse.urlparse(url)
        if parts.query:
            params.update(self._parse_query(url))
            url = urlparse.urlunparse((parts.scheme, parts.netloc, parts.path, parts.params, '', parts.fragment))
        url += '?' + urllib.urlencode(params)
        if isinstance(url, unicode): url = url.encode('utf-8')
        request = urllib2.Request(url)
        headers = headers.copy()
        request.add_header('User-Agent', self._get_ua())
        request.add_header('Accept', '*/*')
        request.add_header('Accept-Encoding', 'gzip')
        request.add_unredirected_header('Host', request.get_host())
        for key, value in headers.iteritems(): request.add_header(key, value)
        response = urllib2.urlopen(request)
        if (response.getcode() in [301, 302, 303, 307] or response.info().getheader('Refresh')):
            if response.info().getheader('Refresh') is not None:
                refresh = response.info().getheader('Refresh')
                return refresh.split(';')[-1].split('url=')[-1]
            else:
                redir_url = response.info().getheader('Location')
                if redir_url.startswith('='):
                    redir_url = redir_url[1:]
                return redir_url
        content_length = response.info().getheader('Content-Length', 0)
        if int(content_length) > MAX_RESPONSE:
            return
        html = response.read(MAX_RESPONSE)
        return html

    def __translate_search(self, url):
        params = SEARCH_PARAMS
        params['pby'] = self.max_results
        params['gps'] = params['sbj'] = self._parse_query(url)['query']
        url = self.base_url + self.search_url
        return url, params

    def _get_release_quality(self, release_name, release_link=None, t_file=None):
        if release_name is None: return
        try: release_name = release_name
        except: pass
        try:
            vid_quality = None
            release_name = release_name.upper()
            fmt = re.sub('(.+)(\.|\(|\[|\s)(\d{4}|S\d*E\d*|S\d*)(\.|\)|\]|\s)', '', release_name)
            fmt = re.split('\.|\(|\)|\[|\]|\s|-', fmt)
            fmt = [i.lower() for i in fmt]
            if any(i in ['dvdscr', 'r5', 'r6'] for i in fmt): vid_quality = 'SCR'
            elif any(i in ['camrip', 'tsrip', 'hdcam', 'hd-cam', 'hdts', 'dvdcam', 'dvdts', 'cam', 'telesync', 'ts'] for i in fmt): vid_quality = 'CAM'
            elif any(i in ['tc', 'hdtc', 'telecine', 'tc720p', 'tc720', 'hdtc'] for i in fmt): vid_quality = 'TELE'
            elif '2160p' in fmt: vid_quality = '4K'
            elif '1080p' in fmt: vid_quality = '1080p'
            elif '720p' in fmt: vid_quality = '720p'
            elif 'brrip' in fmt: vid_quality = '720p'
            if not vid_quality:
                if release_link:
                    release_link = release_link.lower()
                    try: release_link = release_link
                    except: pass
                    if any(i in ['dvdscr', 'r5', 'r6'] for i in release_link): vid_quality = 'SCR'
                    elif any(i in ['camrip', 'tsrip', 'hdcam', 'hdts', 'dvdcam', 'dvdts', 'cam', 'telesync', 'ts'] for i in release_link): vid_quality = 'CAM'
                    elif any(i in ['tc', 'hdtc', 'telecine', 'tc720p', 'tc720', 'hdtc'] for i in release_link): vid_quality = 'TELE'
                    elif '2160' in release_link: vid_quality = '4K'
                    elif '1080' in release_link: vid_quality = '1080p'
                    elif '720' in release_link: vid_quality = '720p'
                    elif '.hd' in release_link: vid_quality = 'SD'
                    else: vid_quality = 'SD'
                else: vid_quality = 'SD'
            if not t_file:
                return vid_quality
            if any(i in ['hevc', 'h265', 'x265'] for i in fmt): vid_type = 'HEVC'
            else: vid_type = 'h264'
            return vid_quality, vid_type
        except:
            return 'SD', 'h264'

    def _get_release_details(self, item):
        name = replace_html_codes(self.file_name)
        size = float(self.size)/1073741824
        fmt = re.sub('(.+)(\.|\(|\[|\s)(\d{4}|S\d*E\d*)(\.|\)|\]|\s)', '', name)
        fmt = re.split('\.|\(|\)|\[|\]|\s|\-', fmt)
        fmt = [x.lower() for x in fmt]
        if '3d' in fmt: q = '  | 3D'
        else: q = ''
        try:
            if any(i in ['hevc', 'h265', 'x265'] for i in fmt): v = 'HEVC'
            else: v = 'h264'
            a = item['18'].replace('UNKNOWN', 'AC3')
            info = '%.2f GB%s | %s | %s' % (size, q, v, a)
            info = ' '.join(info.split())
            return info
        except: pass
        try:
            info = '%.2f GB | [I]%s[/I]' % (size, clean_file_name(name.replace('.', ' ')))
            return info
        except: pass

    def _get_ua(self):
        import random
        import time
        try: last_gen = int(__addon__.getSetting('last_ua_create'))
        except: last_gen = 0
        if not __addon__.getSetting('current_ua') or last_gen < (time.time() - (7 * 24 * 60 * 60)):
            index = random.randrange(len(RAND_UAS))
            versions = {'win_ver': random.choice(WIN_VERS), 'feature': random.choice(FEATURES), 'br_ver': random.choice(BR_VERS[index])}
            user_agent = RAND_UAS[index].format(**versions)
            __addon__.setSetting('current_ua', user_agent)
            __addon__.setSetting('last_ua_create', str(int(time.time())))
        else:
            user_agent = __addon__.getSetting('current_ua')
        return user_agent

    def _parse_query(self, url):
        import urlparse
        q = {}
        queries = urlparse.parse_qs(urlparse.urlparse(url).query)
        if not queries: queries = urlparse.parse_qs(url)
        for key, value in queries.iteritems():
            if len(value) == 1:
                q[key] = value[0]
            else:
                q[key] = value
        return q

    def _parse_json(self, html, url=''):
        import json
        if html:
            try:
                if not isinstance(html, unicode):
                    if html.startswith('\xef\xbb\xbf'):
                        html = html[3:]
                    elif html.startswith('\xfe\xff'):
                        html = html[2:]
                    html = html.decode('utf-8')
                    
                js_data = json.loads(html)
                if js_data is None:
                    return {}
                else:
                    return js_data
            except (ValueError, TypeError):
                return {}
        else:
            return {}
    
test = {u'results': 19, u'largeThumbSize': u'268x206', u'stemmed': u'true',
        u'thumbURL': u'https://th.easynews.com/thumbnails-', u'sid': u'd4a462a78b6f6874a5533c7b009651459a72ab6a',
        u'hidden': 1, u'dlPort': 443, u'perPage': u'10', u'returned': 9, u'sS': u'3', u'hthm': 0,
        u'unfilteredResults': 10, u'groups': [{u'alt.binaries.moovee': 5}, {u'alt.binaries.highspeed': 4},
        {u'alt.binaries.movies': 3}, {u'alt.binaries.u-4all': 3}, {u'alt.binaries.aubergine': 2},
        {u'alt.binaries.big': 2}, {u'alt.binaries.boneless': 2}, {u'alt.binaries.new-movies': 2},
        {u'alt.binaries.flowed': 1}, {u'alt.binaries.misc': 1}, {u'alt.binaries.multimedia': 1},
        {u'alt.binaries.test': 1}], u'hInfo': 0, u'data': [{u'twidth': 90, u'height': u'304', u'alangs': [u'eng'],
        u'20': u'&#8734;', u'width': u'720', u'ts': 1546184338, u'1': u'',
        u'0': u'7f330d3f785f41f0e2ec05d15e69ee5904408cd39', u'3': u'90 x 38', u'2': u'.mkv',
        u'5': u'12-30-2018 15:38:58', u'4': u'854.6 MB', u'7': u'JBinUp.com &lt;JBinUp@JBinUp.local&gt;',
        u'6': u'(29/29) - Description - &quot; Reports 078780021003995.z18&quot; - 987.21 MB - yEnc (1/17) (Ralph Breaks the Internet 2018 DVDSCR MkvCage ws.mkv AutoUnRAR)',
        u'9': u'alt.binaries.moovee', u'8': u'<autorar-HMuoHhLxCjE68EAnEXZA_29o29@JBinUp.local-26b05bb5>',
        u'type': u'VIDEO', u'fullres': u'720 x 304', u'passwd': False, u'expires': u'&#8734;', u'volume': False,
        u'theight': 38, u'fallbackURL': u'//members.easynews.com', u'slangs': None, u'rawSize': 896092470,
        u'primaryURL': u'//members.easynews.com', u'11': u'.mkv', u'10':
        u'Ralph Breaks the Internet 2018 DVDSCR MkvCage ws', u'13': u'1', u'12': u'H264', u'15': 1074,
        u'14': u'1h:51m:12s', u'17': 25, u'16': 44100, u'19': u'95c56bc816a5841d691adbb5178b5206', u'18': u'UNKNOWN',
        u'virus': False, u'35': u'c3ac', u'nfo': u'', u'sc': False, u'sb': 1}, {u'twidth': 90, u'height': u'304',
        u'alangs': None, u'20': u'&#8734;', u'width': u'720', u'ts': 1546459069, u'1': u'',
        u'0': u'341ca31039260ab9e31dd2c0f76ae3dd0efdeb819', u'3': u'90 x 38', u'2': u'.avi', u'5': u'01-02-2019 19:57:49',
        u'4': u'1.5 GB', u'7': u'yEncBin@Poster.com (franky007)', u'9': u'alt.binaries.movies', u'8': u'<autorar-Part1of130.F75592268DFB4F8D99D96A0F65D66DDD@1546460778.local-90c23d63>',
        u'6': u'Ralph.Breaks.the.Internet.2018.DVDSCR.XviD.AC3-EVO- franky007 - [37/44] - &quot;Ralph.Breaks.the.Internet.2018.DVDSCR.XviD.AC3-EVO.part34.rar&quot; yEnc (1/130) (Ralph.Breaks.the.Internet.2018.DVDSCR.XviD.AC3-EVO.avi AutoUnRAR)',
        u'type': u'VIDEO', u'fullres': u'720 x 304', u'passwd': False, u'expires': u'&#8734;',
        u'volume': False, u'theight': 38, u'fallbackURL': u'//members.easynews.com', u'slangs': None,
        u'rawSize': 1659158608, u'primaryURL': u'//members.easynews.com', u'11': u'.avi',
        u'10': u'Ralph.Breaks.the.Internet.2018.DVDSCR.XviD.AC3-EVO', u'13': u'1', u'12': u'XVID', u'15': 1989,
        u'14': u'1h:51m:12s', u'17': 25, u'16': 44100, u'19': u'5be62ac23c11941972242b634dacbe06',
        u'18': u'UNKNOWN', u'virus': False, u'35': u'766c', u'nfo': u'dfb4e7e07cbe32b38725f005b99020fe059b8e982',
        u'sc': False, u'sb': 1}, {u'twidth': 90, u'height': u'304', u'alangs': None, u'20': u'&#8734;',
        u'width': u'720', u'ts': 1546181579, u'1': u'', u'0': u'8d07ed60536b5388a3e59e6295d8e7e00046d9746',
        u'3': u'90 x 38', u'2': u'.avi', u'5': u'12-30-2018 14:52:59', u'4': u'1.5 GB',
        u'7': u'WtF[NZB] &lt;freestuff@for.all&gt;', u'6': u'[1/2] - &quot;Ralph Breaks the Internet.2018.V2.DVDSCR.XviD.AC3-EVO.avi&quot; yEnc (1/2255) 1616285696',
        u'9': u'alt.binaries.test', u'8': u'<GdNyXtYtNyNoYpZeVdFgJeMt-1546181559432@nyuu>', u'type': u'VIDEO',
        u'fullres': u'720 x 304', u'passwd': False, u'expires': u'&#8734;', u'volume': False, u'theight': 38,
        u'fallbackURL': u'//members.easynews.com', u'slangs': None, u'rawSize': 1616285696,
        u'primaryURL': u'//members.easynews.com', u'11': u'.avi',
        u'10': u'Ralph Breaks the Internet.2018.V2.DVDSCR.XviD.AC3-EVO', u'13': u'1', u'12': u'XVID',
        u'15': 1951, u'14': u'1h:50m:25s', u'17': 25, u'16': 48000, u'19': u'028e644eaae6571aff7ac9910327552a',
        u'18': u'UNKNOWN', u'virus': False, u'35': u'26cc', u'nfo': u'', u'sc': False, u'sb': 1},
        {u'twidth': 240, u'height': u'804', u'alangs': [u'eng'], u'20': u'&#8734;', u'width': u'1920',
        u'ts': 1549904962, u'1': u'', u'0': u'7b88ccb4d4086d507577ec8a5ed5dcd709edf71fd', u'3': u'240 x 101',
        u'2': u'.mkv', u'5': u'02-11-2019 17:09:22', u'4': u'3.9 GB', u'7': u'Bob &lt;bob@otherhome.me&gt;',
        u'6': u'&quot;7456f62d71566cc4413854a69abe2d.5a&quot; yEnc (01/63) (Ralph Breaks the Internet.2018.1080p.WEB-DL.H264.AC3-EVO.mkv AutoUnRAR)',
        u'9': u'alt.binaries.u-4all', u'8': u'<autorar-0VXtjkgl49fI-tXtssKYIrRyrSd0@93n740jiK.IN1Z-65e0edab>',
        u'type': u'VIDEO', u'fullres': u'1920 x 804', u'passwd': False, u'expires': u'&#8734;', u'volume': False,
        u'theight': 101, u'fallbackURL': u'//members.easynews.com', u'slangs': None, u'rawSize': 4147626652L,
        u'primaryURL': u'//members.easynews.com', u'11': u'.mkv', u'13': u'1', u'12': u'H264', u'15': 4875,
        u'10':u'Ralph Breaks the Internet.2018.1080p.WEB-DL.H264.AC3-EVO', u'14': u'1h:53m:25s', u'17': 24,
        u'16': 48000, u'19': u'de3ac0e6974f020b492730511e97c8a6', u'18': u'AC3', u'virus': False, u'35': u'e4d5',
        u'nfo': u'', u'sc': False, u'sb': 1}, {u'twidth': 90, u'height': u'304', u'alangs': None, u'20': u'&#8734;',
        u'width': u'720', u'ts': 1546247829, u'1': u'', u'0': u'fa64539d4c0e86d4a4ec570e2643a4330e44edefd',
        u'3': u'90 x 38', u'2': u'.mkv', u'5': u'12-31-2018 09:17:09', u'4': u'358.5 MB',
        u'7': u'JBinUp.com &lt;JBinUp@JBinUp.local&gt;', u'9': u'alt.binaries.moovee', u'8': u'<autorar-pFrt6vKpVgWwPhIXZDk8_19o19@JBinUp.local-3d06b358>', 
        u'6': u'(19/19) - Description - &quot; Lease 998979987097292.z08&quot; - 413.38 MB - yEnc (1/23) (Ralph Breaks the Internet 2018 INTERNAL SD DVDScr 2CH x265 HEVC-PSA.mkv AutoUnRAR)',
        u'type': u'VIDEO', u'fullres': u'720 x 304', u'passwd': False, u'expires': u'&#8734;', u'volume': False,
        u'theight': 38, u'fallbackURL': u'//members.easynews.com', u'slangs': [u'eng'], u'rawSize': 375872467,
        u'primaryURL': u'//members.easynews.com', u'11': u'.mkv', u'13': u'1', u'12': u'HEVC', u'15': 450, u'14': u'1h:51m:12s',
        u'10': u'Ralph Breaks the Internet 2018 INTERNAL SD DVDScr 2CH x265 HEVC-PSA', u'17': 25, u'16': 48000,
        u'19': u'95c56bc816a5841d691adbb5178b5206', u'18': u'UNKNOWN', u'virus': False, u'35': u'b205',
        u'nfo': u'', u'sc': False, u'sb': 1}, {u'twidth': 240, u'height': u'804', u'alangs': [u'eng'],
        u'20': u'&#8734;', u'width': u'1920', u'ts': 1549965045, u'1': u'', u'0': u'edf1f9aa5c518c7fe3be60f44a9cb7e908616eada',
        u'3': u'240 x 101', u'2': u'.mkv', u'5': u'02-12-2019 09:50:45', u'4': u'1.9 GB', u'fullres': u'1920 x 804',
        u'7': u'JBinUp.com &lt;JBinUp@JBinUp.local&gt;', u'9': u'alt.binaries.moovee', u'type': u'VIDEO', 
        u'6': u'(31/31) - Description - &quot;Aesthetic Licence 877909779775793.z20&quot; - 2.19 GB - yEnc (1/120) (Ralph Breaks the Internet 2018 1080p WEB-DL x264 6CH MkvCage ws.mkv AutoUnRAR)',
        u'8': u'<autorar-fltV78at6OdsN7deLIE2_31o31@JBinUp.local-af35d112>', u'passwd': False,
        u'expires': u'&#8734;', u'volume': False, u'theight': 101, u'fallbackURL': u'//members.easynews.com',
        u'slangs': [u'eng'], u'rawSize': 2035043632, u'primaryURL': u'//members.easynews.com', u'11': u'.mkv',
        u'10': u'Ralph Breaks the Internet 2018 1080p WEB-DL x264 6CH MkvCage ws', u'13': u'1', u'12': u'H264',
        u'15': 2392, u'14': u'1h:53m:25s', u'17': 24, u'16': 48000, u'19': u'95c56bc816a5841d691adbb5178b5206',
        u'18': u'AAC', u'virus': False, u'35': u'5539', u'nfo': u'', u'sc': False, u'sb': 1},
        {u'twidth': 240, u'height': u'804', u'alangs': [u'eng', u'fre'], u'20': u'&#8734;', u'width': u'1920',
        u'ts': 1549977065, u'1': u'', u'0': u'080b7f75fcce7e112a2abdbce458f8740b5a28533', u'3': u'240 x 101',
        u'2': u'.mkv', u'5': u'02-12-2019 13:11:05', u'4': u'4.0 GB', u'9': u'alt.binaries.highspeed',
        u'7': u'CPP-user@domain.com (nzbnewzfrance.eu.com)', u'type': u'VIDEO', u'fullres': u'1920 x 804', u'passwd': False,
        u'6': u'{Y28IOZR8-4B66-N69P-2G8D-8GH15A2UO287} (01/77) (Ralph.Breaks.the.Internet.2018.MULTi.1080p.WEB.H264.mkv AutoUnRAR)',
        u'8': u'<autorar-part1of77.ZCmszZj3zyX3rWSvxB1g@camelsystem-powerpost.local-fc8aa7ba>', u'12': u'H264',
        u'expires': u'&#8734;', u'volume': False, u'theight': 101, u'fallbackURL': u'//members.easynews.com',
        u'slangs': [u'fre'], u'rawSize': 4245291230L, u'primaryURL': u'//members.easynews.com', u'13': u'1', u'15': 5007,
        u'11': u'.mkv', u'10': u'Ralph.Breaks.the.Internet.2018.MULTi.1080p.WEB.H264', u'14': u'1h:53m:2s',
        u'17': 23.98, u'16': 48000, u'19': u'c7a318afbe0405657359c123bac37ebb', u'18': u'AC3', u'virus': False,
        u'35': u'0836', u'nfo': u'', u'sc': False, u'sb': 1}, {u'twidth': 90, u'height': u'304',
        u'alangs': [u'eng'], u'20': u'&#8734;', u'width': u'720', u'ts': 1549991364, u'1': u'',
        u'0': u'ccee2896b5f1faedfea1318a3f90c2e405b24df67', u'3': u'90 x 38', u'2': u'.mkv',
        u'5': u'02-12-2019 17:09:24', u'4': u'1.3 GB', u'7': u'yEncBin@Poster.com (franky007)',
        u'6': u'Ralph.Breaks.the.Internet.2018.HDRip.AC3.X264-CMRG- franky007 - [33/40] - &quot;Ralph.Breaks.the.Internet.2018.HDRip.AC3.X264-CMRG.part30.rar&quot; yEnc (1/85) (Ralph.Breaks.the.Internet.2018.HDRip.AC3.X264-CMRG.mkv AutoUnRAR)',
        u'9': u'alt.binaries.aubergine alt.binaries.big alt.binaries.boneless alt.binaries.movies alt.binaries.new-movies',
        u'8': u'<autorar-Part1of85.755A4267DB6847A68A43FCB8EA45DA4C@1549993227.local-4c399a34>', u'type': u'VIDEO',
        u'fullres': u'720 x 304', u'passwd': False, u'expires': u'&#8734;', u'volume': False, u'theight': 38,
        u'fallbackURL': u'//members.easynews.com', u'slangs': None, u'rawSize': 1427172272, u'14': u'1h:53m:25s',
        u'primaryURL': u'//members.easynews.com', u'11': u'.mkv', u'13': u'1', u'12': u'H264', u'15': 1677,
        u'10': u'Ralph.Breaks.the.Internet.2018.HDRip.AC3.X264-CMRG', u'17': 23.98, u'16': 48000,
        u'19': u'a6b2d95a9271c4ef02a349ed31bef73e', u'18': u'AC3', u'virus': False, u'35': u'2257', u'nfo': u'',
        u'sc': False, u'sb': 1}, {u'twidth': 160, u'height': u'536', u'alangs': [u'eng'], u'20': u'&#8734;',
        u'width': u'1280', u'ts': 1549905329, u'1': u'', u'0': u'8d2f147c8e2df669d3740b31e82a14820c6202529',
        u'3': u'160 x 67', u'2': u'.mkv', u'5': u'02-11-2019 17:15:29', u'4': u'3.5 GB',
        u'7': u'Bob &lt;bob@home.me&gt;', u'6': u'&quot;e9421b9e83d22dff73962281237b3e.c6&quot; yEnc (01/20) (Ralph Breaks the Internet.2018.720p.WEB-DL.H264.AC3-EVO.mkv AutoUnRAR)',
        u'9': u'alt.binaries.flowed', u'8': u'<autorar-MMjzMkY$SPF$2O.UtZmiU.iyKMIijTVF5Q@QvFb75.oo4r-c8bcb6de>',
        u'type': u'VIDEO', u'fullres': u'1280 x 536', u'passwd': False, u'expires': u'&#8734;', u'volume': False,
        u'theight': 67, u'fallbackURL': u'//members.easynews.com', u'slangs': None, u'rawSize': 3714835523L,
        u'primaryURL': u'//members.easynews.com', u'11': u'.mkv', u'13': u'1', u'12': u'H264', u'15': 4366,
        u'10': u'Ralph Breaks the Internet.2018.720p.WEB-DL.H264.AC3-EVO', u'14': u'1h:53m:25s', u'17': 23.98,
        u'16': 48000, u'19': u'51e4c71774a819b434be369bbaf119bb', u'18': u'AC3', u'virus': False, u'35': u'52ff',
        u'nfo': u'', u'sc': False, u'sb': 1}], u'largeThumb': u'0', u'numPages': 2,
        u'fields': {u'10': u'Filename', u'12': u'Video Codec', u'20': u'Expire Date', u'14': u'Runtime', u'17':
        u'FPS', u'16': u'Sample Rate', u'18': u'Audio Codec', u'FullThumb': u'Full Thumb', u'3': u'Resolution',
        u'2': u'Extension', u'5': u'Post Date', u'4': u'Size', u'7': u'Poster', u'6': u'Subject', u'9': u'Group',
        u'15': u'BPS'}, u'dlFarm': u'auto', u'baseURL': u'https://members.easynews.com', u'st': u'adv',
        u'downURL':u'https://members.easynews.com/dl', u'gsColumns': [{u'num': 6, u'name': u'subject'},
        {u'num': 4, u'name': u'size'}, {u'num': 9, u'name': u'group'}, {u'num': 5, u'name': u'time'},
        {u'num': 7, u'name': u'poster'}, {u'num': -1, u'name': u'set'}], u'page': 1, u'classicThumbs': u'0'}
