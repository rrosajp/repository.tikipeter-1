import xbmcaddon
import re
from resources.lib.modules import global_vars as g
from resources.lib.modules.furk_api import FurkAPI
from resources.lib.modules.utils import clean_file_name, replace_html_codes
# from resources.lib.modules.utils import logger

Furk = FurkAPI()

class FurkSource:

    def results(self, info):
        self.info = info
        self.search_name = self._search_name()
        files = Furk.search(self.search_name)
        if not files: return
        for i in files:
            try:
                if i['is_ready'] == '1' and i['type'] == 'video':
                    self.file_name = i['name']
                    self.file_id = i['id']
                    self.size = int(i['size'])
                    self.file_dl = i['url_dl']
                    self.video_info = i['video_info']
                    self.files_num_video = i['files_num_video']
                    self.details = self._get_release_details()
                    self.video_quality = self._get_release_quality(self.file_name, self.file_dl)
                    self.display_name = self._build_display_name()
                    g.furk_results.append({'name': self.file_name,
                                    'display_name': self.display_name,
                                    'quality': self.video_quality,
                                    'size': self.size,
                                    'url_dl': self.file_dl,
                                    'id': self.file_id,
                                    'local': False,
                                    'direct': True})
            except:
                self.file_name = i['name']
                self.info_hash = i['info_hash']
                self.display_name = self._build_display_name(uncached=True)
                g.furk_results.append({'name': self.file_name,
                                'display_name': self.display_name,
                                'quality': 'UNCACHED',
                                'size': '0',
                                'url_dl': self.info_hash,
                                'id': self.info_hash,
                                'local': False,
                                'direct': True})


    def _search_name(self):
        search_title = clean_file_name(self.info.get("title"))
        search_title = search_title.replace(' ', '+')
        db_type = self.info.get("db_type")
        year = self.info.get("year")
        years = '%s+|+%s+|+%s' % (str(int(year - 1)), year, str(int(year + 1)))
        season = self.info.get("season")
        episode = self.info.get("episode")
        if db_type == 'movie': search_name = '@name+%s+%s' % (search_title, years)
        else:
            queries = self._seas_ep_query_list(season, episode)
            search_name = '@name+%s+@files+%s+|+%s+|+%s' % (search_title, queries[0], queries[1], queries[2])
        return search_name

    def _build_display_name(self, uncached=False):
        if uncached: return '[I][B]FURK[/B] | [COLOR=red][B]UNCACHED[/B][/COLOR] | %s[/I]' % self.file_name.upper()
        display = '[B]FURK[/B] | PACK [B](x%02d)[/B]' % int(self.files_num_video) if int(self.files_num_video) > 3 else '[B]FURK[/B] | SINGLE'
        quality = '[I]{}[/I] '.format(self.video_quality) if self.video_quality in ('HQ', 'CAM', 'TELE', 'SCR') else '[I][B]{}[/B][/I] '.format(self.video_quality)
        return '{0} | {1} | {2}'.format(display, quality, self.details).upper()

    def _seas_ep_query_list(self, season, episode):
        return ['s%02de%02d' % (int(season), int(episode)), '%dx%02d' % (int(season), int(episode)),
                '%02dx%02d' % (int(season), int(episode))]

    def _get_release_quality(self, release_name, release_link=None, t_file=None):
        if release_name is None: return
        try: release_name = release_name
        except: pass
        try:
            vid_quality = None
            release_name = release_name.upper()
            fmt = re.sub('(.+)(\.|\(|\[|\s)(\d{4}|S\d*E\d*|S\d*)(\.|\)|\]|\s)', '', release_name)
            fmt = re.split('\.|\(|\)|\[|\]|\s|-', fmt)
            fmt = [i.lower() for i in fmt]
            if any(i in ['dvdscr', 'r5', 'r6'] for i in fmt): vid_quality = 'SCR'
            elif any(i in ['camrip', 'tsrip', 'hdcam', 'hd-cam', 'hdts', 'dvdcam', 'dvdts', 'cam', 'telesync', 'ts'] for i in fmt): vid_quality = 'CAM'
            elif any(i in ['tc', 'hdtc', 'telecine', 'tc720p', 'tc720', 'hdtc'] for i in fmt): vid_quality = 'TELE'
            elif '2160p' in fmt: vid_quality = '4K'
            elif '1080p' in fmt: vid_quality = '1080p'
            elif '720p' in fmt: vid_quality = '720p'
            elif 'brrip' in fmt: vid_quality = '720p'
            if not vid_quality:
                if release_link:
                    release_link = release_link.lower()
                    try: release_link = release_link
                    except: pass
                    if any(i in ['dvdscr', 'r5', 'r6'] for i in release_link): vid_quality = 'SCR'
                    elif any(i in ['camrip', 'tsrip', 'hdcam', 'hdts', 'dvdcam', 'dvdts', 'cam', 'telesync', 'ts'] for i in release_link): vid_quality = 'CAM'
                    elif any(i in ['tc', 'hdtc', 'telecine', 'tc720p', 'tc720', 'hdtc'] for i in release_link): vid_quality = 'TELE'
                    elif '2160' in release_link: vid_quality = '4K'
                    elif '1080' in release_link: vid_quality = '1080p'
                    elif '720' in release_link: vid_quality = '720p'
                    elif '.hd' in release_link: vid_quality = 'SD'
                    else: vid_quality = 'SD'
                else: vid_quality = 'SD'
            if not t_file:
                return vid_quality
            if any(i in ['hevc', 'h265', 'x265'] for i in fmt): vid_type = 'HEVC'
            else: vid_type = 'h264'
            return vid_quality, vid_type
        except:
            if not t_file:
                return 'SD'
            else:
                return 'SD', 'h264'

    def _get_release_details(self):
        name = replace_html_codes(self.file_name)
        size = float(self.size)/1073741824
        fmt = re.sub('(.+)(\.|\(|\[|\s)(\d{4}|S\d*E\d*)(\.|\)|\]|\s)', '', name)
        fmt = re.split('\.|\(|\)|\[|\]|\s|\-', fmt)
        fmt = [x.lower() for x in fmt]
        if '3d' in fmt: q = '  | 3D'
        else: q = ''
        try:
            info = self.video_info.replace('\n','')
            v = re.compile('Video: (.+?),').findall(info)[0]
            a = re.compile('Audio: (.+?), .+?, (.+?),').findall(info)[0]
            info = '%.2f GB%s | %s | %s | %s' % (size, q, v, a[0], a[1])
            info = re.sub('\(.+?\)', '', info)
            info = info.replace('stereo', '2.0')
            info = info.replace('eac3', 'dd+')
            info = info.replace('ac3', 'dd')
            info = info.replace('channels', 'ch')
            info = ' '.join(info.split())
            return info
        except: pass
        try:
            if any(i in ['hevc', 'h265', 'x265'] for i in fmt): v = 'HEVC'
            else: v = 'h264'
            info = '%.2f GB%s | %s' % (size, q, v)
            return info
        except: pass
        try:
            info = '%.2f GB | [I]%s[/I]' % (size, name.replace('.', ' '))
            return info
        except: pass




