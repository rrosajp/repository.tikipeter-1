import xbmc, xbmcaddon, xbmcvfs
import os
import shutil
from resources.lib.modules.nav_utils import show_busy_dialog, hide_busy_dialog, notification
# from resources.lib.modules.utils import logger

class ExternalImporter():
    def __init__(self):
        self.dest_path = xbmc.translatePath(os.path.join(xbmcaddon.Addon("plugin.video.furkit").getAddonInfo('profile'), "FurkitScrapers" + '/'))
        self.civ_id = "script.module.eggscrapers"
        self.civ_addon = xbmcaddon.Addon(self.civ_id)
        self.civ_path = xbmc.translatePath(os.path.join(self.civ_addon.getAddonInfo('path'), 'lib', 'oathscrapers' + '/'))
        self.civ_version = self.civ_addon.getAddonInfo('version')

    def import_external(self):
        show_busy_dialog()
        import_status = False
        # try:
        self._make_init_file()
        # if xbmcvfs.exists(self.civ_path):
        try: xbmcvfs.rmdir(self.dest_path, True)
        except: pass
        shutil.copytree(self.civ_path, self.dest_path)
        self._instances_rename(self.dest_path)
        import_status = True
        notification('Furk It Scrapers Activated', 5000, self.civ_addon.getAddonInfo('icon'))
        xbmcaddon.Addon("plugin.video.furkit").setSetting('civ_version', self.civ_version)
        # else:
            # notification('Activation Failed. Please ensure you have Externals Scrapers Module Installed', 5000)
        # except:
            # notification('External Scrapers Activation Failed. Please See Log Error', 5000)
        hide_busy_dialog()
        return import_status

    def _make_init_file(self):
        init_file = xbmcvfs.File(os.path.join(xbmcaddon.Addon("plugin.video.furkit").getAddonInfo('profile'), '__init__.py'), 'w')
        init_file.close()

    def _instances_rename(self, path):
        replacements = [['from resources.lib.', 'from furkitscrapers.']]
        directories, files = self._list_directory(path, absolute=True)
        for file in files:
            if file.endswith('.py'):
                self._replace_now(file, replacements)
        for directory in directories:
            self._instances_rename(directory)

    def _list_directory(self, path, absolute=False):
        directories, files = xbmcvfs.listdir(path)
        if absolute:
            for i in range(len(files)):
                files[i] = os.path.join(path, files[i])
            for i in range(len(directories)):
                directories[i] = os.path.join(path, directories[i])
        return directories, files

    def _replace_now(self, path, valueFrom, valueTo=None):
        data = self._read_now(path)
        if not isinstance(valueFrom, list):
            valueFrom = [[valueFrom, valueTo]]
        for replacement in valueFrom:
            data = data.replace(replacement[0], replacement[1])
        self._write_now(path, data)

    def _read_now(self, path):
        try:
            file = xbmcvfs.File(path)
            result = file.read()
            file.close()
            return result.decode('utf-8')
        except: return None

    def _write_now(self, path, value):
        file = xbmcvfs.File(path, 'w')
        result = file.write(str(value.encode('utf-8')))
        file.close()
        return result
