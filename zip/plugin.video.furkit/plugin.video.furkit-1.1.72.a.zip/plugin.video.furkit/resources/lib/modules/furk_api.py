import sys
import xbmcaddon
import requests, json
import time, datetime
from resources.lib.modules import furkitcache
from resources.lib.modules.utils import to_utf8
# from resources.lib.modules.utils import logger

__addon__ = xbmcaddon.Addon(id='plugin.video.furkit')
_cache = furkitcache.FurkItCache()

class FurkAPI:
    def __init__(self):
        self.base_link = 'https://www.furk.net'
        self.login_link = "/api/login/login?login=%s&pwd=%s"
        self.file_get_video_link = "/api/file/get?api_key=%s&type=video&sort_col=size"
        self.file_get_audio_link = "/api/file/get?api_key=%s&type=audio&sort_col=size"
        self.file_link_link = "/api/file/link?api_key=%s&id=%s"
        self.file_unlink_link = "/api/file/unlink?api_key=%s&id=%s"
        self.file_protect_link = "/api/file/protect?api_key=%s&id=%s&is_protected=%s"
        self.account_info_link = "/api/account/info?api_key=%s"
        self.search_link = "/api/plugins/metasearch?api_key=%s&q=%s&cached=yes" \
                                "&match=%s&moderated=%s%s&sort=size&type=video&offset=0&limit=%s"
        self.search_direct_link = "/api/plugins/metasearch?api_key=%s&q=%s&cached=yes" \
                                "&sort=relevance&type=video&offset=0&limit=%s"
        self.search_torrent_link = "/api/plugins/metasearch?api_key=%s&q=%s&cached=all" \
                                "&sort=relevance&type=video&offset=0&limit=%s"
        self.tfile_link = "/api/file/get?api_key=%s&t_files=1&id=%s"
        self.user_name = __addon__.getSetting('furk_login')
        self.user_pass = __addon__.getSetting('furk_password')
        self.api_key = __addon__.getSetting('furk_api_key')
        self.furk_limit = __addon__.getSetting('furk.limit')
        self.furk_limit_direct = __addon__.getSetting('furk.limit.direct')
        self.mod_level = __addon__.getSetting('furk.mod.level').lower()

    def get_api(self):
        try:
            if not self.user_name or not self.user_pass:
                __addon__.setSetting('furk_api_key', '')
            api_key = self.api_key
            if not api_key:
                if not self.user_name or not self.user_pass:
                    import xbmcgui
                    dialog = xbmcgui.Dialog()
                    if dialog.yesno("No Furk username/password set!", "Furk It works best with a Furk account.", "If you are not a member of Furk.net, please have Universal Scrapers installed and change provider settings..  Would you like to visit settings now?"):
                        from resources.lib.modules.nav_utils import open_settings
                        open_settings('0.2')
                    return
                else:
                    link = (self.base_link + self.login_link % (self.user_name, self.user_pass))
                    s = requests.Session()
                    p = s.post(link)
                    p = json.loads(p.text)
                    if p['status'] == 'ok':
                        api_key = p['api_key']
                        __addon__.setSetting('furk_api_key', api_key)
                    else:
                        pass
            return api_key
        except: pass

    def search(self, query):
        try:
            api_key = self.get_api()
            if not api_key: return
            search_in = '' if '@files' in query else '&attrs=name'
            link = (self.base_link + self.search_link \
                % (api_key, query, 'extended', self.mod_level, search_in, self.furk_limit))
            cache = _cache.get("furkit_%s_%s" % ('FURK_SEARCH', query))
            if cache:
                files = cache
            else:
                p = self._get(link)
                if p['status'] != 'ok':
                    return
                files = p['files']
                _cache.set("furkit_%s_%s" % ('FURK_SEARCH', query), files,
                    expiration=datetime.timedelta(hours=2))
            return files
        except: return

    def direct_search(self, query):
        try:
            api_key = self.get_api()
            if not api_key: return
            link = (self.base_link + self.search_direct_link % (api_key, query, self.furk_limit_direct))
            cache = _cache.get("furkit_%s_%s" % ('FURK_SEARCH_DIRECT', query))
            if cache:
                files = cache
            else:
                p = self._get(link)
                if p['status'] != 'ok':
                    return
                files = p['files']
                _cache.set("furkit_%s_%s" % ('FURK_SEARCH_DIRECT', query), files,
                    expiration=datetime.timedelta(hours=2))
            return files
        except: return

    def t_files(self, file_id):
        try:
            cache = _cache.get("furkit_%s_%s" % ('FURK_T_FILE', file_id))
            if cache:
                t_files = cache
            else:
                link = (self.base_link + self.tfile_link % (self.api_key, file_id))
                p = self._get(link)
                if p['status'] != 'ok' or p['found_files'] != '1': return
                t_files = p['files']
                t_files = (t_files[0])['t_files']
                _cache.set("furkit_%s_%s" % ('FURK_T_FILE', file_id), t_files,
                    expiration=datetime.timedelta(hours=2))
            return t_files
        except: return

    def file_get_video(self):
        try:
            link = (self.base_link + self.file_get_video_link % (self.api_key))
            p = self._get(link)
            files = p['files']
            return files
        except: return

    def file_get_audio(self):
        try:
            link = (self.base_link + self.file_get_audio_link % (self.api_key))
            p = self._get(link)
            files = p['files']
            return files
        except: return

    def file_link(self, item_id):
        try:
            link = (self.base_link + self.file_link_link % (self.api_key, item_id))
            return self._get(link)
        except: return

    def file_unlink(self, item_id):
        try:
            link = (self.base_link + self.file_unlink_link % (self.api_key, item_id))
            return self._get(link)
        except: return

    def file_protect(self, item_id, is_protected):
        try:
            link = (self.base_link + self.file_protect_link % (self.api_key, item_id, is_protected))
            return self._get(link)
        except: return

    def account_info(self):
        try:
            link = (self.base_link + self.account_info_link % (self.api_key))
            return self._get(link)
        except: return

    def _get(self, link):
        s = requests.Session()
        p = s.get(link)
        return to_utf8(json.loads(p.text))

